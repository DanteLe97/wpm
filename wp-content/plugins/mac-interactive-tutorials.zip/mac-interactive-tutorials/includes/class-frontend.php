<?php
/**
 * Frontend Class
 * 
 * Handles frontend widget loading and rendering
 */

if (!defined('ABSPATH')) {
    exit;
}

class MAC_Tutorial_Frontend {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_footer', array($this, 'render_widget_container'));
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_scripts($hook) {
        // Only load on admin pages
        if (strpos($hook, 'admin.php') === false && 
            strpos($hook, 'post.php') === false && 
            strpos($hook, 'post-new.php') === false &&
            strpos($hook, 'edit.php') === false) {
            return;
        }
        
        // Check if there's an active tutorial
        $active_tutorial_data = $this->get_active_tutorial_data();
        if (!$active_tutorial_data) {
            return;
        }
        
        // Enqueue scripts
        wp_enqueue_script(
            'mac-tutorial-widget',
            MAC_TUTORIALS_PLUGIN_URL . 'frontend/assets/js/widget.js',
            array('jquery'),
            MAC_TUTORIALS_VERSION,
            true
        );
        
        // Enqueue styles
        wp_enqueue_style(
            'mac-tutorial-widget',
            MAC_TUTORIALS_PLUGIN_URL . 'frontend/assets/css/widget.css',
            array(),
            MAC_TUTORIALS_VERSION
        );
        
        // Localize script with tutorial data
        wp_localize_script('mac-tutorial-widget', 'MacTutorialData', $active_tutorial_data);
    }
    
    /**
     * Get active tutorial data
     */
    private function get_active_tutorial_data() {
        $state_manager = new MAC_Tutorial_State_Manager();
        $active_state = $state_manager->get_active_tutorial();
        
        if (!$active_state) {
            return false;
        }
        
        $tutorial_id = $active_state['tutorial_id'];
        $tutorial = get_post($tutorial_id);
        
        if (!$tutorial || $tutorial->post_type !== 'mac_tutorial') {
            return false;
        }
        
        $steps = get_post_meta($tutorial_id, '_mac_tutorial_steps', true);
        $steps = !empty($steps) && is_array($steps) ? $steps : array();
        
        // Validate and sanitize current_step
        $current_step = isset($active_state['current_step']) ? intval($active_state['current_step']) : 0;
        $current_step = max(0, min($current_step, count($steps) - 1)); // Clamp to valid range
        
        return array(
            'tutorial' => array(
                'id' => $tutorial_id,
                'title' => $tutorial->post_title,
                'content' => $tutorial->post_content,
                'steps' => $steps,
            ),
            'current_step' => $current_step,
            'status' => $active_state['status'] ?? 'in-progress',
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => $state_manager->get_nonce(),
        );
    }
    
    /**
     * Render widget container
     */
    public function render_widget_container() {
        // Only render if there's an active tutorial
        $state_manager = new MAC_Tutorial_State_Manager();
        $active_state = $state_manager->get_active_tutorial();
        
        if (!$active_state) {
            return;
        }
        
        ?>
        <div id="mac-tutorial-widget-container"></div>
        <?php
    }
}

