<?php
/**
 * Admin Class
 * 
 * Handles admin pages and UI
 */

if (!defined('ABSPATH')) {
    exit;
}

class MAC_Tutorial_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_page'));
        add_action('admin_init', array($this, 'handle_actions'));
    }
    
    /**
     * Add admin page
     */
    public function add_admin_page() {
        // The post type already creates a menu, but we can add a custom page if needed
        // For now, we'll use the post type list page
    }
    
    /**
     * Handle admin actions
     */
    public function handle_actions() {
        // Handle toggle tutorial action (start/stop)
        if (isset($_GET['mac_toggle_tutorial']) && isset($_GET['tutorial_id'])) {
            $this->toggle_tutorial();
        }
        
        // Handle start tutorial action (from beginning)
        if (isset($_GET['mac_start_tutorial']) && isset($_GET['tutorial_id'])) {
            $this->start_tutorial();
        }
        
        // Handle resume tutorial action
        if (isset($_GET['mac_resume_tutorial']) && isset($_GET['tutorial_id'])) {
            $this->resume_tutorial();
        }
    }
    
    /**
     * Toggle tutorial (on/off widget)
     */
    private function toggle_tutorial() {
        if (!current_user_can('read')) {
            wp_die(__('You do not have permission to toggle tutorials.', 'mac-interactive-tutorials'));
        }
        
        $tutorial_id = absint($_GET['tutorial_id']);
        $nonce = sanitize_text_field($_GET['_wpnonce'] ?? '');
        
        if (!wp_verify_nonce($nonce, 'toggle_tutorial_' . $tutorial_id)) {
            wp_die(__('Security check failed.', 'mac-interactive-tutorials'));
        }
        
        $state_manager = new MAC_Tutorial_State_Manager();
        $active_state = $state_manager->get_active_tutorial();
        
        // If this tutorial is currently active, close it
        if ($active_state && $active_state['tutorial_id'] == $tutorial_id) {
            $state_manager->close_tutorial($tutorial_id);
        } else {
            // Otherwise, start/resume it
            $paused_state = $state_manager->get_paused_tutorial($tutorial_id);
            if ($paused_state) {
                // Resume from last step
                $current_step = $paused_state['current_step'] ?? 0;
                $state_manager->update_state($tutorial_id, $current_step, 'in-progress');
            } else {
                // Start from beginning
                $state_manager->update_state($tutorial_id, 0, 'in-progress');
            }
        }
        
        // Redirect back to tutorials list (no page change)
        wp_safe_redirect(admin_url('edit.php?post_type=mac_tutorial'));
        exit;
    }
    
    /**
     * Start tutorial (from beginning)
     */
    private function start_tutorial() {
        if (!current_user_can('read')) {
            wp_die(__('You do not have permission to start tutorials.', 'mac-interactive-tutorials'));
        }
        
        $tutorial_id = absint($_GET['tutorial_id']);
        $nonce = sanitize_text_field($_GET['_wpnonce'] ?? '');
        
        if (!wp_verify_nonce($nonce, 'start_tutorial_' . $tutorial_id)) {
            wp_die(__('Security check failed.', 'mac-interactive-tutorials'));
        }
        
        $state_manager = new MAC_Tutorial_State_Manager();
        
        // Always start from beginning (step 0)
        $state_manager->update_state($tutorial_id, 0, 'in-progress');
        
        // Redirect to tutorial's first step URL if available
        $steps = get_post_meta($tutorial_id, '_mac_tutorial_steps', true);
        if (!empty($steps) && is_array($steps) && !empty($steps[0]['target_url'])) {
            $target_url = $steps[0]['target_url'];
            if (!preg_match('/^https?:\/\//', $target_url)) {
                $target_url = admin_url($target_url);
            }
            wp_safe_redirect($target_url);
            exit;
        }
        
        // Otherwise redirect back to tutorials list
        wp_safe_redirect(admin_url('edit.php?post_type=mac_tutorial'));
        exit;
    }
    
    /**
     * Resume tutorial (from last step)
     */
    private function resume_tutorial() {
        if (!current_user_can('read')) {
            wp_die(__('You do not have permission to resume tutorials.', 'mac-interactive-tutorials'));
        }
        
        $tutorial_id = absint($_GET['tutorial_id']);
        $nonce = sanitize_text_field($_GET['_wpnonce'] ?? '');
        
        if (!wp_verify_nonce($nonce, 'resume_tutorial_' . $tutorial_id)) {
            wp_die(__('Security check failed.', 'mac-interactive-tutorials'));
        }
        
        $state_manager = new MAC_Tutorial_State_Manager();
        
        // Resume from last step
        $paused_state = $state_manager->get_paused_tutorial($tutorial_id);
        if ($paused_state) {
            $current_step = $paused_state['current_step'] ?? 0;
            $state_manager->update_state($tutorial_id, $current_step, 'in-progress');
            
            // Redirect to current step URL if available
            $steps = get_post_meta($tutorial_id, '_mac_tutorial_steps', true);
            if (!empty($steps) && is_array($steps) && isset($steps[$current_step]['target_url']) && !empty($steps[$current_step]['target_url'])) {
                $target_url = $steps[$current_step]['target_url'];
                if (!preg_match('/^https?:\/\//', $target_url)) {
                    $target_url = admin_url($target_url);
                }
                wp_safe_redirect($target_url);
                exit;
            }
        } else {
            // If no paused state, start from beginning
            $state_manager->update_state($tutorial_id, 0, 'in-progress');
            
            $steps = get_post_meta($tutorial_id, '_mac_tutorial_steps', true);
            if (!empty($steps) && is_array($steps) && !empty($steps[0]['target_url'])) {
                $target_url = $steps[0]['target_url'];
                if (!preg_match('/^https?:\/\//', $target_url)) {
                    $target_url = admin_url($target_url);
                }
                wp_safe_redirect($target_url);
                exit;
            }
        }
        
        // Otherwise redirect back to tutorials list
        wp_safe_redirect(admin_url('edit.php?post_type=mac_tutorial'));
        exit;
    }
    
    /**
     * Add custom columns to tutorials list
     */
    public function add_custom_columns($columns) {
        $new_columns = array();
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'title') {
                $new_columns['steps_count'] = __('Steps', 'mac-interactive-tutorials');
                $new_columns['difficulty'] = __('Difficulty', 'mac-interactive-tutorials');
            }
        }
        return $new_columns;
    }
    
    /**
     * Render custom column content
     */
    public function render_custom_columns($column, $post_id) {
        if ($column === 'steps_count') {
            $steps = get_post_meta($post_id, '_mac_tutorial_steps', true);
            $count = !empty($steps) && is_array($steps) ? count($steps) : 0;
            echo $count;
        } elseif ($column === 'difficulty') {
            $settings = get_post_meta($post_id, '_mac_tutorial_settings', true);
            $difficulty = $settings['difficulty'] ?? 'beginner';
            echo ucfirst($difficulty);
        }
    }
}

// Add custom columns
add_filter('manage_mac_tutorial_posts_columns', function($columns) {
    $admin = new MAC_Tutorial_Admin();
    return $admin->add_custom_columns($columns);
});

add_action('manage_mac_tutorial_posts_custom_column', function($column, $post_id) {
    $admin = new MAC_Tutorial_Admin();
    $admin->render_custom_columns($column, $post_id);
}, 10, 2);

// Add row actions
add_filter('post_row_actions', function($actions, $post) {
    if ($post->post_type === 'mac_tutorial' && $post->post_status === 'publish') {
        $state_manager = new MAC_Tutorial_State_Manager();
        $active_state = $state_manager->get_active_tutorial();
        $paused_state = $state_manager->get_paused_tutorial($post->ID);
        
        $tutorial_id = $post->ID;
        $toggle_nonce = wp_create_nonce('toggle_tutorial_' . $tutorial_id);
        $start_nonce = wp_create_nonce('start_tutorial_' . $tutorial_id);
        $resume_nonce = wp_create_nonce('resume_tutorial_' . $tutorial_id);
        
        $toggle_url = admin_url('admin.php?mac_toggle_tutorial=1&tutorial_id=' . $tutorial_id . '&_wpnonce=' . $toggle_nonce);
        $start_url = admin_url('admin.php?mac_start_tutorial=1&tutorial_id=' . $tutorial_id . '&_wpnonce=' . $start_nonce);
        $resume_url = admin_url('admin.php?mac_resume_tutorial=1&tutorial_id=' . $tutorial_id . '&_wpnonce=' . $resume_nonce);
        
        // Check if this tutorial is currently active (in-progress)
        $is_active = $active_state && $active_state['tutorial_id'] == $tutorial_id;
        
        // Check if this tutorial has been started before (has any state)
        $user_state = $state_manager->get_user_state();
        $has_state = isset($user_state[$tutorial_id]);
        
        // Toggle button (on/off) - always show
        if ($is_active) {
            $actions['toggle'] = '<a href="' . esc_url($toggle_url) . '">' . __('Stop Tutorial', 'mac-interactive-tutorials') . '</a>';
        } else {
            $actions['toggle'] = '<a href="' . esc_url($toggle_url) . '">' . __('Start Tutorial', 'mac-interactive-tutorials') . '</a>';
        }
        
        // Show Start and Resume buttons if tutorial has been started before
        if ($has_state) {
            $actions['start'] = '<a href="' . esc_url($start_url) . '">' . __('Restart Tutorial', 'mac-interactive-tutorials') . '</a>';
            if ($paused_state || !$is_active) {
                $actions['resume'] = '<a href="' . esc_url($resume_url) . '">' . __('Resume Tutorial', 'mac-interactive-tutorials') . '</a>';
            }
        }
    }
    return $actions;
}, 10, 2);

