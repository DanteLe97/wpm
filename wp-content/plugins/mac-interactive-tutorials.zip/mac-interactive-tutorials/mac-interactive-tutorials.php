<?php
/**
 * Plugin Name: MAC Interactive Tutorials
 * Plugin URI: https://macusaone.com
 * Description: Tạo và quản lý interactive tutorials tương tự Crocoblock Workflows, với khả năng tạo tutorials trực tiếp trong WordPress admin
 * Version: 1.0.0
 * Author: MAC USA One
 * Author URI: https://macusaone.com
 * Text Domain: mac-interactive-tutorials
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MAC_TUTORIALS_VERSION', '1.0.0');
define('MAC_TUTORIALS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MAC_TUTORIALS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MAC_TUTORIALS_PLUGIN_FILE', __FILE__);
define('MAC_TUTORIALS_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
class MAC_Interactive_Tutorials {
    
    /**
     * Plugin version
     */
    const VERSION = '1.0.0';
    
    /**
     * Plugin slug
     */
    const PLUGIN_SLUG = 'mac-interactive-tutorials';
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Post Type instance
     */
    public $post_type = null;
    
    /**
     * Meta Boxes instance
     */
    public $meta_boxes = null;
    
    /**
     * State Manager instance
     */
    public $state_manager = null;
    
    /**
     * Frontend instance
     */
    public $frontend = null;
    
    /**
     * Admin instance
     */
    public $admin = null;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init();
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        // Core classes
        require_once MAC_TUTORIALS_PLUGIN_DIR . 'includes/class-post-type.php';
        require_once MAC_TUTORIALS_PLUGIN_DIR . 'includes/class-meta-boxes.php';
        require_once MAC_TUTORIALS_PLUGIN_DIR . 'includes/class-state-manager.php';
        require_once MAC_TUTORIALS_PLUGIN_DIR . 'includes/class-frontend.php';
        
        // Admin classes
        if (is_admin()) {
            require_once MAC_TUTORIALS_PLUGIN_DIR . 'admin/class-admin.php';
        }
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Initialize core classes
        $this->post_type = new MAC_Tutorial_Post_Type();
        $this->meta_boxes = new MAC_Tutorial_Meta_Boxes();
        $this->state_manager = new MAC_Tutorial_State_Manager();
        $this->frontend = new MAC_Tutorial_Frontend();
        
        // Initialize admin
        if (is_admin()) {
            $this->admin = new MAC_Tutorial_Admin();
        }
        
        // Load text domain
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'mac-interactive-tutorials',
            false,
            dirname(MAC_TUTORIALS_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Get plugin URL
     */
    public function get_plugin_url() {
        return MAC_TUTORIALS_PLUGIN_URL;
    }
    
    /**
     * Get plugin path
     */
    public function get_plugin_path() {
        return MAC_TUTORIALS_PLUGIN_DIR;
    }
}

/**
 * Get plugin instance
 */
function mac_tutorials() {
    return MAC_Interactive_Tutorials::get_instance();
}

// Initialize plugin
mac_tutorials();

