=== Social Feed Aggregator ===
Contributors: you
Tags: social,instagram,facebook,gmb,google,mybusiness,feed,aggregator
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tổng hợp feed từ Instagram (Basic Display), Facebook Page và Google My Business (Places).
Cài đặt:
1. Upload plugin folder to /wp-content/plugins/
2. Activate plugin through the 'Plugins' screen in WordPress
3. Go to 'Social Feed' admin menu, fill App IDs / Tokens / API keys
4. Use 'Check' buttons to validate connections.
5. Use shortcode: [social_feed source="all" limit="5"]

Notes:
- This plugin is a starting skeleton. For production: implement secure storage for secrets, complete OAuth popup flows, error logging and rate-limit handling.
