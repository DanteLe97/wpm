<?php
/**
 * Plugin Name: Social Feed Aggregator
 * Description: Tổng hợp feed từ Instagram (Basic Display), Facebook Page và Google My Business (Places). Kèm trang cấu hình, nút kiểm tra kết nối, cron refresh token, and shortcode/widget.
 * Version: 0.2
 * Author: Generated
 */

if (!defined('ABSPATH')) exit;

class SFA {
    const VERSION = '0.2';
    const OPT_KEY = 'sfa_settings';

    public static function init(){
        add_action('init', [__CLASS__, 'register_post_type']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets']);
        add_shortcode('social_feed', [__CLASS__, 'shortcode_social_feed']);
        add_action('wp_ajax_sfa_check_connection', [__CLASS__, 'ajax_check_connection']);
        add_action('sfa_daily_tasks', [__CLASS__, 'daily_tasks']);

        // ensure daily schedule exists
        add_filter('cron_schedules', function($s){ if(!isset($s['every_five_minutes'])) $s['every_five_minutes']=['interval'=>300,'display'=>'Every 5 Minutes']; return $s; });
        if(!wp_next_scheduled('sfa_daily_tasks')) wp_schedule_event(time()+60, 'daily', 'sfa_daily_tasks');
    }

    /* ------------------ Storage helpers ------------------ */
    public static function get_settings(){ return get_option(self::OPT_KEY, []); }
    public static function update_setting($key, $val){ $all = self::get_settings(); $all[$key]=$val; update_option(self::OPT_KEY,$all); }

    /* ------------------ Admin ------------------ */
    public static function admin_menu(){ add_menu_page('Social Feed', 'Social Feed', 'manage_options', 'sfa_settings', [__CLASS__,'render_settings'], 'dashicons-share', 58); }

    public static function admin_assets($hook){ if(strpos($hook,'sfa_settings')===false) return; wp_enqueue_style('sfa-admin', plugin_dir_url(__FILE__).'assets/admin.css'); wp_enqueue_script('sfa-admin-js', plugin_dir_url(__FILE__).'assets/admin.js', ['jquery'], self::VERSION, true); wp_localize_script('sfa-admin-js','sfa_ajax',['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('sfa_nonce')]); }

    public static function register_settings(){ register_setting('sfa_group', self::OPT_KEY);
        add_settings_section('sfa_section_instagram','Instagram Settings',null,'sfa_instagram');
        add_settings_field('sfa_instagram_app_id','Instagram App ID', [__CLASS__,'field_text'], 'sfa_instagram','sfa_section_instagram',['label_for'=>'instagram_app_id','option_key'=>'instagram']);
        add_settings_field('sfa_instagram_app_secret','Instagram App Secret', [__CLASS__,'field_text_secret'], 'sfa_instagram','sfa_section_instagram',['label_for'=>'instagram_app_secret','option_key'=>'instagram']);
        add_settings_field('sfa_instagram_token','Instagram Access Token (long-lived)', [__CLASS__,'field_text'], 'sfa_instagram','sfa_section_instagram',['label_for'=>'instagram_access_token','option_key'=>'instagram']);

        add_settings_section('sfa_section_facebook','Facebook Settings',null,'sfa_facebook');
        add_settings_field('sfa_facebook_app_id','Facebook App ID', [__CLASS__,'field_text'], 'sfa_facebook','sfa_section_facebook',['label_for'=>'facebook_app_id','option_key'=>'facebook']);
        add_settings_field('sfa_facebook_app_secret','Facebook App Secret', [__CLASS__,'field_text_secret'], 'sfa_facebook','sfa_section_facebook',['label_for'=>'facebook_app_secret','option_key'=>'facebook']);
        add_settings_field('sfa_facebook_page_id','Facebook Page ID', [__CLASS__,'field_text'], 'sfa_facebook','sfa_section_facebook',['label_for'=>'facebook_page_id','option_key'=>'facebook']);
        add_settings_field('sfa_facebook_page_token','Facebook Page Access Token', [__CLASS__,'field_text'], 'sfa_facebook','sfa_section_facebook',['label_for'=>'facebook_page_token','option_key'=>'facebook']);

        add_settings_section('sfa_section_gmb','Google My Business / Places',null,'sfa_gmb');
        add_settings_field('sfa_gmb_api_key','Google API Key', [__CLASS__,'field_text'], 'sfa_gmb','sfa_section_gmb',['label_for'=>'gmb_api_key','option_key'=>'gmb']);
        add_settings_field('sfa_gmb_place_id','Place ID / Location ID', [__CLASS__,'field_text'], 'sfa_gmb','sfa_section_gmb',['label_for'=>'gmb_place_id','option_key'=>'gmb']);

        add_settings_section('sfa_section_general','General',null,'sfa_general');
        add_settings_field('sfa_general_item_limit','Items to fetch per source (default 20)', [__CLASS__,'field_text'], 'sfa_general','sfa_section_general',['label_for'=>'general_limit','option_key'=>'general']);
    }

    public static function field_text($args){ $opt = self::get_settings(); $group=$args['option_key']; $name = $args['label_for']; $val = isset($opt[$group][$name])?$opt[$group][$name]:''; printf('<input type="text" id="%1$s" name="%2$s[%3$s]" value="%4$s" class="regular-text"/>', esc_attr($name), esc_attr(self::OPT_KEY), esc_attr($group.'['.$name.']'), esc_attr($val)); }
    public static function field_text_secret($args){ $opt=self::get_settings(); $group=$args['option_key']; $name=$args['label_for']; $val = isset($opt[$group][$name])?$opt[$group][$name]:''; printf('<input type="password" id="%1$s" name="%2$s[%3$s]" value="%4$s" class="regular-text" autocomplete="new-password"/>', esc_attr($name), esc_attr(self::OPT_KEY), esc_attr($group.'['.$name.']'), esc_attr($val)); }

    public static function render_settings(){ if(!current_user_can('manage_options')) wp_die('Not allowed'); ?>
        <div class="wrap"><h1>Social Feed Aggregator</h1>
        <form method="post" action="options.php">
        <?php settings_fields('sfa_group'); do_settings_sections('sfa_instagram'); do_settings_sections('sfa_facebook'); do_settings_sections('sfa_gmb'); do_settings_sections('sfa_general'); submit_button(); ?>
        </form>
        <hr>
        <h2>Quick Checks</h2>
        <p>Use the buttons to verify each platform is connected correctly.</p>
        <button class="button button-primary sfa-check" data-source="instagram">Check Instagram</button> <span id="sfa-status-instagram" class="sfa-status"></span><br><br>
        <button class="button button-primary sfa-check" data-source="facebook">Check Facebook</button> <span id="sfa-status-facebook" class="sfa-status"></span><br><br>
        <button class="button button-primary sfa-check" data-source="gmb">Check Google My Business</button> <span id="sfa-status-gmb" class="sfa-status"></span>
        <hr>
        <h2>Manual OAuth (Instagram / Facebook)</h2>
        <p>Use these links to start OAuth flow in a popup. After completing, the plugin will save tokens.
        <br><a href="" id="sfa-instagram-connect" class="button">Connect Instagram</a>
        <a href="" id="sfa-facebook-connect" class="button">Connect Facebook Page</a></p>
        </div>
    <?php }

    /* ------------------ Post Type / Shortcode ------------------ */
    public static function register_post_type(){ register_post_type('social_feed_item',['labels'=>['name'=>'Social Feed Items'],'public'=>false,'show_ui'=>true,'supports'=>['title','editor']]); }

    public static function shortcode_social_feed($atts){ $atts=shortcode_atts(['source'=>'all','limit'=>5,'layout'=>'grid'],$atts,'social_feed'); $args=['post_type'=>'social_feed_item','posts_per_page'=>intval($atts['limit'])]; if($atts['source']!=='all') $args['meta_query']=[['key'=>'_sfi_origin','value'=>sanitize_text_field($atts['source'])]]; $q=new WP_Query($args); ob_start(); echo '<div class="sfa-grid">'; while($q->have_posts()){$q->the_post(); $media=get_post_meta(get_the_ID(),'_sfi_media',true); $media = $media ? json_decode($media,true) : []; ?>
        <article class="sfa-item"><a href="<?php echo esc_url(get_post_meta(get_the_ID(),'_sfi_permalink',true)); ?>" target="_blank"><?php if(!empty($media[0])): ?><img src="<?php echo esc_url($media[0]); ?>" alt="" style="max-width:100%"/><?php endif; ?><h4><?php the_title(); ?></h4><div class="sfa-excerpt"><?php the_excerpt(); ?></div></a></article>
    <?php } wp_reset_postdata(); echo '</div>'; return ob_get_clean(); }

    /* ------------------ AJAX Check ------------------ */
    public static function ajax_check_connection(){ check_ajax_referer('sfa_nonce'); if(!current_user_can('manage_options')) wp_send_json_error('no_permission'); $src = isset($_POST['source'])?sanitize_text_field($_POST['source']):''; $settings=self::get_settings(); switch($src){ case 'instagram': $inst=new SFA_Instagram($settings); $res=$inst->check_connection(); break; case 'facebook': $fb=new SFA_Facebook($settings); $res=$fb->check_connection(); break; case 'gmb': $gmb=new SFA_GMB($settings); $res=$gmb->check_connection(); break; default: wp_send_json_error(['message'=>'unknown_source']); }
        if(isset($res['ok']) && $res['ok']) wp_send_json_success($res); wp_send_json_error($res);
    }

    /* ------------------ Daily Tasks ------------------ */
    public static function daily_tasks(){ $settings=self::get_settings(); // refresh instagram
        if(!empty($settings['instagram']['instagram_access_token']) && !empty($settings['instagram']['instagram_expires_at'])){
            if(time() > ($settings['instagram']['instagram_expires_at'] - DAY_IN_SECONDS*7)){
                $inst = new SFA_Instagram($settings);
                $inst->refresh_long_lived_token();
            }
        }
        // validate facebook token
        if(!empty($settings['facebook']['facebook_page_token'])){
            $fb = new SFA_Facebook($settings);
            $fb->validate_page_token();
        }
        // fetch posts
        $fetcher = new SFA_Fetcher($settings);
        $fetcher->run_all();
    }
}

/* ======================== Instagram helper ======================== */
class SFA_Instagram {
    private $settings;
    public function __construct($settings=[]){ $this->settings = isset($settings['instagram']) ? $settings['instagram'] : []; }
    public function get_connect_url(){ $app_id = $this->settings['instagram_app_id'] ?? ''; $redirect = admin_url('admin.php?page=sfa_settings'); $url = "https://api.instagram.com/oauth/authorize?client_id=".urlencode($app_id) ."&redirect_uri=".urlencode($redirect) ."&scope=user_profile,user_media&response_type=code"; return $url; }
    public function exchange_code_for_token($code){ // exchange code to short-lived token
        $app_id = $this->settings['instagram_app_id'] ?? ''; $app_secret = $this->settings['instagram_app_secret'] ?? ''; $redirect = admin_url('admin.php?page=sfa_settings'); $url = 'https://api.instagram.com/oauth/access_token'; $body = ['client_id'=>$app_id,'client_secret'=>$app_secret,'grant_type'=>'authorization_code','redirect_uri'=>$redirect,'code'=>$code]; $r = wp_remote_post($url,['body'=>$body,'timeout'=>20]); if(is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_message()]; $b=json_decode(wp_remote_retrieve_body($r),true); if(isset($b['access_token'])){
            // exchange short token to long
            $short = $b['access_token']; $ex = wp_remote_get('https://graph.instagram.com/access_token?grant_type=ig_exchange_token&client_secret='.urlencode($app_secret).'&access_token='.urlencode($short)); if(is_wp_error($ex)) return ['ok'=>false,'error'=>$ex->get_message()]; $bb=json_decode(wp_remote_retrieve_body($ex),true); if(isset($bb['access_token'])){ $inst = SFA::get_settings(); $inst['instagram']['instagram_access_token']=$bb['access_token']; $inst['instagram']['instagram_expires_at']=time()+intval($bb['expires_in']); update_option(SFA::OPT_KEY,$inst); return ['ok'=>true]; }
        }
        return ['ok'=>false,'body'=>$b]; }
    public function refresh_long_lived_token(){ $settings = SFA::get_settings(); $token = $settings['instagram']['instagram_access_token'] ?? ''; if(!$token) return ['ok'=>false,'message'=>'no_token']; $url = 'https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token='.urlencode($token); $r = wp_remote_get($url,['timeout'=>20]); if(is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_message()]; $b=json_decode(wp_remote_retrieve_body($r),true); if(isset($b['access_token'])){ $settings = SFA::get_settings(); $settings['instagram']['instagram_access_token']=$b['access_token']; $settings['instagram']['instagram_expires_at']=time()+intval($b['expires_in']); update_option(SFA::OPT_KEY,$settings); return ['ok'=>true]; } return ['ok'=>false,'body'=>$b]; }
    public function check_connection(){ $settings = SFA::get_settings(); $token = $settings['instagram']['instagram_access_token'] ?? ''; if(!$token) return ['ok'=>false,'message'=>'no_token']; $url = 'https://graph.instagram.com/me?fields=id,username&access_token='.urlencode($token); $r=wp_remote_get($url,['timeout'=>10]); if(is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_message()]; $b=json_decode(wp_remote_retrieve_body($r),true); if(isset($b['id'])) return ['ok'=>true,'id'=>$b['id'],'username'=>$b['username']]; return ['ok'=>false,'body'=>$b]; }
}

/* ======================== Facebook helper ======================== */
class SFA_Facebook {
    private $settings;
    public function __construct($settings=[]){ $this->settings = isset($settings['facebook']) ? $settings['facebook'] : []; }
    public function get_connect_url(){ $app_id = $this->settings['facebook_app_id'] ?? ''; $redirect = admin_url('admin.php?page=sfa_settings'); $scopes='pages_read_engagement,pages_read_user_content'; $url = 'https://www.facebook.com/v17.0/dialog/oauth?client_id='.urlencode($app_id).'&redirect_uri='.urlencode($redirect).'&scope='.$scopes; return $url; }
    public function check_connection(){ $settings = SFA::get_settings(); $page_token = $settings['facebook']['facebook_page_token'] ?? ''; $page_id = $settings['facebook']['facebook_page_id'] ?? ''; if(!$page_token || !$page_id) return ['ok'=>false,'message'=>'no_token_or_pageid']; $url = 'https://graph.facebook.com/v17.0/'.urlencode($page_id).'?fields=name&access_token='.urlencode($page_token); $r=wp_remote_get($url,['timeout'=>10]); if(is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_message()]; $b=json_decode(wp_remote_retrieve_body($r),true); if(isset($b['name'])) return ['ok'=>true,'name'=>$b['name']]; return ['ok'=>false,'body'=>$b]; }
    public function validate_page_token(){ // optional: call debug_token using app access token
        $settings = SFA::get_settings(); $token = $settings['facebook']['facebook_page_token'] ?? ''; if(!$token) return false; $app_id = $settings['facebook']['facebook_app_id'] ?? ''; $app_secret = $settings['facebook']['facebook_app_secret'] ?? ''; if(!$app_id || !$app_secret) return false; $app_token = $app_id . '|' . $app_secret; $url = 'https://graph.facebook.com/debug_token?input_token='.urlencode($token).'&access_token='.urlencode($app_token); $r=wp_remote_get($url,['timeout'=>10]); if(is_wp_error($r)) return false; $b=json_decode(wp_remote_retrieve_body($r),true); return $b; }
}

/* ======================== GMB / Places helper ======================== */
class SFA_GMB {
    private $settings;
    public function __construct($settings=[]){ $this->settings = isset($settings['gmb']) ? $settings['gmb'] : []; }
    public function check_connection(){ $settings = SFA::get_settings(); $key = $settings['gmb']['gmb_api_key'] ?? ''; $place = $settings['gmb']['gmb_place_id'] ?? ''; if(!$key || !$place) return ['ok'=>false,'message'=>'no_key_or_placeid']; $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id='.urlencode($place).'&key='.urlencode($key); $r=wp_remote_get($url,['timeout'=>10]); if(is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_message()]; $b=json_decode(wp_remote_retrieve_body($r),true); if(isset($b['result'])) return ['ok'=>true,'name'=>$b['result']['name']]; return ['ok'=>false,'body'=>$b]; }
}

/* ======================== Fetcher ======================== */
class SFA_Fetcher {
    private $settings;
    public function __construct($settings=[]){ $this->settings = $settings ?: SFA::get_settings(); }
    public function run_all(){ $this->fetch_instagram(); $this->fetch_facebook(); $this->fetch_gmb(); }

    private function fetch_instagram(){ $s = $this->settings['instagram'] ?? []; $token = $s['instagram_access_token'] ?? ''; if(!$token) return; $limit = intval($this->settings['general']['general_limit'] ?? 20); $url = 'https://graph.instagram.com/me/media?fields=id,caption,media_url,permalink,timestamp,media_type&access_token='.urlencode($token).'&limit='.intval($limit);
        $r=wp_remote_get($url,['timeout'=>20]); if(is_wp_error($r)) return; $b=json_decode(wp_remote_retrieve_body($r),true); if(empty($b['data'])) return; foreach($b['data'] as $p){ $item=['origin'=>'instagram','origin_id'=>$p['id'],'message'=>$p['caption'] ?? '','media'=> isset($p['media_url'])?[$p['media_url']]:[],'permalink'=>$p['permalink'] ?? '','created_time'=>$p['timestamp'] ?? current_time('mysql'),'raw'=>$p]; $this->upsert_item($item); } }

    private function fetch_facebook(){ $s=$this->settings['facebook'] ?? []; $token = $s['facebook_page_token'] ?? ''; $page = $s['facebook_page_id'] ?? ''; if(!$token || !$page) return; $limit = intval($this->settings['general']['general_limit'] ?? 20); $url = 'https://graph.facebook.com/v17.0/'.urlencode($page).'/posts?fields=message,full_picture,permalink_url,created_time,id&limit='.intval($limit).'&access_token='.urlencode($token);
        $r=wp_remote_get($url,['timeout'=>20]); if(is_wp_error($r)) return; $b=json_decode(wp_remote_retrieve_body($r),true); if(empty($b['data'])) return; foreach($b['data'] as $p){ $media = []; if(!empty($p['full_picture'])) $media[]=$p['full_picture']; $item=['origin'=>'facebook','origin_id'=>$p['id'],'message'=>$p['message'] ?? '','media'=>$media,'permalink'=>$p['permalink_url'] ?? '','created_time'=>$p['created_time'] ?? current_time('mysql'),'raw'=>$p]; $this->upsert_item($item); } }

    private function fetch_gmb(){ $s=$this->settings['gmb'] ?? []; $key = $s['gmb_api_key'] ?? ''; $place = $s['gmb']['gmb_place_id'] ?? ''; if(!$key || !$place) return; $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id='.urlencode($place).'&fields=name,review,user_ratings_total&key='.urlencode($key); $r=wp_remote_get($url,['timeout'=>20]); if(is_wp_error($r)) return; $b=json_decode(wp_remote_retrieve_body($r),true); if(empty($b['result'])) return; // create a single item capturing summary
        $res = $b['result']; $item=['origin'=>'gmb','origin_id'=>$place,'message'=>'Google Place: '.($res['name'] ?? '').' - Reviews: '.($res['user_ratings_total'] ?? 0),'media'=>[],'permalink'=>'','created_time'=>current_time('mysql'),'raw'=>$res]; $this->upsert_item($item); }

    private function upsert_item($item){ // find existing
        $existing = get_posts(['post_type'=>'social_feed_item','meta_query'=>[['key'=>'_sfi_origin','value'=>$item['origin']],['key'=>'_sfi_origin_id','value'=>$item['origin_id']]],'posts_per_page'=>1]); $post_data=['post_title'=>wp_trim_words($item['message'],12,'...'),'post_content'=>$item['message'],'post_status'=>'publish','post_type'=>'social_feed_item','post_date'=>date('Y-m-d H:i:s', strtotime($item['created_time']))]; if($existing){ $post_id = $existing[0]->ID; $post_data['ID']=$post_id; wp_update_post($post_data); } else { $post_id = wp_insert_post($post_data); }
        if($post_id){ update_post_meta($post_id,'_sfi_origin',$item['origin']); update_post_meta($post_id,'_sfi_origin_id',$item['origin_id']); update_post_meta($post_id,'_sfi_media',wp_json_encode($item['media'])); update_post_meta($post_id,'_sfi_permalink',$item['permalink']); update_post_meta($post_id,'_sfi_raw',wp_json_encode($item['raw'])); }
    }
}

/* ======================== Boot ======================== */
SFA::init();

/* ======================== Minimal assets (for user to create) ======================== */
/* Create two files in assets/:

assets/admin.js
jQuery(document).ready(function($){
    $('.sfa-check').on('click', function(e){
        var src = $(this).data('source');
        var $status = $('#sfa-status-'+src);
        $status.text('Checking...');
        $.post(ajaxurl, { action: 'sfa_check_connection', _ajax_nonce: sfa_ajax.nonce, source: src}, function(resp){
            if(resp.success){ $status.text('OK: '+ JSON.stringify(resp.data)); } else { $status.text('Error: '+ JSON.stringify(resp.data)); }
        }).fail(function(){ $status.text('Request failed'); });
    });
});

assets/admin.css
.sfa-grid{display:flex;flex-wrap:wrap;gap:12px}
.sfa-item{width:200px;border:1px solid #eee;padding:8px;border-radius:6px}

*/
?>
