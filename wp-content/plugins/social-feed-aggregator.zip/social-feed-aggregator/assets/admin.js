jQuery(document).ready(function($){
    $('.sfa-check').on('click', function(e){
        var src = $(this).data('source');
        var $status = $('#sfa-status-'+src);
        $status.text('Checking...');
        $.post(ajaxurl, { action: 'sfa_check_connection', _ajax_nonce: sfa_ajax.nonce, source: src}, function(resp){
            if(resp.success){ $status.text('OK: '+ JSON.stringify(resp.data)); } else { $status.text('Error: '+ JSON.stringify(resp.data)); }
        }).fail(function(){ $status.text('Request failed'); });
    });
});
