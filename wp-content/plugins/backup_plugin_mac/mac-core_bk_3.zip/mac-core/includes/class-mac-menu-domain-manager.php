<?php
/**
 * MAC Menu Domain Manager Class
 * 
 * This class was moved from mac-menu plugin to provide compatibility
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// MAC Menu API Constants - Only define if MAC Menu is not installed
if (!file_exists(WP_PLUGIN_DIR . '/mac-menu/mac-menu.php')) {
    if (!defined('MAC_MENU_VALIDATE_KEY')) {
        define('MAC_MENU_VALIDATE_KEY', 'https://wpm.macusaone.com/api/v1/menu-license/validate-key');
    }
    if (!defined('MAC_MENU_VALIDATE_URL')) {
        define('MAC_MENU_VALIDATE_URL', 'https://wpm.macusaone.com/api/v1/menu-license/validate-url');
    }
    if (!defined('MAC_MENU_REGISTER_DOMAIN')) {
        define('MAC_MENU_REGISTER_DOMAIN', 'https://wpm.macusaone.com/api/v1/menu-license/register-domain');
    }
}

// Only define the class if MAC Menu is not installed to avoid conflicts
if (!file_exists(WP_PLUGIN_DIR . '/mac-menu/mac-menu.php') && !class_exists('MAC_Menu_Domain_Manager')) {
class MAC_Menu_Domain_Manager {
    private static $instance = null;
    private $current_version;
    private $plugin_file;

    // Constants
    const DEFAULT_VERSION = '1.6.2';
    const TIMEOUT = 45;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
        $this->init_hooks();
    }

    private function init() {
        $this->plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $this->current_version = $this->get_plugin_version();
        
        error_log('MAC Menu Domain Manager: Plugin file: ' . $this->plugin_file);
        error_log('MAC Menu Domain Manager: Current version: ' . $this->current_version);
        
        // Fix options if they were incorrectly initialized with '0'
        $this->fix_options_if_needed();
    }

    private function init_hooks() {
        // Hooks are now handled by compatibility layer to avoid conflicts
        // add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        // add_action('wp_ajax_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
        // add_action('wp_ajax_nopriv_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
        
        // Schedule periodic domain check
        if (!wp_next_scheduled('mac_menu_domain_check')) {
            wp_schedule_event(time(), 'hourly', 'mac_menu_domain_check');
        }
        
        add_action('mac_menu_domain_check', array($this, 'handle_check_request_url'));
        
        // Also check on admin_init if no valid key exists
        // DISABLED: Now using manual check via button
        // add_action('admin_init', array($this, 'check_domain_if_needed'));
        
        // Add AJAX handler for test function
        add_action('wp_ajax_mac_core_test_validate_url', array($this, 'handle_test_validate_url_ajax'));
    }

    private function get_plugin_version() {
        if (is_admin() && function_exists('get_plugin_data')) {
            $plugin_data = get_plugin_data($this->plugin_file);
            return isset($plugin_data['Version']) ? $plugin_data['Version'] : self::DEFAULT_VERSION;
        }
        return self::DEFAULT_VERSION;
    }

    public function enqueue_scripts() {
        wp_localize_script('admin-script', 'kvp_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac_menu_domain_nonce')
        ));
    }

    public function handle_check_request($key_domain_check = null) {
        error_log('=== MAC Menu: handle_check_request() CALLED ===');
        error_log('MAC Menu: handle_check_request - Key: ' . ($key_domain_check ?: 'null'));
        error_log('MAC Menu: handle_check_request - Timestamp: ' . date('Y-m-d H:i:s'));
        error_log('MAC Menu: handle_check_request - Backtrace: ' . $this->get_backtrace());
        
        if (empty($key_domain_check)) {
            error_log('MAC Menu: handle_check_request - Empty key, resetting options');
            $this->reset_domain_options();
            error_log('MAC Menu: handle_check_request() ENDING - Empty key');
            return;
        }

        $api_url = MAC_MENU_VALIDATE_KEY;
        $domain = get_site_url() . '/';
        
        error_log('MAC Menu: handle_check_request - Calling API: ' . $api_url);
        error_log('MAC Menu: handle_check_request - Domain: ' . $domain);
        error_log('MAC Menu: handle_check_request - Version: ' . $this->current_version);
        
        $response = $this->make_api_request($api_url, array(
            'key' => $key_domain_check,
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            error_log('MAC Menu: handle_check_request - API Error: ' . $response->get_error_message());
            error_log('MAC Menu: handle_check_request() ENDING - API Error');
            return;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('MAC Menu: handle_check_request - Empty response from API');
            error_log('MAC Menu: handle_check_request() ENDING - Empty response');
            return;
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('MAC Menu: handle_check_request - JSON parse error');
            error_log('MAC Menu: handle_check_request() ENDING - JSON Error');
            return;
        }

        error_log('MAC Menu: handle_check_request - Calling process_domain_response()');
        $this->process_domain_response($data, $key_domain_check);
        error_log('MAC Menu: handle_check_request() ENDING - Success');
    }

    public function handle_check_request_url() {
        $api_url = MAC_MENU_VALIDATE_URL;
        $domain = get_site_url() . '/';
        
        // Log what we're sending to CRM
        $request_data = array(
            'url' => $domain,
            'menuversion' => $this->current_version
        );
        error_log('=== MAC Menu: Sending to CRM ===');
        error_log('URL: ' . $api_url);
        error_log('Data: ' . json_encode($request_data));
        
        $response = $this->make_api_request($api_url, $request_data);

        if (is_wp_error($response)) {
            error_log('CRM Response: ERROR - ' . $response->get_error_message());
            return;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('CRM Response: EMPTY');
            return;
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('CRM Response: JSON ERROR - ' . json_last_error_msg());
            return;
        }

        // Log what we received from CRM
        error_log('=== MAC Menu: Received from CRM ===');
        error_log('Response: ' . json_encode($data));
        
        $this->process_domain_url_response($data);
    }

    public function force_sync_license() {
        // Public method để force sync license với CRM
        error_log('MAC Menu: Force sync requested by admin');
        $this->force_sync_with_crm();
    }
    
    public function check_domain_if_needed() {
        error_log('=== MAC Menu: check_domain_if_needed() CALLED ===');
        error_log('MAC Menu: check_domain_if_needed - Timestamp: ' . date('Y-m-d H:i:s'));
        error_log('MAC Menu: check_domain_if_needed - Backtrace: ' . $this->get_backtrace());
        
        // Only check if we're in admin and not doing AJAX
        if (!is_admin() || (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
            error_log('MAC Menu: check_domain_if_needed - Not in admin or doing AJAX, skipping');
            error_log('MAC Menu: check_domain_if_needed() ENDING - Skipped');
            return;
        }
        
        // Check if we have a valid key
        $current_key = get_option('mac_domain_valid_key', '');
        $current_status = get_option('mac_domain_valid_status', '');
        
        // Clean up invalid values (0, null, etc.)
        if ($current_key === '0' || $current_key === null) {
            $current_key = '';
        }
        if ($current_status === '0' || $current_status === null) {
            $current_status = '';
        }
        
        error_log('MAC Menu: check_domain_if_needed - Current key: ' . ($current_key ?: 'empty'));
        error_log('MAC Menu: check_domain_if_needed - Current status: ' . ($current_status ?: 'empty'));
        
        // If no key or invalid status, check with CRM
        if (empty($current_key) || $current_status !== 'activate') {
            error_log('MAC Menu: check_domain_if_needed - No valid key or invalid status detected');
            
            // Check last sync time to avoid too frequent requests
            $last_sync = get_option('mac_domain_last_sync', 0);
            $current_time = time();
            
            // Ensure $last_sync is an integer
            $last_sync = intval($last_sync);
            
            $time_diff = $current_time - $last_sync;
            
            error_log('MAC Menu: check_domain_if_needed - Last sync: ' . date('Y-m-d H:i:s', $last_sync));
            error_log('MAC Menu: check_domain_if_needed - Current time: ' . date('Y-m-d H:i:s', $current_time));
            error_log('MAC Menu: check_domain_if_needed - Time difference: ' . $time_diff . ' seconds');
            
            // Only check if it's been more than 1 hour since last check
            if ($time_diff > 3600) {
                error_log('MAC Menu: check_domain_if_needed - More than 1 hour passed, calling handle_check_request_url()');
                $this->handle_check_request_url();
                error_log('MAC Menu: check_domain_if_needed() ENDING - URL check called');
            } else {
                error_log('MAC Menu: check_domain_if_needed - Less than 1 hour passed, skipping check');
                error_log('MAC Menu: check_domain_if_needed() ENDING - Skipped (time limit)');
            }
        } else {
            error_log('MAC Menu: check_domain_if_needed - Valid key and status found, no need to check');
            error_log('MAC Menu: check_domain_if_needed() ENDING - No action needed');
        }
    }
    
    public function handle_ajax_request() {
        // Debug: Log the nonce for debugging
        error_log('MAC Menu AJAX Request - POST data: ' . print_r($_POST, true));
        
        // Verify nonce if it exists
        if (isset($_POST['nonce'])) {
            if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
                error_log('MAC Menu AJAX Request - Nonce verification failed');
                wp_send_json_error('Invalid security token.');
                return;
            }
        }

        if (!isset($_POST['key'])) {
            wp_send_json_error('Key is required.');
            return;
        }

        $key = sanitize_text_field($_POST['key']);
        $api_url = MAC_MENU_REGISTER_DOMAIN;
        $domain = get_site_url() . '/';

        $response = $this->make_api_request($api_url, array(
            'key' => $key,
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            wp_send_json_error('API request failed: ' . $response->get_error_message());
            return;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            wp_send_json_error('Empty response from server.');
            return;
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error('Invalid response format from server.');
            return;
        }

        $this->process_ajax_response($data);
    }

    private function make_api_request($url, $body) {
        $response = wp_remote_post($url, array(
            'method' => 'POST',
            'body' => $body,
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded'
            )
        ));
        
        return $response;
    }

    private function process_domain_response($data, $key = null) {
        error_log('=== MAC Menu: process_domain_response() CALLED ===');
        error_log('MAC Menu: process_domain_response - Input data: ' . print_r($data, true));
        error_log('MAC Menu: process_domain_response - Input key: ' . ($key ?: 'null'));
        error_log('MAC Menu: process_domain_response - Timestamp: ' . date('Y-m-d H:i:s'));
        error_log('MAC Menu: process_domain_response - Backtrace: ' . $this->get_backtrace());
        
        // Kiểm tra xem có phải lỗi API không
        if ($this->is_api_error($data)) {
            error_log('MAC Menu: CASE 1 - API Error detected, keeping existing options');
            error_log('MAC Menu: process_domain_response() ENDING - API Error');
            return; // Không reset khi API lỗi
        }
        
        // Kiểm tra key có hợp lệ không
        if (!isset($data['valid']) || !$data['valid']) {
            error_log('MAC Menu: CASE 2 - Invalid key detected (valid=false or not set)');
            
            // Nếu có license active, cần thêm kiểm tra để tránh reset nhầm
            if ($this->should_preserve_license()) {
                error_log('MAC Menu: CASE 2a - Invalid key but active license exists, double-checking before reset');
                // Có thể thêm logic kiểm tra thêm ở đây
            }
            
            error_log('MAC Menu: CASE 2b - Invalid key confirmed, resetting options');
            $this->reset_domain_options();
            error_log('MAC Menu: process_domain_response() ENDING - Invalid key, options reset');
            return;
        }

        error_log('MAC Menu: CASE 3 - Valid key detected, checking status changes');
        $current_status = get_option('mac_domain_valid_status', '');
        
        // Clean up invalid values (0, null, etc.)
        if ($current_status === '0' || $current_status === null) {
            $current_status = '';
        }
        
        error_log('MAC Menu: Current status in DB: ' . $current_status);
        error_log('MAC Menu: New status from CRM: ' . $data['statusDomain']);
        
        if ($current_status !== $data['statusDomain']) {
            error_log('MAC Menu: CASE 3a - Status changed, updating options');
            $this->update_domain_options($data);
            $this->reload_page();
            error_log('MAC Menu: process_domain_response() ENDING - Status updated');
        } else {
            error_log('MAC Menu: CASE 3b - Status unchanged, no action needed');
            error_log('MAC Menu: process_domain_response() ENDING - No changes');
        }
    }
    
    private function process_domain_url_response($data) {
        // Kiểm tra xem có phải lỗi API không
        if ($this->is_api_error($data)) {
            error_log('CRM Result: API Error - keeping existing options');
            return;
        }
        
        // Kiểm tra domain có được đăng ký trong CRM không
        if (!isset($data['valid']) || !$data['valid']) {
            error_log('CRM Result: Domain not found - resetting options');
            $this->reset_domain_options();
            return;
        }
        
        // Nếu domain hợp lệ nhưng không có key, cũng reset
        if (!isset($data['keyDomain']) || empty($data['keyDomain'])) {
            error_log('CRM Result: Domain valid but no key assigned - resetting options');
            $this->reset_domain_options();
            return;
        }
        
        // Kiểm tra key hiện tại trong database có khớp với key từ CRM không
        $current_key = get_option('mac_domain_valid_key', '');
        
        // Clean up invalid values (0, null, etc.)
        if ($current_key === '0' || $current_key === null) {
            $current_key = '';
        }
        
        if (!empty($current_key) && $current_key !== $data['keyDomain']) {
            error_log('CRM Result: Key mismatch - resetting options');
            $this->reset_domain_options();
            return;
        }
        
        // Nếu domain và key đều hợp lệ, cập nhật options
        $current_status = get_option('mac_domain_valid_status', '');
        
        // Clean up invalid values (0, null, etc.)
        if ($current_status === '0' || $current_status === null) {
            $current_status = '';
        }
        
        if ($current_status !== $data['statusDomain']) {
            error_log('CRM Result: Status changed - updating options');
            $this->update_domain_options($data);
            $this->reload_page();
        } else {
            error_log('CRM Result: No changes needed');
        }
    }
    
    private function is_api_error($data) {
        // Kiểm tra các trường hợp lỗi API
        if (empty($data)) {
            return true; // Response rỗng
        }
        
        // Kiểm tra có phải error response không
        if (isset($data['error']) || isset($data['error_code'])) {
            return true;
        }
        
        // Kiểm tra có phải HTML error page không
        if (is_string($data) && (strpos($data, '<html') !== false || strpos($data, 'error') !== false)) {
            return true;
        }
        
        // Kiểm tra có phải JSON parse error không
        if (json_last_error() !== JSON_ERROR_NONE) {
            return true;
        }
        
        return false;
    }

    private function process_ajax_response($data) {
        // Debug: Log the response data
        error_log('MAC Menu Process AJAX Response - Data: ' . print_r($data, true));
        
        if (!isset($data['valid']) || !$data['valid']) {
            error_log('MAC Menu Process AJAX Response - Invalid key');
            wp_send_json_error($data['message'] ?? 'Invalid key.');
            return;
        }

        error_log('MAC Menu Process AJAX Response - Valid key, updating options');
        $this->update_domain_options($data);
        
        // Send a simple success message instead of an object
        wp_send_json_success($data['message'] ?? 'Key is valid!');
    }

    private function update_domain_options($data) {
        update_option('mac_domain_valid_key', $data['keyDomain']);
        update_option('mac_domain_valid_status', $data['statusDomain']);
        update_option('mac_domain_last_sync', time());

        if (in_array($data['statusDomain'], array('activate', 'deactivate'))) {
            update_option('mac_menu_github_key', $data['keytoken']);
        } else {
            update_option('mac_menu_github_key', null);
        }
        
        error_log('Updated: Key=' . $data['keyDomain'] . ', Status=' . $data['statusDomain'] . ', GitHub=' . ($data['keytoken'] ?? 'null'));
    }

    private function reset_domain_options() {
        update_option('mac_domain_valid_key', null);
        update_option('mac_domain_valid_status', null);
        update_option('mac_menu_github_key', null);
        update_option('mac_domain_last_sync', time());
        
        error_log('Reset: All options cleared');
    }
    
    private function has_active_license() {
        $status = get_option('mac_domain_valid_status', '');
        return $status === 'activate';
    }
    
    private function should_preserve_license() {
        // Nếu có license active, chỉ reset khi chắc chắn key invalid
        if ($this->has_active_license()) {
            error_log('MAC Menu: Active license detected, being cautious about reset');
            return true;
        }
        return false;
    }
    
    private function check_crm_sync_status() {
        // Kiểm tra xem plugin có đồng bộ với CRM không
        $current_key = get_option('mac_domain_valid_key', '');
        $current_status = get_option('mac_domain_valid_status', '');
        
        if (empty($current_key) || empty($current_status)) {
            error_log('MAC Menu: No local license data found');
            return false;
        }
        
        error_log('MAC Menu: Local license - Key: ' . $current_key . ', Status: ' . $current_status);
        return true;
    }
    
    private function force_sync_with_crm() {
        // Force sync bằng cách gọi URL check
        error_log('MAC Menu: Force syncing with CRM...');
        
        // Update last sync time before force sync
        update_option('mac_domain_last_sync', time());
        error_log('MAC Menu: Last sync time updated before force sync: ' . date('Y-m-d H:i:s'));
        
        $this->handle_check_request_url();
    }

    private function reload_page() {
        // Check if we're already on a reloaded page to prevent infinite loop
        if (isset($_GET['reloaded']) && $_GET['reloaded'] == '1') {
            error_log('MAC Menu: Already reloaded, skipping to prevent infinite loop');
            return;
        }
        
        // Never reload during plugin activation
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 15);
        foreach ($backtrace as $trace) {
            if (isset($trace['function']) && in_array($trace['function'], ['activate_plugin', 'plugin_activate'])) {
                return; // Don't reload during plugin activation
            }
        }
        
        // Only reload if we're in admin context and not doing AJAX
        if (!is_admin() || (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
            error_log('MAC Menu: Not in admin or doing AJAX, skipping reload');
            return;
        }
        
        // Only reload if we're in a proper admin page context
        if (isset($_GET['page']) && strpos($_GET['page'], 'mac-') === 0) {
            error_log('MAC Menu: Redirecting to reloaded page');
            if (!headers_sent()) {
                wp_redirect(admin_url('admin.php?page=' . $_GET['page'] . '&reloaded=1'));
                exit;
            } else {
                ?>
                <script type="text/javascript">
                    window.location.reload();
                </script>
                <?php
            }
        }
    }
    
    /**
     * Get backtrace for debugging
     */
    private function get_backtrace() {
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
        $trace_string = '';
        foreach ($backtrace as $i => $trace) {
            if ($i === 0) continue; // Skip current function
            $trace_string .= "\n" . ($i) . ". " . 
                (isset($trace['class']) ? $trace['class'] . '::' : '') . 
                $trace['function'] . '() in ' . 
                (isset($trace['file']) ? basename($trace['file']) : 'unknown') . 
                ':' . (isset($trace['line']) ? $trace['line'] : 'unknown');
        }
        return $trace_string;
    }
    
    /**
     * Fix options if they were incorrectly initialized with '0'
     */
    private function fix_options_if_needed() {
        error_log('=== MAC Menu: Checking and fixing options ===');
        
        // Get current values
        $current_key = get_option('mac_domain_valid_key', '');
        $current_status = get_option('mac_domain_valid_status', '');
        
        error_log('MAC Menu: Current key: ' . $current_key);
        error_log('MAC Menu: Current status: ' . $current_status);
        
        // Fix key if it's '0'
        if ($current_key === '0') {
            update_option('mac_domain_valid_key', '');
            error_log('MAC Menu: Fixed mac_domain_valid_key from "0" to empty');
        }
        
        // Fix status if it's '0'
        if ($current_status === '0') {
            update_option('mac_domain_valid_status', '');
            error_log('MAC Menu: Fixed mac_domain_valid_status from "0" to empty');
        }
        
        error_log('=== MAC Menu: Options check completed ===');
    }
    
    /**
     * Test function to send API call to MAC_MENU_VALIDATE_URL
     */
    public function testValidateUrl() {
        error_log('=== MAC Menu: testValidateUrl() CALLED ===');
        error_log('MAC Menu: testValidateUrl - Timestamp: ' . date('Y-m-d H:i:s'));
        
        // Get the API URL
        $api_url = MAC_MENU_VALIDATE_URL;
        $domain = get_site_url() . '/';
        
        error_log('MAC Menu: testValidateUrl - API URL: ' . $api_url);
        error_log('MAC Menu: testValidateUrl - Domain: ' . $domain);
        error_log('MAC Menu: testValidateUrl - Version: ' . $this->current_version);
        
        // Prepare request data for POST method
        $request_data = array(
            'url' => $domain,
            'menuversion' => $this->current_version
        );
        
        error_log('=== MAC Menu: Sending to CRM ===');
        error_log('URL: ' . $api_url);
        error_log('Method: POST');
        error_log('Data: ' . json_encode($request_data));
        
        // Make the API request using POST method
        $response = wp_remote_post($api_url, array(
            'method' => 'POST',
            'body' => $request_data,
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            error_log('CRM Response: ERROR - ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('CRM Response: EMPTY');
            return false;
        }
        
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('CRM Response: JSON ERROR - ' . json_last_error_msg());
            return false;
        }
        
        error_log('=== MAC Menu: Received from CRM ===');
        error_log('Response: ' . json_encode($data));
        
        return $data;
    }
    
    /**
     * AJAX handler for testValidateUrl
     */
    public function handle_test_validate_url_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_test_validate_url')) {
            wp_send_json_error('Security check failed.');
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
            return;
        }
        
        error_log('MAC Menu: AJAX testValidateUrl requested');
        $result = $this->testValidateUrl();
        
        if ($result !== false) {
            wp_send_json_success('API test completed successfully. Check error log for details.');
        } else {
            wp_send_json_error('API test failed. Check error log for details.');
        }
    }

    /**
     * Cleanup cron job when plugin is deactivated
     */
    public static function cleanup_cron_job() {
        wp_clear_scheduled_hook('mac_menu_domain_check');
    }
}
} // End of if (!file_exists(WP_PLUGIN_DIR . '/mac-menu/mac-menu.php') && !class_exists('MAC_Menu_Domain_Manager'))
