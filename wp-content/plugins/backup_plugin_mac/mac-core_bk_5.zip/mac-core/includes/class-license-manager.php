<?php
namespace MAC_Core;

// MAC Menu API Constants
if (!defined('MAC_MENU_VALIDATE_KEY')) {
    define('MAC_MENU_VALIDATE_KEY', 'https://wpm.macusaone.com/api/v1/menu-license/validate-key');
}
if (!defined('MAC_MENU_VALIDATE_URL')) {
    define('MAC_MENU_VALIDATE_URL', 'https://wpm.macusaone.com/api/v1/menu-license/validate-url');
}
if (!defined('MAC_MENU_REGISTER_DOMAIN')) {
    define('MAC_MENU_REGISTER_DOMAIN', 'https://wpm.macusaone.com/api/v1/menu-license/register-domain');
}

class License_Manager {
    private $api;
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'mac_licenses';
        $this->api = new API();

        // Initialize MAC Menu options
        $this->initialize_mac_menu_options();

        
        // Note: Hooks are now handled by compatibility layer
        // $this->init_mac_menu_domain_hooks();

        add_action('admin_init', array($this, 'check_licenses'));
        add_action('admin_notices', array($this, 'display_license_notices'));
        
                 // MAC Menu compatibility hooks - These are now handled by compatibility layer
         // add_action('wp_ajax_kvp_handle_ajax_request', array($this, 'mac_menu_handle_ajax_request'));
         // add_action('wp_ajax_nopriv_kvp_handle_ajax_request', array($this, 'mac_menu_handle_ajax_request'));
    }

    /**
     * Initialize MAC Menu options
     * Moved from mac-menu plugin
     */
    private function initialize_mac_menu_options() {
        error_log('MAC Core License Manager: Initializing MAC Menu options');
        error_log('MAC Core License Manager: Init timestamp: ' . date('Y-m-d H:i:s'));
        error_log('MAC Core License Manager: Init backtrace: ' . $this->get_backtrace());
        
        if (false === get_option('mac_domain_valid_key')) {
            add_option('mac_domain_valid_key', '');
            error_log('MAC Core License Manager: Added mac_domain_valid_key option with empty value');
        }
        if (false === get_option('mac_domain_valid_status')) {
            add_option('mac_domain_valid_status', '');
            error_log('MAC Core License Manager: Added mac_domain_valid_status option with empty value');
        }
    }

    public function check_licenses() {
        $licenses = $this->get_all_licenses();
        foreach ($licenses as $license) {
            if ($license['status'] === 'active') {
                $result = $this->api->validate_license($license['license_key'], $license['plugin_slug']);
                if (!$result['success']) {
                    $this->update_license_status($license['id'], 'invalid');
                }
            }
        }
    }

    public function display_license_notices() {
        $licenses = $this->get_all_licenses();
        foreach ($licenses as $license) {
            if ($license['status'] === 'invalid') {
                echo '<div class="error"><p>' . 
                    sprintf(__('Your license for %s is invalid. Please <a href="%s">update your license</a>.', 'mac-core'),
                        $license['plugin_name'],
                        admin_url('admin.php?page=mac-core-licenses')
                    ) . '</p></div>';
            }
        }
    }

    public function get_all_licenses() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$this->table_name}", ARRAY_A);
    }

    public function get_license($plugin_slug) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE plugin_slug = %s", $plugin_slug),
            ARRAY_A
        );
    }

    public function add_license($license_key, $plugin_slug, $plugin_name) {
        global $wpdb;

        $result = $this->api->activate_license($license_key, $plugin_slug);
        if (!$result['success']) {
            return $result;
        }

        $wpdb->insert(
            $this->table_name,
            array(
                'license_key' => $license_key,
                'plugin_slug' => $plugin_slug,
                'plugin_name' => $plugin_name,
                'status' => 'active',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );

        return array(
            'success' => true,
            'message' => __('License activated successfully.', 'mac-core')
        );
    }
    


    public function update_license($license_id, $license_key) {
        global $wpdb;

        $license = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );

        if (!$license) {
            return array(
                'success' => false,
                'message' => __('License not found.', 'mac-core')
            );
        }

        $result = $this->api->activate_license($license_key, $license['plugin_slug']);
        if (!$result['success']) {
            return $result;
        }

        $wpdb->update(
            $this->table_name,
            array(
                'license_key' => $license_key,
                'status' => 'active',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $license_id),
            array('%s', '%s', '%s'),
            array('%d')
        );

        return array(
            'success' => true,
            'message' => __('License updated successfully.', 'mac-core')
        );
    }

    public function deactivate_license($license_id) {
        global $wpdb;

        $license = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );

        if (!$license) {
            return array(
                'success' => false,
                'message' => __('License not found.', 'mac-core')
            );
        }

        $result = $this->api->deactivate_license($license['license_key'], $license['plugin_slug']);
        if (!$result['success']) {
            return $result;
        }

        $wpdb->update(
            $this->table_name,
            array(
                'status' => 'inactive',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $license_id),
            array('%s', '%s'),
            array('%d')
        );

        return array(
            'success' => true,
            'message' => __('License deactivated successfully.', 'mac-core')
        );
    }

    public function delete_license($license_id) {
        global $wpdb;

        $license = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );

        if (!$license) {
            return array(
                'success' => false,
                'message' => __('License not found.', 'mac-core')
            );
        }

        if ($license['status'] === 'active') {
            $this->api->deactivate_license($license['license_key'], $license['plugin_slug']);
        }

        $wpdb->delete(
            $this->table_name,
            array('id' => $license_id),
            array('%d')
        );

        return array(
            'success' => true,
            'message' => __('License deleted successfully.', 'mac-core')
        );
    }

    private function update_license_status($license_id, $status) {
        global $wpdb;
        $wpdb->update(
            $this->table_name,
            array(
                'status' => $status,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $license_id),
            array('%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Get backtrace for debugging
     */
    private function get_backtrace() {
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
        $trace_string = '';
        foreach ($backtrace as $i => $trace) {
            if ($i === 0) continue; // Skip current function
            $trace_string .= "\n" . ($i) . ". " . 
                (isset($trace['class']) ? $trace['class'] . '::' : '') . 
                $trace['function'] . '() in ' . 
                (isset($trace['file']) ? basename($trace['file']) : 'unknown') . 
                ':' . (isset($trace['line']) ? $trace['line'] : 'unknown');
        }
        return $trace_string;
    }

} 