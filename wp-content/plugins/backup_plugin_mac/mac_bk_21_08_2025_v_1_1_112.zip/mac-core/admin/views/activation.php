<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="mac-core-wrap">
    <div class="mac-core-header">
        <h1><?php _e('MAC Core Activation', 'mac-core'); ?></h1>
    </div>

    <div class="mac-core-content">
        <div class="mac-core-card">
            <h2><?php _e('Activate Your License', 'mac-core'); ?></h2>
            
            <?php if (isset($_GET['activation']) && $_GET['activation'] === 'success'): ?>
                <div class="mac-status success">
                    <?php _e('License activated successfully!', 'mac-core'); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['activation']) && $_GET['activation'] === 'error'): ?>
                <div class="mac-status error">
                    <?php _e('License activation failed. Please try again.', 'mac-core'); ?>
                </div>
            <?php endif; ?>

            <form class="mac-license-form" method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php wp_nonce_field('mac_activate_license', 'mac_license_nonce'); ?>
                <input type="hidden" name="action" value="mac_activate_license">
                
                <div class="form-group">
                    <label for="license_key"><?php _e('License Key', 'mac-core'); ?></label>
                    <input type="text" id="license_key" name="license_key" required 
                           placeholder="<?php _e('Enter your license key', 'mac-core'); ?>">
                </div>

                <button type="submit" class="mac-button">
                    <?php _e('Activate License', 'mac-core'); ?>
                </button>
            </form>
        </div>

        <div class="mac-core-card">
            <h2><?php _e('Need Help?', 'mac-core'); ?></h2>
            <p><?php _e('If you need assistance with your license, please contact our support team.', 'mac-core'); ?></p>
            <a href="https://your-support-url.com" class="mac-button" target="_blank">
                <?php _e('Contact Support', 'mac-core'); ?>
            </a>
        </div>
    </div>
</div>