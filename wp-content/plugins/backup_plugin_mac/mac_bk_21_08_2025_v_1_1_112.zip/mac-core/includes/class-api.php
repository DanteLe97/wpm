<?php
namespace MAC_Core;

class API {
    private $api_url;
    private $api_key;

    public function __construct() {
        $this->api_url = get_option('mac_core_api_url', 'https://api.mac-marketing.com/v1');
        $this->api_key = get_option('mac_core_api_key', '');
    }

    public function validate_license($license_key, $plugin_slug) {
        $response = wp_remote_post($this->api_url . '/licenses/validate', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'license_key' => $license_key,
                'plugin_slug' => $plugin_slug,
                'site_url' => get_site_url()
            ))
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    public function activate_license($license_key, $plugin_slug) {
        $response = wp_remote_post($this->api_url . '/licenses/activate', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'license_key' => $license_key,
                'plugin_slug' => $plugin_slug,
                'site_url' => get_site_url()
            ))
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    public function deactivate_license($license_key, $plugin_slug) {
        $response = wp_remote_post($this->api_url . '/licenses/deactivate', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'license_key' => $license_key,
                'plugin_slug' => $plugin_slug,
                'site_url' => get_site_url()
            ))
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    public function get_plugin_info($plugin_slug) {
        $response = wp_remote_get($this->api_url . '/plugins/' . $plugin_slug, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key
            )
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    public function download_plugin($plugin_slug, $version) {
        $response = wp_remote_get($this->api_url . '/plugins/' . $plugin_slug . '/download/' . $version, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key
            )
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = wp_remote_retrieve_body($response);
        return array(
            'success' => true,
            'data' => $body
        );
    }

    public function validate_domain($license_key, $domain, $version) {
        $response = wp_remote_post($this->api_url . '/domains/validate', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'license_key' => $license_key,
                'domain' => $domain,
                'version' => $version
            )),
            'timeout' => 45
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    public function register_domain($license_key, $domain, $version) {
        $response = wp_remote_post($this->api_url . '/domains/register', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'license_key' => $license_key,
                'domain' => $domain,
                'version' => $version
            )),
            'timeout' => 45
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }
} 