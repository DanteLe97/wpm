jQuery(document).ready(function($) {
    'use strict';

    // Handle license actions
    $('.mac-core-license-action').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var action = $button.data('action');
        var licenseId = $button.data('license-id');

        if (action === 'delete' && !confirm(macCoreAdmin.i18n.confirmDelete)) {
            return;
        }

        $button.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_license_action',
                nonce: macCoreAdmin.nonce,
                license_action: action,
                license_id: licenseId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // Handle plugin actions
    $('.mac-core-plugin-action').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var action = $button.data('action');
        var pluginSlug = $button.data('plugin-slug');

        if (action === 'uninstall' && !confirm(macCoreAdmin.i18n.confirmDelete)) {
            return;
        }

        $button.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_plugin_action',
                nonce: macCoreAdmin.nonce,
                plugin_action: action,
                plugin_slug: pluginSlug
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // Handle settings form
    $('#mac-core-settings-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $submitButton = $form.find('button[type="submit"]');

        $submitButton.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_save_settings',
                nonce: macCoreAdmin.nonce,
                api_url: $form.find('#api_url').val(),
                api_key: $form.find('#api_key').val(),
                debug_mode: $form.find('#debug_mode').is(':checked') ? 1 : 0
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $submitButton.prop('disabled', false);
            }
        });
    });

    // Handle license key validation
    $('#license_key').on('blur', function() {
        var $input = $(this);
        var licenseKey = $input.val();

        if (!licenseKey) {
            return;
        }

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_validate_license',
                nonce: macCoreAdmin.nonce,
                license_key: licenseKey
            },
            success: function(response) {
                if (response.success) {
                    $input.removeClass('error').addClass('valid');
                } else {
                    $input.removeClass('valid').addClass('error');
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            }
        });
    });

    // Handle plugin installation
    $('.mac-core-install-plugin').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var pluginSlug = $button.data('plugin-slug');
        var $addonCard = $button.closest('.mac-core-addon-card');

        // First debug tokens
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_debug_tokens',
                nonce: macCoreAdmin.nonce
            },
            success: function(response) {
                console.log('Token debug:', response);
                if (response.success && response.data) {
                    var tokens = response.data;
                    var tokenInfo = [];
                    
                    for (var addon in tokens) {
                        if (addon === '_system') {
                            var sys = tokens[addon];
                            tokenInfo.push('=== SYSTEM STATUS ===');
                            tokenInfo.push('License Key: ' + sys.license_key);
                            tokenInfo.push('Domain Status: ' + sys.domain_status);
                            tokenInfo.push('Domain Key: ' + sys.domain_key);
                        } else {
                            var info = tokens[addon];
                            tokenInfo.push(addon + ': ' + (info.has_token ? 'FOUND (' + info.token_length + ' chars)' : 'NOT FOUND'));
                        }
                    }
                    
                    console.log('Token status:\n' + tokenInfo.join('\n'));
                    
                    // Check if current plugin has token
                    if (tokens[pluginSlug] && !tokens[pluginSlug].has_token) {
                        var sys = tokens['_system'];
                        var message = 'GitHub token not found for ' + pluginSlug + '.\n\n';
                        message += 'Token option: ' + tokens[pluginSlug].option_name + '\n\n';
                        message += 'System Status:\n';
                        message += '- License Key: ' + sys.license_key + '\n';
                        message += '- Domain Status: ' + sys.domain_status + '\n';
                        message += '- Domain Key: ' + sys.domain_key + '\n\n';
                        message += 'Please check your license key and domain validation.';
                        
                        alert(message);
                        return;
                    } else if (tokens[pluginSlug] && tokens[pluginSlug].has_token) {
                        // Test token validity
                        $.ajax({
                            url: macCoreAdmin.ajaxUrl,
                            type: 'POST',
                            data: {
                                action: 'mac_core_test_token',
                                nonce: macCoreAdmin.nonce,
                                plugin_slug: pluginSlug
                            },
                            success: function(response) {
                                console.log('Token test:', response);
                                if (response.success) {
                                    console.log('Token is valid: ' + response.data.message);
                                } else {
                                    console.log('Token is invalid: ' + response.data.message);
                                    alert('GitHub token is invalid: ' + response.data.message + '\n\nPlease check your license key and domain validation.');
                                    return;
                                }
                                
                                // Continue with system requirements check
                                checkSystemRequirements();
                            },
                            error: function(xhr, status, error) {
                                console.error('Token test error:', xhr.responseText);
                                // Continue anyway
                                checkSystemRequirements();
                            }
                        });
                        return;
                    }
                    
                    // Continue with system requirements check
                    checkSystemRequirements();
                } else {
                    alert('Failed to check tokens.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Token debug error:', xhr.responseText);
                alert('Failed to check tokens. Please try again.');
            }
        });
        
        function checkSystemRequirements() {
            // Check system requirements
            $.ajax({
                url: macCoreAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'mac_core_check_system_requirements',
                    nonce: macCoreAdmin.nonce
                },
                success: function(response) {
                    console.log('System requirements:', response);
                    if (response.success && response.data) {
                        var req = response.data;
                        var issues = [];
                        
                        if (!req.plugins_dir_writable) {
                            issues.push('Plugins directory not writable: ' + req.plugins_dir_path);
                        }
                        if (!req.content_dir_writable) {
                            issues.push('Content directory not writable: ' + req.content_dir_path);
                        }
                        if (!req.php_version_ok) {
                            issues.push('PHP version too old: ' + req.php_version + ' (need 7.0+)');
                        }
                        if (!req.curl_available) {
                            issues.push('cURL not available');
                        }
                        
                        if (issues.length > 0) {
                            alert('System requirements not met:\n\n' + issues.join('\n'));
                            return;
                        }
                        
                        // System requirements OK, check plugin status
                        checkPluginStatus();
                    } else {
                        alert('Failed to check system requirements.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('System requirements check error:', xhr.responseText);
                    alert('Failed to check system requirements. Please try again.');
                }
            });
        }
        
        function checkPluginStatus() {
            // Check if GitHub token is available
            $.ajax({
                url: macCoreAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'mac_core_check_install_status',
                    nonce: macCoreAdmin.nonce,
                    plugin_slug: pluginSlug
                },
                success: function(response) {
                    console.log('Status check response:', response);
                    if (response.success && response.data) {
                        if (!response.data.has_token) {
                            alert('GitHub token not found. Please check your license key and domain validation.');
                            return;
                        }
                        
                        if (response.data.installed) {
                            alert('Plugin is already installed.');
                            return;
                        }
                        
                        // Proceed with installation
                        installPlugin();
                    } else {
                        var errorMsg = 'Failed to check plugin status.';
                        if (response && response.data && response.data.message) {
                            errorMsg = response.data.message;
                        }
                        alert(errorMsg);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Status check error:', xhr.responseText);
                    alert('Failed to check plugin status. Please try again.');
                }
            });
        }

        function installPlugin() {
            $button.prop('disabled', true).text('Installing...');
            
            // Add loading indicator
            $addonCard.addClass('installing');
            
            $.ajax({
                url: macCoreAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'mac_core_install_plugin',
                    nonce: macCoreAdmin.nonce,
                    plugin_slug: pluginSlug
                },
                success: function(response) {
                    console.log('Install response:', response);
                    if (response.success) {
                        $button.text('Installed!').addClass('button-disabled');
                        $addonCard.removeClass('installing').addClass('installed');
                        
                        // Show success message
                        var message = response.data.message || 'Plugin installed successfully!';
                        
                                                 // Check if activation failed
                         if (response.data.activation_failed) {
                             message += '\n\nPlugin has been installed but could not be activated automatically.';
                             message += '\nYou can try to activate it manually using the "Activate" button.';
                             message += '\n\nActivation error: ' + response.data.activation_error;
                             
                             // Change button to "Activate"
                             $button.text('Activate').removeClass('button-disabled').addClass('mac-core-activate-plugin');
                         }
                         
                         // Check if force activated
                         if (response.data.force_activated) {
                             message += '\n\nPlugin was force activated due to output issues.';
                             message += '\nThis is normal for MAC Menu plugin.';
                         }
                        
                        // Check if there are function conflicts
                        if (response.data.message && response.data.message.includes('Function conflicts detected')) {
                            message += '\n\nThere are function conflicts. You can force remove the conflicting plugin and try again.';
                            
                            // Change button to "Force Remove"
                            $button.text('Force Remove').removeClass('button-disabled').addClass('mac-core-force-remove-plugin');
                        }
                        
                        alert(message);
                        
                        // Reload page after a short delay
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        var message = 'Installation failed.';
                        if (response && response.data && response.data.message) {
                            message = response.data.message;
                        } else if (response && response.message) {
                            message = response.message;
                        }
                        alert(message);
                        $button.prop('disabled', false).text('Install Now');
                        $addonCard.removeClass('installing');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Installation error:', xhr.responseText);
                    var errorMsg = 'Installation failed. Please check your GitHub token and try again.';
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response && response.message) {
                            errorMsg = response.message;
                        }
                    } catch(e) {
                        // Use default error message
                    }
                    alert(errorMsg);
                    $button.prop('disabled', false).text('Install Now');
                    $addonCard.removeClass('installing');
                }
            });
        }
    });
    
    // Handle manual plugin activation
    $(document).on('click', '.mac-core-activate-plugin', function(e) {
        e.preventDefault();
        var $button = $(this);
        var pluginSlug = $button.data('plugin-slug');
        var $addonCard = $button.closest('.mac-core-addon-card');
        
        $button.prop('disabled', true).text('Activating...');
        $addonCard.addClass('installing');
        
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_activate_plugin',
                nonce: macCoreAdmin.nonce,
                plugin_slug: pluginSlug
            },
            success: function(response) {
                console.log('Activate response:', response);
                                 if (response.success) {
                     $button.text('Activated!').addClass('button-disabled');
                     $addonCard.removeClass('installing').addClass('installed');
                     
                     var message = response.data.message || 'Plugin activated successfully!';
                     alert(message);
                     
                                           // Check if reload is required
                      if (response.data.reload_required) {
                          if (response.data.force_restart) {
                              // Force restart for MAC Menu to clear all caches
                              alert('Plugin activated successfully! The page will now restart to complete activation.');
                              setTimeout(function() {
                                  window.location.href = window.location.href.split('?')[0] + '?restart=1&t=' + Date.now();
                              }, 1000);
                          } else {
                              // Immediate reload for other plugins
                              location.reload();
                          }
                      } else {
                          // Reload page after a short delay
                          setTimeout(function() {
                              location.reload();
                          }, 1500);
                      }
                } else {
                    var message = 'Activation failed.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                    $button.prop('disabled', false).text('Activate');
                    $addonCard.removeClass('installing');
                }
            },
            error: function(xhr, status, error) {
                console.error('Activation error:', xhr.responseText);
                var errorMsg = 'Activation failed. Please try again.';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response && response.message) {
                        errorMsg = response.message;
                    }
                } catch(e) {
                    // Use default error message
                }
                alert(errorMsg);
                $button.prop('disabled', false).text('Activate');
                $addonCard.removeClass('installing');
            }
        });
    });
    
    // Handle force remove plugin
    $(document).on('click', '.mac-core-force-remove-plugin', function(e) {
        e.preventDefault();
        var $button = $(this);
        var pluginSlug = $button.data('plugin-slug');
        var $addonCard = $button.closest('.mac-core-addon-card');
        
        if (!confirm('Are you sure you want to force remove this plugin? This will completely delete the plugin files.')) {
            return;
        }
        
        $button.prop('disabled', true).text('Removing...');
        $addonCard.addClass('installing');
        
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_force_remove_plugin',
                nonce: macCoreAdmin.nonce,
                plugin_slug: pluginSlug
            },
            success: function(response) {
                console.log('Force remove response:', response);
                if (response.success) {
                    $button.text('Removed!').addClass('button-disabled');
                    $addonCard.removeClass('installing').addClass('installed');
                    
                    var message = response.data.message || 'Plugin removed successfully!';
                    message += '\n\nYou can now try installing the plugin again.';
                    alert(message);
                    
                    // Reload page after a short delay
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    var message = 'Force remove failed.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                    $button.prop('disabled', false).text('Force Remove');
                    $addonCard.removeClass('installing');
                }
            },
            error: function(xhr, status, error) {
                console.error('Force remove error:', xhr.responseText);
                var errorMsg = 'Force remove failed. Please try again.';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response && response.message) {
                        errorMsg = response.message;
                    }
                } catch(e) {
                    // Use default error message
                }
                alert(errorMsg);
                $button.prop('disabled', false).text('Force Remove');
                $addonCard.removeClass('installing');
            }
        });
    });
    
    // Handle check options status
    $(document).on('click', '.mac-core-check-options-status', function() {
        const button = $(this);
        const resultDiv = $('#mac-core-options-status-result');
        
        button.prop('disabled', true).text('Checking...');
        resultDiv.hide();
        
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_check_options_status',
                nonce: macCoreAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    let html = '<h4>Critical Options Status:</h4><table class="widefat"><thead><tr><th>Option</th><th>Exists</th><th>Value</th><th>Length</th></tr></thead><tbody>';
                    
                    Object.keys(response.data).forEach(function(option) {
                        const data = response.data[option];
                        html += '<tr>';
                        html += '<td><strong>' + option + '</strong></td>';
                        html += '<td>' + (data.exists ? '✅ Yes' : '❌ No') + '</td>';
                        html += '<td>' + data.value + '</td>';
                        html += '<td>' + data.length + '</td>';
                        html += '</tr>';
                    });
                    
                    html += '</tbody></table>';
                    resultDiv.html(html).show();
                } else {
                    resultDiv.html('<p class="error">Error: ' + response.data + '</p>').show();
                }
            },
            error: function() {
                resultDiv.html('<p class="error">An error occurred while checking options status.</p>').show();
            },
            complete: function() {
                button.prop('disabled', false).text('Check Options Status');
            }
        });
    });
    
    // Handle check URL
    $(document).on('click', '.mac-core-check-url', function() {
        const button = $(this);
        
        button.prop('disabled', true).text('Checking URL...');
        
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_check_url',
                nonce: macCoreAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.data + '\n\nCheck error log for detailed API information.');
                    // Reload page to show updated status
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    var message = '❌ URL check failed.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert('❌ An error occurred while checking URL.');
            },
            complete: function() {
                button.prop('disabled', false).text('Check URL');
            }
        });
    });
    
    // Handle test validate URL
    $(document).on('click', '.mac-core-test-validate-url', function() {
        const button = $(this);
        
        button.prop('disabled', true).text('Testing Validate URL...');
        
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_test_validate_url',
                nonce: macCoreAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Test Validate URL completed successfully!\n\nCheck error log for detailed API request/response information.');
                } else {
                    var message = 'Test Validate URL failed.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert('An error occurred while testing Validate URL.');
            },
            complete: function() {
                button.prop('disabled', false).text('Test Validate URL');
            }
        });
    });

    // Install MAC Menu button
    $(document).on('click', '.mac-core-install-mac-menu', function() {
        const button = $(this);
        button.prop('disabled', true).text('Installing MAC Menu...');
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: { action: 'mac_core_install_mac_menu', nonce: macCoreAdmin.nonce },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.data + '\n\nPage will reload to show updated status.');
                    setTimeout(function() { location.reload(); }, 2000);
                } else {
                    var message = 'Failed to install MAC Menu.';
                    if (response && response.data && response.data.message) { message = response.data.message; }
                    else if (response && response.message) { message = response.message; }
                    alert('❌ ' + message);
                }
            },
            error: function() {
                alert('❌ An error occurred while installing MAC Menu.');
            },
            complete: function() {
                button.prop('disabled', false).text('Install MAC Menu');
            }
        });
    });

    // Activate MAC Menu button
    $(document).on('click', '.mac-core-activate-mac-menu', function() {
        const button = $(this);
        button.prop('disabled', true).text('Activating MAC Menu...');
        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: { action: 'mac_core_activate_mac_menu', nonce: macCoreAdmin.nonce },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.data + '\n\nPage will reload to show updated status.');
                    setTimeout(function() { location.reload(); }, 2000);
                } else {
                    var message = 'Failed to activate MAC Menu.';
                    if (response && response.data && response.data.message) { message = response.data.message; }
                    else if (response && response.message) { message = response.message; }
                    alert('❌ ' + message);
                }
            },
            error: function() {
                alert('❌ An error occurred while activating MAC Menu.');
            },
            complete: function() {
                button.prop('disabled', false).text('Activate MAC Menu');
            }
        });
    });

    // Reset Options button
    $(document).on('click', '.mac-core-reset-options', function() {
        if (confirm('Are you sure you want to reset all MAC Menu options? This will clear all domain keys and status.')) {
            const button = $(this);
            button.prop('disabled', true).text('Resetting Options...');
            $.ajax({
                url: macCoreAdmin.ajaxUrl,
                type: 'POST',
                data: { action: 'mac_core_reset_options', nonce: macCoreAdmin.nonce },
                success: function(response) {
                    if (response.success) {
                        alert('✅ ' + response.data);
                        setTimeout(function() { location.reload(); }, 2000);
                    } else {
                        var message = 'Failed to reset options.';
                        if (response && response.data && response.data.message) { message = response.data.message; }
                        else if (response && response.message) { message = response.message; }
                        alert('❌ ' + message);
                    }
                },
                error: function() {
                    alert('❌ An error occurred while resetting options.');
                },
                complete: function() {
                    button.prop('disabled', false).text('Reset Options');
                }
            });
        }
    });
    
});