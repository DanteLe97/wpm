<?php

require_once MAC_CORE_PATH . 'api/mac-walc-core.php';





