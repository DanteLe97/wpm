<?php
class macMenu {
    private $_cat_menu = '';
    public function __construct(){
        global $wpdb;
        $this->_cat_menu = $wpdb->prefix.'mac_cat_menu';
    }
    public function get_cat_menu_name() {
        return $this->_cat_menu;
    }
    /* list cat */
    public function all_cat(){
        global $wpdb;
        $sql = "SELECT * FROM $this->_cat_menu WHERE `is_hidden` = '0' ORDER BY `order`  ASC";
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function find_cat_menu($id){
        global $wpdb;
        $sql = "SELECT * FROM $this->_cat_menu WHERE `id` = $id";
        $items = $wpdb->get_results($sql);
        return $items;
    }
    //     public function find_cat_menu_by_name($name){
//         global $wpdb;
//         //$sql = "SELECT * FROM $this->_cat_menu WHERE `category_name` = '$name'";
//         $sql = $wpdb->prepare("SELECT * FROM $this->_cat_menu WHERE category_name = %s  and `is_hidden` = '0' ",$name);
//         $items = $wpdb->get_results($sql);
//         return $items;
        
        
//     }

    public function find_cat_menu_by_name($name){
        global $wpdb;

        // Chuẩn hóa chuỗi
        $name = trim($name);
        $name = preg_replace('/\s+/', ' ', $name);
        $name = html_entity_decode($name, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $search = ["’", "‘", "`", "´", "′"]; // có thể thêm nữa
        $name = str_replace($search, "'", $name);
        $name = str_replace("'", "\\'", $name); 
        // Truy vấn
        $sql = $wpdb->prepare("SELECT * FROM $this->_cat_menu WHERE category_name LIKE %s AND is_hidden = '0'", $name);
        $items = $wpdb->get_results($sql);

        return $items;
    }
    public function find_cat_menu_by_name_all_child_cats($names) {
        global $wpdb;
    
        if (!is_array($names) || empty($names)) {
            return []; // Trả về mảng rỗng nếu đầu vào không phải là mảng hoặc mảng rỗng
        }
    
        // Thoát chuỗi để tránh SQL injection
        $names_placeholder = implode(',', array_map(function($name) use ($wpdb) {
            return $wpdb->prepare('%s', $name);
        }, $names));
        var_dump($names_placeholder);
        // Xây dựng câu truy vấn SQL
        $sql = "
            SELECT *
            FROM $this->_cat_menu
            WHERE `category_name` IN ($names_placeholder)
                OR `parents_category` IN (
                    SELECT `id`
                    FROM $this->_cat_menu AS sub1
                    WHERE sub1.`parents_category` IN ($names_placeholder)
                    OR sub1.`parents_category` IN (
                        SELECT `id`
                        FROM $this->_cat_menu AS sub2
                        WHERE sub2.`parents_category` IN ($names_placeholder)
                        OR sub2.`parents_category` IN (
                            SELECT `id`
                            FROM $this->_cat_menu AS sub3
                            WHERE sub3.`parents_category` IN ($names_placeholder)
                            OR sub3.`parents_category` IN (
                                SELECT `id`
                                FROM $this->_cat_menu AS sub4
                                WHERE sub4.`parents_category` IN ($names_placeholder)
                            )
                        )
                    )
                )
            and `is_hidden` = '0'
            ORDER BY `order` ASC
        ";
        // Thực thi truy vấn và kiểm tra lỗi
        $items = $wpdb->get_results($sql);
    
        if ($wpdb->last_error) {
            // In lỗi cơ sở dữ liệu nếu có
            echo 'Database error: ' . $wpdb->last_error;
        }
    
        return $items;
    }
    public function find_cat_menu_all_child_cats($ids) {
        global $wpdb;
    
        if (!is_array($ids) || empty($ids)) {
            return []; // Trả về mảng rỗng nếu đầu vào không phải là mảng hoặc mảng rỗng
        }
    
        // Chuyển mảng các ID thành một chuỗi các giá trị được phân tách bởi dấu phẩy
        $ids_placeholder = implode(',', array_map('intval', $ids));
    
        $sql = "
            SELECT *
            FROM $this->_cat_menu
            WHERE (`id` IN ($ids_placeholder)
                OR `parents_category` IN ($ids_placeholder)
                OR `parents_category` IN (
                    SELECT `id`
                    FROM $this->_cat_menu AS sub1
                    WHERE sub1.`parents_category` IN ($ids_placeholder)
                    OR sub1.`parents_category` IN (
                        SELECT `id`
                        FROM $this->_cat_menu AS sub2
                        WHERE sub2.`parents_category` IN ($ids_placeholder)
                        OR sub2.`parents_category` IN (
                            SELECT `id`
                            FROM $this->_cat_menu AS sub3
                            WHERE sub3.`parents_category` IN ($ids_placeholder)
                            OR sub3.`parents_category` IN (
                                SELECT `id`
                                FROM $this->_cat_menu AS sub4
                                WHERE sub4.`parents_category` IN ($ids_placeholder)
                            )
                        )
                    )
                )
				)
                AND `is_hidden` = '0'
                ORDER BY `order` ASC
        ";
    
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function save_cat($data){
        global $wpdb;
        $wpdb->insert($this->_cat_menu, $data);
        $lastId = $wpdb->insert_id;
        $item = $this->find_cat_menu($lastId);
        return $item;
    }
    public function update_cat($id,$data){
        global $wpdb;
        // if($id == 9) {
        //     echo '<pre>';
        // print_r($data);
        // echo '</pre>';
        // die();
        // }
        
        $wpdb->update($this->_cat_menu, $data, [
            'ID' => $id
        ]);
        
        $result = $this->find_cat_menu($id);
        return $result;
    }
    public function update_cat_inside($id, $data) {
        global $wpdb;
        
        // Lấy dữ liệu hiện tại
        $current_data = $this->find_cat_menu($id);
        if (empty($current_data)) {
            return false;
        }
        
        // Chỉ giữ lại những trường có thay đổi
        $update_data = array();
        foreach ($data as $key => $value) {
            if ($current_data[0]->$key !== $value) {
                $update_data[$key] = $value;
            }
        }
        
        // Nếu không có trường nào thay đổi, return luôn
        if (empty($update_data)) {
            return $current_data;
        }
        
        // Update chỉ những trường thay đổi
        $wpdb->update(
            $this->_cat_menu, 
            $update_data,
            ['id' => $id]
        );
        
        // Return dữ liệu mới
        return $this->find_cat_menu($id);
    }
    public function destroy_Cat($id){
        global $wpdb;
        $wpdb->delete($this->_cat_menu,[
            'id' => $id
        ]);
        return true;
    }
    public function paginate_cat($limit = 100){
        global $wpdb;

        $s = isset( $_REQUEST['s'] ) ? $_REQUEST['s'] : '';
        $paged = isset( $_REQUEST['paged'] ) ? $_REQUEST['paged'] : 1;

        // Lấy tổng số records
        $sql = "SELECT count(id) FROM $this->_cat_menu ";
        // Tim kiếm
        if( $s ){
            $sql .= " AND ( id LIKE '%$s%' )";
        }
        $total_items = $wpdb->get_var($sql);
        
        // Thuật toán phân trang
        /*
        Limit: limit
        Tổng số trang: total_pages
        Tính offset
        */
        $total_pages    = ceil( $total_items / $limit );
        $offset         = ( $paged * $limit ) - $limit;

        //$sql = "SELECT * FROM $this->_cat_menu WHERE `parents_category` = '0'";
        $sql = "
            SELECT t1.*
            FROM $this->_cat_menu AS t1
            LEFT JOIN $this->_cat_menu AS t2 ON t1.parents_category = t2.id
            WHERE t1.parents_category = 0 OR (t1.parents_category != 0 AND t2.id IS NULL)
        ";
        //$sql = "SELECT * FROM $this->_cat_menu ";
        // Tim kiếm
        if( $s ){
            $sql .= " AND ( id LIKE '%$s%' )";
        }
        $sql .= " ORDER BY `order` ASC";
        $sql .= " LIMIT $limit OFFSET $offset";


        $items = $wpdb->get_results($sql);

        return [
            'total_pages'   => $total_pages,
            'total_items'   => $total_items,
            'items'         => $items
        ];

    }
    /* all  */
    public function all_cat_by_not_is_table(){
        global $wpdb;
        $sql = "SELECT *
                FROM $this->_cat_menu WHERE 
                `is_table` = '0' ORDER BY `order` ASC ";

        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function all_cat_menu_has_item(){
        global $wpdb;
        $sql = "SELECT *
        FROM $this->_cat_menu WHERE `parents_category` = '0' and `is_hidden` = '0' ORDER BY `order` ASC";

        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function all_cat_by_parent_cat_menu($id){
        global $wpdb;
        $sql = "SELECT *
                FROM $this->_cat_menu WHERE 
                `parents_category` = $id ORDER BY `order` ASC ";

        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function all_cat_by_parent_cat_menu_html($id){
        global $wpdb;
        $sql = "SELECT *
                FROM $this->_cat_menu WHERE 
                `parents_category` = $id  and `is_hidden` = '0' ORDER BY `order` ASC ";

        $items = $wpdb->get_results($sql);
        return $items;
    }
    
    public function change_status($order_id,$status){
        global $wpdb;
        $wpdb->update(
            $this->_menu, 
            [
                'status' => $status
            ], 
            [
                'id' => $order_id
            ]
        );
        return true;
    }
    public function change_position($id,$position){
        global $wpdb;
        $wpdb->update(
            $this->_cat_menu, 
            
            [
                'order' => $position
            ],
            [
                'ID' => $id
            ]
        );
        
        return true;
    }
    public function change_position_cat($id,$position){
        global $wpdb;
        $wpdb->update(
            $this->_menu, 
            
            [
                'order' => $position
            ],
            [
                'ID' => $id
            ]
        );
        
        return true;
    }

    public function getAllIdCatChildInside($id_category) {
        $arrayCatId = array();
        $objmacMenu = new macMenu();
        $result = $objmacMenu->all_cat_by_parent_cat_menu($id_category);
       
            foreach( $result as $item ){
                if ($item->category_inside == 1){
                    $arrayCatId[] = $item->id;
                }
            }
      
        return $arrayCatId;
    }
    public function getAllIdCatChildInsideHTML($id_category) {
        $arrayCatId = array();
        $objmacMenu = new macMenu();
        $result = $objmacMenu->all_cat_by_parent_cat_menu_html($id_category);
       
            foreach( $result as $item ){
                if ($item->category_inside == 1){
                    $arrayCatId[] = $item->id;
                }
            }
      
        return $arrayCatId;
    }
}