<?php
/**
 * MacAPI Core Plugin - Xử lý auto-login độc lập cho API, không trùng với add-on/auto-login.php
 */
if (!defined('ABSPATH')) exit;

class MacAPI_Auto_Login {
    public function __construct() {
        add_action('init', [$this, 'macapi_auto_login_handler']);
    }

    // Xử lý auto-login qua token riêng
    public function macapi_auto_login_handler() {
        if (!isset($_GET['macapi_token'])) return;
        $token = sanitize_text_field($_GET['macapi_token']);
        $users = get_users([
            'meta_key'   => 'macapi_token',
            'meta_value' => $token,
            'number'     => 1,
            'fields'     => 'all',
        ]);
        if (empty($users)) {
            error_log('MacAPI AutoLogin: Token không hợp lệ: ' . $token);
            wp_die('Token không hợp lệ.');
        }
        $user = $users[0];
        // Đăng nhập
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        // DEBUG: Kiểm tra headers đã gửi chưa
        if (!headers_sent()) {
            error_log('MacAPI AutoLogin: Redirect bằng header cho user ID: ' . $user->ID);
            wp_redirect(admin_url());
            exit;
        } else {
            error_log('MacAPI AutoLogin: Redirect bằng JS fallback cho user ID: ' . $user->ID);
            echo '<script>window.location="' . admin_url() . '";</script>';
            exit;
        }
    }

    // Tạo link auto-login riêng
    public function macapi_generate_auto_login_link($user_id, $days = 3) {
        $token = wp_generate_password(32, false, false);
        $expires = time() + $days * DAY_IN_SECONDS;
        update_user_meta($user_id, 'macapi_token', $token);
        update_user_meta($user_id, 'macapi_expires', $expires);
        return site_url('?macapi_token=' . $token);
    }
}
new MacAPI_Auto_Login();
