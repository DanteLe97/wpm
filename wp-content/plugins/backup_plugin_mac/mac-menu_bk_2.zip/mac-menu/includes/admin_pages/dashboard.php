<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

$keyDomain = !empty(get_option('mac_domain_valid_key')) ? get_option('mac_domain_valid_key') : "0" ;
$statusDomain = !empty(get_option('mac_domain_valid_status')) ? get_option('mac_domain_valid_status') : "0" ;

// Only check domain status when actually viewing the dashboard page
if (isset($_GET['page']) && $_GET['page'] === 'mac-menu') {
    if(!empty($keyDomain)) {
        kvp_handle_check_request($keyDomain);
    }else{
        kvp_handle_check_request_url();
    }
}

    if ( is_admin() ) {
        if( ! function_exists('get_plugin_data') ){
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }
        $plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $plugin_data = get_plugin_data( $plugin_file );
    }
    if(isset($plugin_data['Version'])){
        $current_version = $plugin_data['Version'];
    }else{
        $current_version = '1.0.1';
    }
    
?>
<div id="post-body" style="margin-top: 50px;">
    <?php 
        global $wpdb;
        // Tên bảng
        $cattablename = $wpdb->prefix . 'mac_cat_menu';
        // Kiểm tra sự tồn tại của bảng
        $table_exists_query = $wpdb->prepare("SHOW TABLES LIKE %s", $cattablename);
        $table_exists = $wpdb->get_var($table_exists_query);
        if(current_user_can('edit_dashboard')):
        ?>
        <div class="page-settings-wrap">
            <div class="content">
                <div class="wrap mac-dashboard">
                    <h1 class="wp-heading-inline"></h1>
                    <?php if( !empty($statusDomain) && ($statusDomain =='activate' || $statusDomain =='deactivate') ){ ?>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>IMPORT MENU</h2>
                        </div>
                        
                        <div class="inside is-primary-category"> 
                            <select class="mac-selection-data mac-selection-import-mode">
                                <option value="" selected>Please select an import mode</option>
                                <option value="replace">Replace existing data (delete and re-import)</option>
                                <option value="append">Append to existing data (add new items only)</option>
                            </select>
                            <div class="mac-data-replace">
                                <?php
                                if ($table_exists === $cattablename):
                                    ?>
                                        <div class="form-add-cat-menu">
                                            <form action="" method="post" id="posts-filter" enctype="multipart/form-data">
                                                <input id="input-delete-data" type="text" data-table="<?= $cattablename ?>" name="delete_data" value="" readonly style="border:none;padding:0; opacity: 0; width: 0;">
                                                <!-- <input id="input-export-table-data" type="text" name="export_table_data" value="" readonly style="border:none;padding:0; opacity: 0; width: 0;"> -->
                                                <input type="file" name="csv_file_cat">
                                                <input type="submit" name="submit-cat" value="submit" class="btn-delete-menu">
                                            </form>
                                        </div>
                                        <!-- -->
                                        <div class="overlay" id="overlay"></div>
                                        <div class="confirm-dialog" id="confirmDialog" >
                                            <p>Are you sure want delete data?</p>
                                            <div class="btn-wrap">
                                                <div id="confirmOk">OK</div>
                                                <div id="confirmCancel">Cancel</div>
                                            </div>
                                        </div>
                                    <?php
                                else:
                                    ?>
                                        <div class="form-add-cat-menu">
                                            <form action="" method="post" enctype="multipart/form-data">
                                                <input type="file" name="csv_file_cat">
                                                <input type="submit" name="submit-cat" value="submit">
                                            </form>
                                        </div>
                                    <?php
                                endif;
                                ?>
                            </div>
                            <div class="mac-data-append">
                                <div class="form-append-cat-menu" > <!--style="display:none"-->
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <input type="text" name="name_shop">
                                        <input type="file" name="csv_file_cat_append">
                                        <input type="submit" name="submit-cat" value="submit">
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>EXPORT MENU</h2>
                        </div>
                        <div class="inside is-primary-category"> 
                            <?php
                            if ($table_exists === $cattablename):
                                ?>
                                    <a href="<?php echo admin_url('admin-post.php?action=export_csv&export_table_data=1'); ?>">Export CSV</a>
                            <?php
                            endif;
                            ?>
                        </div>
                    </div>
            <?php } ?>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>Validate Key</h2>
                        </div>
                        <div class="inside"> 
                            <div id="kvp-container" class="key-domain-wrap" >
                                <form id="kvp-form">
                                    <label for="kvp-key-input">Enter your key:</label>
                                    <input type="text" id="kvp-key-input" name="key" value="MAC Menu" required>
                                    <button type="submit">Validate</button>
                                </form>
                                <div id="kvp-result"></div>
                            </div>
                        </div>
                    </div>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>Setting Custom Meta Box Page</h2>
                        </div>
                        <div class="inside"> 
                            <div class="mac-custom-meta-box-page-wrap" >
                                <form id="mac-custom-meta-box-page-form" method="post" enctype="multipart/form-data">
                                    <label>Enter Name Meta Box Page:</label>
                                    <?php $ValueMetaBoxPage = !empty(get_option('mac_custom_meta_box_page')) ? get_option('mac_custom_meta_box_page') : "" ; ?>
                                    <input type="text" name="mac-custom-meta-box-page" value="<?=$ValueMetaBoxPage;?>" required>
                                    <button type="submit">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php if( !empty($statusDomain) && ($statusDomain =='activate' || $statusDomain =='deactivate') ){ ?>
                    <div class="form-add-settings-menu">
                        <form id="formCategorySettingsMain" method="post" enctype="multipart/form-data">
                            <div class="postbox">
                                <div class="postbox-header">
                                    <h2>SETTINGS</h2>
                                </div>
                                <div class="inside is-primary-category" <?php if($statusDomain =='pending' || $statusDomain =='0' ){ echo 'style="opacity: 0; visibility: hidden; height: 0;"';} ?>> 
                                    <table class="form-settings-page">
                                        <tr>
                                            <td>On/Off Description WP Editor </td>
                                            <td>
                                                <?php $editorTextValue = !empty(get_option('mac_menu_text_editor')) ? get_option('mac_menu_text_editor') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($editorTextValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-text-editor" value="<?= $editorTextValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr>  
                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:700;">Menu</h2></td>
                                        </tr>

                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">Content</h2></td>
                                        </tr>

                                        <tr>
                                            <td>On/Off Element Category</td>
                                            <td>
                                                <?php $elementCatValue = !empty(get_option('mac_menu_element_category')) ? get_option('mac_menu_element_category') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($elementCatValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-element-category" value="<?= $elementCatValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Element Category Table</td>
                                            <td>
                                                <?php $elementCatTableValue = !empty(get_option('mac_menu_element_category_table')) ? get_option('mac_menu_element_category_table') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($elementCatTableValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-element-category-table" value="<?= $elementCatTableValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 

                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">Style</h2></td>
                                        </tr>

                                        <tr>
                                            <td>On/Off Background</td>
                                            <td>
                                                <?php $bgValue = !empty(get_option('mac_menu_background')) ? get_option('mac_menu_background') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($bgValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-background" value="<?= $bgValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Spacing</td>
                                            <td>
                                                <?php $spacingValue = !empty(get_option('mac_menu_spacing')) ? get_option('mac_menu_spacing') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($spacingValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-spacing" value="<?= $spacingValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Image</td>
                                            <td>
                                                <?php $imgValue = !empty(get_option('mac_menu_img')) ? get_option('mac_menu_img') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($imgValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-img" value="<?= $imgValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Item Image</td>
                                            <td>
                                                <?php $itemImgValue = !empty(get_option('mac_menu_item_img')) ? get_option('mac_menu_item_img') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($itemImgValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-item-img" value="<?= $itemImgValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">Typography</h2></td>
                                        </tr>
                                        <tr>
                                            <td>Rank</td>
                                            <td>
                                                <?php $rankNumber = !empty(get_option('mac_menu_rank')) ? get_option('mac_menu_rank') : "1" ; ?>
                                                <select class="mac-is-selection" name="mac-menu-rank">
                                                    <option value="1" <?= ($rankNumber == 1) ? "selected" : ""  ?>>1</option>
                                                    <option value="2" <?= ($rankNumber == 2) ? "selected" : ""  ?>>2</option>
                                                    <option value="3" <?= ($rankNumber == 3) ? "selected" : ""  ?>>3</option>
                                                    <option value="4" <?= ($rankNumber == 4) ? "selected" : ""  ?>>4</option>
                                                    <option value="5" <?= ($rankNumber == 5) ? "selected" : ""  ?>>5</option>
                                                </select>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>Javascript Link Menu</td>
                                            <td>
                                                <?php $rankNumber = !empty(get_option('mac_menu_js_link')) ? get_option('mac_menu_js_link') : "0" ; ?>
                                                <select class="mac-is-selection" name="mac-menu-js-link">
                                                    <option value="0" <?= ($rankNumber == 0) ? "selected" : ""  ?>>Default</option>
                                                    <option value="1" <?= ($rankNumber == 1) ? "selected" : ""  ?>>Link Menu</option>
                                                </select>
                                            </td>
                                        </tr>   
                                        <?php do_action('mac_menu_add_on_additional_settings_row_dual_price'); ?>
                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">QR Code</h2></td>
                                        </tr>
                                        <tr>
                                            <td>On/Off QR Code</td>
                                            <td class="mac-qr-code">
                                                <?php $macQR = !empty(get_option('mac_qr_code')) ? get_option('mac_qr_code') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($macQR == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-qr" value="<?= $macQR ?>" readonly/>
                                                </div>
                                                <?php $macHeading = !empty(get_option('mac_qr_title')) ? get_option('mac_qr_title') : "" ; ?>
                                                <label>Heading Title:</label>
                                                <input type="text" name="mac-qr-title" value="<?=$macHeading;?>">
                                            </td>
                                        </tr> 

                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">HTML New</h2></td>
                                        </tr>
                                        <tr>
                                            <td>On/Off HTML</td>
                                            <td class="mac-html">
                                                <?php $macHTMLOld = !empty(get_option('mac_html_old')) ? get_option('mac_html_old') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($macHTMLOld == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-html-old" value="<?= $macHTMLOld ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 

                                        
                                        
                                       
                                    </table>
                                </div>
                                <!--
                                <div class="postbox-header" style="margin-top: 45px">
                                    <h2>Key</h2>
                                </div>
                                <div class="inside is-primary-category" 
                                <?php if($statusDomain =='pending' || $statusDomain =='0'){ echo 'style="opacity: 0; visibility: hidden; height: 0;"';} ?>
                                > 
                                    <table class="form-settings-page">
                                        <tr>
                                            <td>Insert KEY</td>
                                            <td>
                                                <input type="text" name="mac-menu-github-key" class="hidden-input" value="MAC Menu"/>
                                            </td>
                                        </tr>    
                                    </table>
                                </div>
                                -->
                            </div>
                            <input type="text" name="action" value="menu-settings" readonly style="display:none;">
                            <input type="submit" name="submit-settings" class="mac-btn-save-chages" value="Save Changes">
                        </form>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
            <?php
        else:
            wp_die('You do not have sufficient permissions to access this page.');
        endif;
    ?>
</div>
<?php
if (false === get_option('mac_custom_meta_box_page')) {
    add_option('mac_custom_meta_box_page', '0');
}
if (false === get_option('mac_menu_element_category')) {
    add_option('mac_menu_element_category', '0');
}
if (false === get_option('mac_menu_element_category_table')) {
    add_option('mac_menu_element_category_table', '0');
}
if (false === get_option('mac_menu_background')) {
    add_option('mac_menu_background', '0');
}
if (false === get_option('mac_menu_spacing')) {
    add_option('mac_menu_spacing', '0');
}
if (false === get_option('mac_menu_rank')) {
    add_option('mac_menu_rank', '1');
}
if (false === get_option('mac_menu_text_editor')) {
    add_option('mac_menu_text_editor', '0');
}
if (false === get_option('mac_menu_img')) {
    add_option('mac_menu_img', '0');
}
if (false === get_option('mac_menu_item_img')) {
    add_option('mac_menu_item_img', '0');
}
if (false === get_option('mac_menu_js_link')) {
    add_option('mac_menu_js_link', '0');
}
if (false === get_option('mac_qr_title')) {
    add_option('mac_qr_title', '');
}

if (false === get_option('mac_html_old')) {
    add_option('mac_html_old', '');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_REQUEST['mac-custom-meta-box-page']) && !empty($_REQUEST['mac-custom-meta-box-page']) ) {
        update_option('mac_custom_meta_box_page', $_REQUEST['mac-custom-meta-box-page']);
        mac_redirect('admin.php?page=mac-menu');
    }
    
}

if(isset($_REQUEST['action']) == 'menu-settings'):
    
    if(isset($_REQUEST['mac-menu-element-category']) ) {
        update_option('mac_menu_element_category', $_REQUEST['mac-menu-element-category']);
    }
    if(isset($_REQUEST['mac-menu-element-category-table']) ) {
        update_option('mac_menu_element_category_table', $_REQUEST['mac-menu-element-category-table']);
    }
    if(isset($_REQUEST['mac-menu-background'])) {
        update_option('mac_menu_background', $_REQUEST['mac-menu-background']);
    }
    if(isset($_REQUEST['mac-menu-spacing'])) {
        update_option('mac_menu_spacing', $_REQUEST['mac-menu-spacing']);
    }
    if(isset($_REQUEST['mac-menu-rank']) && !empty($_REQUEST['mac-menu-rank']) ) {
        update_option('mac_menu_rank', $_REQUEST['mac-menu-rank']);
    }
    if(isset($_REQUEST['mac-menu-text-editor']) ) {
        update_option('mac_menu_text_editor', $_REQUEST['mac-menu-text-editor']);
    }
    if(isset($_REQUEST['mac-menu-img']) ) {
        update_option('mac_menu_img', $_REQUEST['mac-menu-img']);
    }
    if(isset($_REQUEST['mac-menu-item-img']) ) {
        update_option('mac_menu_item_img', $_REQUEST['mac-menu-item-img']);
    }
    if(isset($_REQUEST['mac-menu-js-link']) ) {
        update_option('mac_menu_js_link', $_REQUEST['mac-menu-js-link']);
    }
    
    if(isset($_REQUEST['mac-menu-dp']) ) {
        update_option('mac_menu_dp', $_REQUEST['mac-menu-dp']);
    }
    if(isset($_REQUEST['mac-menu-dp-sw']) ) {
        update_option('mac_menu_dp_sw', $_REQUEST['mac-menu-dp-sw']);
    }
    if(isset($_REQUEST['mac-menu-dp-value']) ) {
        update_option('mac_menu_dp_value', $_REQUEST['mac-menu-dp-value']);
    }
    if(isset($_REQUEST['mac-menu-qr']) ) {
        update_option('mac_qr_code', $_REQUEST['mac-menu-qr']);
    }
    if(isset($_REQUEST['mac-qr-title']) ) {
        update_option('mac_qr_title', $_REQUEST['mac-qr-title']);
    }
    if(isset($_REQUEST['mac-html-old']) ) {
        update_option('mac_html_old', $_REQUEST['mac-html-old']);
    }
    
    
    mac_redirect('admin.php?page=mac-menu');
    exit();
endif;
function importCSV($fileCSV, $parentID = 0, $parentName = ''){
    if($fileCSV['error'] === UPLOAD_ERR_OK ) {
        $csv_file = $fileCSV;
        $tmp_name = $csv_file["tmp_name"];
        // Đọc nội dung từ file CSV
        $handle = fopen($tmp_name, "r");
        // Kiểm tra xem file có tồn tại không
        if ($handle === FALSE) {
            die("Failed to open uploaded file.");
        }
        $header = array_flip(fgetcsv($handle)); // Read header row
        // Đọc từng dòng của file CSV và xử lý dữ liệu
        $itemMenuIndex = 0;
        $itemChildrenIndex = 0;
        $numberX = 0;
        $rank = 0;
        $term = 0;
        $dataArray = [];
        while (($row = fgetcsv($handle)) !== FALSE) {
            if(!empty($row[$header['category_name']])){
                $dataArray[$itemMenuIndex] = [
                    "category_name" => $row[$header['category_name']],
                    "slug_category" => '',
                    "category_description" => ( isset($header['category_description']) && !empty($row[$header['category_description']])) ? $row[$header['category_description']] : "",
                    "price" => ( isset($header['price']) && !empty($row[$header['price']])) ? $row[$header['price']] : "",
                    "featured_img" => ( isset($header['featured_img']) && !empty($row[$header['featured_img']])) ? $row[$header['featured_img']] : "",
                    "parents_category" => ( isset($header['parents_category']) && !empty($row[$header['parents_category']])) ? (int)$row[$header['parents_category']] + $parentID  : $parentID,
                    "group_repeater" => [],
                    "is_table" => ( isset($header['is_table']) && !empty($row[$header['is_table']])) ? $row[$header['is_table']] : "0", 
                    "is_hidden" => ( isset($header['is_hidden']) && !empty($row[$header['is_hidden']])) ? $row[$header['is_hidden']] : "0", 
                    "data_table" => ( isset($header['table_heading']) && !empty($row[$header['table_heading']])) ? $row[$header['table_heading']] : "", 
                    "order" => '',
                    "category_inside" => ( isset($header['category_inside']) && !empty($row[$header['category_inside']])) ? $row[$header['category_inside']] : "1", 
                    "category_inside_order" => ( isset($header['category_inside_order']) && !empty($row[$header['category_inside_order']])) ? $row[$header['category_inside_order']] : NULL, 
                ];
                
                if (!empty($row[$header['item_list_name']])) {
                    $listItem = 0;
                    $dataArray[$itemMenuIndex]['group_repeater'][] = [
                        "name" => $row[$header['item_list_name']],
                        "featured_img" => ( isset($header['item_list_img']) && !empty($row[$header['item_list_img']])) ? $row[$header['item_list_img']] : "", 
                        "description"  => ( isset($header['item_list_description']) && !empty($row[$header['item_list_description']])) ? $row[$header['item_list_description']] : "", 
                        "fullwidth"    => ( isset($header['item_list_fw']) && !empty($row[$header['item_list_fw']])) ? $row[$header['item_list_fw']] : "0", 
                        "price-list"   => ( isset($header['item_list_price']) ) ? create_array($row[$header['item_list_price']],'price') : "",  
                        "position"   => ( isset($header['item_list_position']) && !empty($row[$header['item_list_position']])) ? $row[$header['item_list_position']] : $listItem + 1, 
                    ];
                    
                }
                $itemMenuIndex++;
            }else{
                if (!empty($row[$header['item_list_name']])) {
                    if($listItem == 0) {
                        $listItem+=1;
                    }
                    $dataArray[($itemMenuIndex - 1)]['group_repeater'][] = [
                        "name" => $row[$header['item_list_name']],
                        "featured_img" => ( isset($header['item_list_img']) && !empty($row[$header['item_list_img']])) ? $row[$header['item_list_img']] : "", 
                        "description"  => ( isset($header['item_list_description']) && !empty($row[$header['item_list_description']])) ? $row[$header['item_list_description']] : "", 
                        "fullwidth"    => ( isset($header['item_list_fw']) && !empty($row[$header['item_list_fw']])) ? $row[$header['item_list_fw']] : "0", 
                        "price-list"   => ( isset($header['item_list_price']) ) ? create_array($row[$header['item_list_price']],'price') : "",  
                        "position"   => ( isset($header['item_list_position']) && !empty($row[$header['item_list_position']])) ? $row[$header['item_list_position']] : $listItem + 1, 
                    ];
                    $listItem+=1;
                }
            }
           
        }
        fclose($handle);
       
        plugin_cat_table($dataArray,$parentID,$parentName);
    }else{
        echo 'Upload False';
    }
}


if(!empty($_FILES['csv_file_cat'])) {
    $deleteData = (isset($_REQUEST['delete_data']) && $_REQUEST['delete_data'] != '') ? $_REQUEST['delete_data'] : '';
    if($deleteData != '') {
        delete_table_cat($deleteData);
    }
    importCSV($_FILES['csv_file_cat'], 0, '');
}elseif (!empty($_FILES['csv_file_cat_append']) && !empty($_REQUEST['name_shop'])) {
    $shopName = trim($_REQUEST['name_shop']);
  
    // Tạo category cha trong DB
    $parentID = insert_category([
        'category_name' => $shopName,
        'slug_category' => create_slug($shopName), // có thể generate slug nếu muốn
        'category_description' => '',
        'price' => '',
        'featured_img' => '',
        'parents_category' => 0,
        'group_repeater' => [],
        'is_table' => 0,
        'is_hidden' => 0,
        'data_table' => '',
        'order' => '',
        'category_inside' => '',
        'category_inside_order' => NULL
    ]);
    if ($parentID) {
        importCSV($_FILES['csv_file_cat_append'], $parentID, $shopName);
    } else {
        echo "Không thể tạo danh mục cha.";
    }
}
function insert_category($data) {
    global $wpdb;
    $cattablename = $wpdb->prefix . "mac_cat_menu";
    $wpdb->insert($cattablename, [
        'category_name' => $data['category_name'],
        'slug_category' => $data['slug_category'],
        'category_description' => $data['category_description'],
        'price' => $data['price'],
        'featured_img' => $data['featured_img'],
        'parents_category' => $data['parents_category'],
        'group_repeater' => maybe_serialize($data['group_repeater']),
        'is_table' => $data['is_table'],
        'is_hidden' => $data['is_hidden'],
        'data_table' => $data['data_table'],
        'order' => $data['order'],
        'category_inside' => $data['category_inside'],
        'category_inside_order' => $data['category_inside_order']
    ]);

    return $wpdb->insert_id; // trả về ID của row vừa chèn
}

?>