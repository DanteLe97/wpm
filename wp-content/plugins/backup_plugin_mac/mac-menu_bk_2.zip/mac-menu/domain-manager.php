<?php
/**
 * MAC Menu Domain Manager
 * 
 * @package MAC Menu
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class MAC_Menu_Domain_Manager {
    private static $instance = null;
    private $current_version;
    private $plugin_file;

    // Constants
    const DEFAULT_VERSION = '1.0.1';
    const TIMEOUT = 45;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
        $this->init_hooks();
    }

    private function init() {
        $this->plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $this->current_version = $this->get_plugin_version();
    }

    private function init_hooks() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
        add_action('wp_ajax_nopriv_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
    }

    private function get_plugin_version() {
        if (is_admin() && function_exists('get_plugin_data')) {
            $plugin_data = get_plugin_data($this->plugin_file);
            return isset($plugin_data['Version']) ? $plugin_data['Version'] : self::DEFAULT_VERSION;
        }
        return self::DEFAULT_VERSION;
    }

    public function enqueue_scripts() {
        wp_localize_script('admin-script', 'kvp_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac_menu_domain_nonce')
        ));
    }

    public function handle_check_request($key_domain_check = null) {
        if (empty($key_domain_check)) {
            $this->reset_domain_options();
            return;
        }

        $api_url = MAC_MENU_VALIDATE_KEY;
        $domain = get_site_url();
        
        $response = $this->make_api_request($api_url, array(
            'key' => $key_domain_check,
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            error_log('MAC Menu Domain Check Error: ' . $response->get_error_message());
            return;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        $this->process_domain_response($data, $key_domain_check);
    }

    public function handle_check_request_url() {
        $api_url = MAC_MENU_VALIDATE_URL;
        $domain = get_site_url();
        
        $response = $this->make_api_request($api_url, array(
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            error_log('MAC Menu Domain URL Check Error: ' . $response->get_error_message());
            return;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        $this->process_domain_response($data);
    }

    public function handle_ajax_request() {
        // Verify nonce if it exists
        if (isset($_POST['nonce'])) {
            if (!wp_verify_nonce($_POST['nonce'], 'mac_menu_domain_nonce')) {
                wp_send_json_error('Invalid security token.');
                return;
            }
        }

        if (!isset($_POST['key'])) {
            wp_send_json_error('Key is required.');
            return;
        }

        $key = sanitize_text_field($_POST['key']);
        $api_url = MAC_MENU_REGISTER_DOMAIN;
        $domain = get_site_url();

        $response = $this->make_api_request($api_url, array(
            'key' => $key,
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            wp_send_json_error('API request failed: ' . $response->get_error_message());
            return;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            wp_send_json_error('Empty response from server.');
            return;
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error('Invalid response format from server.');
            return;
        }

        $this->process_ajax_response($data);
    }

    private function make_api_request($url, $body) {
        return wp_remote_post($url, array(
            'method' => 'POST',
            'body' => $body,
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded'
            )
        ));
    }

    private function process_domain_response($data, $key = null) {
        if (!isset($data['valid']) || !$data['valid']) {
            $this->reset_domain_options();
            return;
        }

        $current_status = get_option('mac_domain_valid_status', '0');
        
        if ($current_status !== $data['statusDomain']) {
            $this->update_domain_options($data);
            $this->reload_page();
        }
    }

    private function process_ajax_response($data) {
        if (!isset($data['valid']) || !$data['valid']) {
            wp_send_json_error($data['message'] ?? 'Invalid key.');
            return;
        }

        $this->update_domain_options($data);
        
        // Send a simple success message instead of an object
        wp_send_json_success($data['message'] ?? 'Key is valid!');
    }

    private function update_domain_options($data) {
        update_option('mac_domain_valid_key', $data['keyDomain']);
        update_option('mac_domain_valid_status', $data['statusDomain']);

        if (in_array($data['statusDomain'], array('activate', 'deactivate'))) {
            update_option('mac_menu_github_key', $data['keytoken']);
        } else {
            update_option('mac_menu_github_key', null);
        }
    }

    private function reset_domain_options() {
        update_option('mac_domain_valid_key', null);
        update_option('mac_domain_valid_status', null);
        update_option('mac_menu_github_key', null);
    }

    private function reload_page() {
        ?>
        <script type="text/javascript">
            window.location.reload();
        </script>
        <?php
    }
}

// Initialize the domain manager
if (defined('ABSPATH')) {
    add_action('plugins_loaded', array('MAC_Menu_Domain_Manager', 'get_instance'));
}

// Wrapper functions for backward compatibility
function kvp_enqueue_scripts() {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->enqueue_scripts();
}

function kvp_handle_check_request($keyDomainCheck = null) {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->handle_check_request($keyDomainCheck);
}

function kvp_handle_check_request_url() {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->handle_check_request_url();
}

function kvp_handle_ajax_request() {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->handle_ajax_request();
}

// Register the old function hooks
add_action('admin_enqueue_scripts', 'kvp_enqueue_scripts');
add_action('wp_ajax_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
add_action('wp_ajax_nopriv_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
