<?php
// Activity Log Page for MAC Menu Plugin
if (!defined('ABSPATH')) {
    exit;
}

// Ensure user has permission
if (!current_user_can('edit_dashboard')) {
    wp_die('You do not have sufficient permissions to access this page.');
}

// Ensure activity log table exists
force_create_activity_log_table();

// Handle pagination
$page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Handle filters
$action_type_filter = isset($_GET['action_type']) ? sanitize_text_field($_GET['action_type']) : '';
$date_filter = isset($_GET['date_filter']) ? sanitize_text_field($_GET['date_filter']) : '';

// Get logs
$logs = get_activity_logs($per_page, $offset, $action_type_filter);
$total_logs = get_activity_log_count($action_type_filter);
$total_pages = ceil($total_logs / $per_page);

// Get unique action types for filter
global $wpdb;
$table_name = $wpdb->prefix . 'mac_menu_activity_log';
$action_types = $wpdb->get_col("SELECT DISTINCT action_type FROM $table_name ORDER BY action_type");
?>

<div class="wrap">
    <h1 class="wp-heading-inline">MAC Menu Activity Log</h1>
    
    <div class="tablenav top">
        <div class="alignleft actions">
            <form method="get" action="">
                <input type="hidden" name="page" value="mac-menu-activity-log">
                
                <select name="action_type">
                    <option value="">All Actions</option>
                    <?php foreach ($action_types as $type): ?>
                        <option value="<?php echo esc_attr($type); ?>" <?php selected($action_type_filter, $type); ?>>
                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $type))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <input type="submit" class="button" value="Filter">
            </form>
        </div>
        
        <div class="tablenav-pages">
            <?php if ($total_pages > 1): ?>
                <span class="displaying-num"><?php printf('%d items', $total_logs); ?></span>
                <span class="pagination-links">
                    <?php
                    $page_links = paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('&laquo;'),
                        'next_text' => __('&raquo;'),
                        'total' => $total_pages,
                        'current' => $page
                    ));
                    echo $page_links;
                    ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th scope="col" class="manage-column column-date">Date/Time</th>
                <th scope="col" class="manage-column column-action">Action</th>
                <th scope="col" class="manage-column column-description">Description</th>
                <th scope="col" class="manage-column column-table">Table</th>
                <th scope="col" class="manage-column column-records">Records</th>
                <th scope="col" class="manage-column column-user">User</th>
                <th scope="col" class="manage-column column-error">Error</th>
            </tr>
        </thead>
        
        <tbody>
            <?php if (empty($logs)): ?>
                <tr>
                    <td colspan="7">No activity logs found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td class="column-date">
                            <?php 
                            // Display Hanoi time (already stored in Hanoi timezone)
                            echo esc_html($log->created_at);
                            ?>
                        </td>
                        <td class="column-action">
                            <span class="action-type action-<?php echo esc_attr($log->action_type); ?>">
                                <?php echo esc_html(ucfirst(str_replace('_', ' ', $log->action_type))); ?>
                            </span>
                        </td>
                        <td class="column-description">
                            <div class="desc-wrap">
                                <div class="desc-content is-collapsed">
                                    <?php 
                                    if ($log->old_data && $log->new_data) {
                                        // Hiển thị dữ liệu từ 2 cột riêng biệt
                                        $old_data = json_decode($log->old_data, true);
                                        $new_data = json_decode($log->new_data, true);
                                        
                                        if ($old_data && $new_data) {
                                            echo "<div class='data-comparison'>";
                                            echo "<div class='old-data'>";
                                            echo "<strong>Dữ liệu cũ:</strong><br>";
                                            foreach ($old_data as $field => $value) {
                                                if (isset($new_data[$field]) && $new_data[$field] !== $value) {
                                                    echo "<span style='color: #999;'>$field: " . (is_array($value) ? json_encode($value) : $value) . "</span><br>";
                                                }
                                            }
                                            echo "</div>";
                                            echo "<div class='new-data'>";
                                            echo "<strong>Dữ liệu mới:</strong><br>";
                                            foreach ($new_data as $field => $value) {
                                                if (isset($old_data[$field]) && $old_data[$field] !== $value) {
                                                    echo "<span style='color: #d32f2f; font-weight: bold;'>$field: " . (is_array($value) ? json_encode($value) : $value) . "</span><br>";
                                                }
                                            }
                                            echo "</div>";
                                            echo "</div>";
                                        } else {
                                            echo wp_kses_post($log->action_description);
                                        }
                                    } else {
                                        echo wp_kses_post($log->action_description);
                                    }
                                    ?>
                                </div>
                                <button type="button" class="button-link toggle-desc" aria-expanded="false">Show all</button>
                            </div>
                        </td>
                        <td class="column-table">
                            <?php echo esc_html($log->affected_table ?: '-'); ?>
                        </td>
                        <td class="column-records">
                            <?php echo esc_html($log->affected_records ?: '-'); ?>
                        </td>
                        <td class="column-user">
                            <?php echo esc_html($log->user_name ?: 'System'); ?>
                        </td>
                        <td class="column-error">
                            <?php if ($log->error_message): ?>
                                <span class="error-message" title="<?php echo esc_attr($log->error_message); ?>">
                                    <?php echo esc_html(substr($log->error_message, 0, 50)) . (strlen($log->error_message) > 50 ? '...' : ''); ?>
                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="tablenav bottom">
        <div class="alignleft actions">
            <form method="get" action="">
                <input type="hidden" name="page" value="mac-menu-activity-log">
                
                <select name="action_type">
                    <option value="">All Actions</option>
                    <?php foreach ($action_types as $type): ?>
                        <option value="<?php echo esc_attr($type); ?>" <?php selected($action_type_filter, $type); ?>>
                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $type))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <input type="submit" class="button" value="Filter">
            </form>
        </div>
        
        <div class="tablenav-pages">
            <?php if ($total_pages > 1): ?>
                <span class="displaying-num"><?php printf('%d items', $total_logs); ?></span>
                <span class="pagination-links">
                    <?php echo $page_links; ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.action-type {
    padding: 2px 8px;
    border-radius: 3px;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
}

.action-import_replace {
    background-color: #d4edda;
    color: #155724;
}

.action-import_append {
    background-color: #d1ecf1;
    color: #0c5460;
}

.action-settings_update {
    background-color: #fff3cd;
    color: #856404;
}

.action-crm_error {
    background-color: #f8d7da;
    color: #721c24;
}

.action-import_error {
    background-color: #f8d7da;
    color: #721c24;
}

.action-plugin_activate {
    background-color: #d4edda;
    color: #155724;
}

.action-plugin_deactivate {
    background-color: #f8d7da;
    color: #721c24;
}

.action-plugin_update {
    background-color: #d1ecf1;
    color: #0c5460;
}

.action-category_update {
    background-color: #e2e3e5;
    color: #383d41;
}

.action-category_create {
    background-color: #d4edda;
    color: #155724;
}

.action-category_delete {
    background-color: #f8d7da;
    color: #721c24;
}

.error-message {
    color: #dc3545;
    font-style: italic;
}

.data-comparison {
    display: flex;
    gap: 20px;
    margin: 10px 0;
}

.old-data, .new-data {
    flex: 1;
    padding: 10px;
    border-radius: 4px;
    font-size: 12px;
    line-height: 1.4;
}

.old-data {
    background-color: #f8f9fa;
    border-left: 3px solid #999;
}

.new-data {
    background-color: #fff3cd;
    border-left: 3px solid #d32f2f;
}

.old-data strong, .new-data strong {
    display: block;
    margin-bottom: 8px;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.old-data span, .new-data span {
    display: block;
    margin-bottom: 4px;
    word-break: break-word;
}

.desc-wrap {
    max-width: 100%;
}

.desc-content {
    max-height: 160px;
    overflow: hidden;
    position: relative;
}

.desc-content.is-collapsed:after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 40px;
    background: linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,1));
}

.desc-content.is-expanded {
    max-height: none;
}

.toggle-desc {
    margin-top: 6px;
}
</style>

<script>
document.addEventListener('click', function(e){
    if(e.target && e.target.classList.contains('toggle-desc')){
        var wrap = e.target.closest('.desc-wrap');
        if(!wrap) return;
        var content = wrap.querySelector('.desc-content');
        if(!content) return;
        var isExpanded = content.classList.toggle('is-expanded');
        content.classList.toggle('is-collapsed', !isExpanded);
        e.target.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
        e.target.textContent = isExpanded ? 'Hide' : 'Show all';
    }
});
</script>
