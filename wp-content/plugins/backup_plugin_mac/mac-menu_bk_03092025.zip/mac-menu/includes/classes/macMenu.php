<?php
class macMenu {
    private $_cat_menu = '';
    public function __construct(){
        global $wpdb;
        $this->_cat_menu = $wpdb->prefix.'mac_cat_menu';
    }
    public function get_cat_menu_name() {
        return $this->_cat_menu;
    }
    /* list cat */
    public function all_cat(){
        global $wpdb;
        $sql = "SELECT * FROM $this->_cat_menu WHERE `is_hidden` = '0' ORDER BY `order`  ASC";
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function find_cat_menu($id){
        global $wpdb;
        // Nếu id không phải số (ví dụ 'new') thì bỏ qua
        if (!is_numeric($id)) {
            return array();
        }
        $sql = $wpdb->prepare("SELECT * FROM $this->_cat_menu WHERE `id` = %d", intval($id));
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function find_cat_menu_by_name($name){
        global $wpdb;
        //$sql = "SELECT * FROM $this->_cat_menu WHERE `category_name` = '$name'";
        $sql = $wpdb->prepare("SELECT * FROM $this->_cat_menu WHERE category_name = %s  and `is_hidden` = '0' ",$name);
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function find_cat_menu_by_name_all_child_cats($names) {
        global $wpdb;
    
        if (!is_array($names) || empty($names)) {
            return []; // Trả về mảng rỗng nếu đầu vào không phải là mảng hoặc mảng rỗng
        }
    
        // Thoát chuỗi để tránh SQL injection
        $names_placeholder = implode(',', array_map(function($name) use ($wpdb) {
            return $wpdb->prepare('%s', $name);
        }, $names));
        var_dump($names_placeholder);
        // Xây dựng câu truy vấn SQL
        $sql = "
            SELECT *
            FROM $this->_cat_menu
            WHERE `category_name` IN ($names_placeholder)
                OR `parents_category` IN (
                    SELECT `id`
                    FROM $this->_cat_menu AS sub1
                    WHERE sub1.`parents_category` IN ($names_placeholder)
                    OR sub1.`parents_category` IN (
                        SELECT `id`
                        FROM $this->_cat_menu AS sub2
                        WHERE sub2.`parents_category` IN ($names_placeholder)
                        OR sub2.`parents_category` IN (
                            SELECT `id`
                            FROM $this->_cat_menu AS sub3
                            WHERE sub3.`parents_category` IN ($names_placeholder)
                            OR sub3.`parents_category` IN (
                                SELECT `id`
                                FROM $this->_cat_menu AS sub4
                                WHERE sub4.`parents_category` IN ($names_placeholder)
                            )
                        )
                    )
                )
            and `is_hidden` = '0'
            ORDER BY `order` ASC
        ";
        // Thực thi truy vấn và kiểm tra lỗi
        $items = $wpdb->get_results($sql);
    
        if ($wpdb->last_error) {
            // In lỗi cơ sở dữ liệu nếu có
            echo 'Database error: ' . $wpdb->last_error;
        }
    
        return $items;
    }
    public function find_cat_menu_all_child_cats($ids) {
        global $wpdb;
    
        if (!is_array($ids) || empty($ids)) {
            return []; // Trả về mảng rỗng nếu đầu vào không phải là mảng hoặc mảng rỗng
        }
    
        // Chuyển mảng các ID thành một chuỗi các giá trị được phân tách bởi dấu phẩy
        $ids_placeholder = implode(',', array_map('intval', $ids));
    
        $sql = "
            SELECT *
            FROM $this->_cat_menu
            WHERE (`id` IN ($ids_placeholder)
                OR `parents_category` IN ($ids_placeholder)
                OR `parents_category` IN (
                    SELECT `id`
                    FROM $this->_cat_menu AS sub1
                    WHERE sub1.`parents_category` IN ($ids_placeholder)
                    OR sub1.`parents_category` IN (
                        SELECT `id`
                        FROM $this->_cat_menu AS sub2
                        WHERE sub2.`parents_category` IN ($ids_placeholder)
                        OR sub2.`parents_category` IN (
                            SELECT `id`
                            FROM $this->_cat_menu AS sub3
                            WHERE sub3.`parents_category` IN ($ids_placeholder)
                            OR sub3.`parents_category` IN (
                                SELECT `id`
                                FROM $this->_cat_menu AS sub4
                                WHERE sub4.`parents_category` IN ($ids_placeholder)
                            )
                        )
                    )
                )
				)
                AND `is_hidden` = '0'
                ORDER BY `order` ASC
        ";
    
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function save_cat($data){
        global $wpdb;
        $wpdb->insert($this->_cat_menu, $data);
        $lastId = $wpdb->insert_id;
        
        // Log the creation with detailed data
        if (function_exists('log_activity')) {
            $category_name = $data['category_name'] ?? 'Unknown';
            
            // Log detailed creation data
            $detailed_log = "=== CATEGORY CREATION DETAILS ===\n";
            $detailed_log .= "New Category ID: $lastId\n";
            $detailed_log .= "Category Name: $category_name\n";
            $detailed_log .= "Timestamp: " . date('Y-m-d H:i:s') . "\n\n";
            
            $detailed_log .= "=== ALL CREATED DATA ===\n";
            foreach ($data as $field => $value) {
                $detailed_log .= "$field: " . (is_array($value) ? json_encode($value) : $value) . "\n";
            }
            
            // Disabled: detailed file logs are no longer written to disk
            
            $description = "Created new category: '$category_name'";
            log_activity('category_create', $description, 'mac_cat_menu', 1);
        }
        
        $item = $this->find_cat_menu($lastId);
        return $item;
    }
    public function update_cat($id,$data){
        global $wpdb;
        
        // Get current data for comparison
        $current_data = $this->find_cat_menu($id);
        if (empty($current_data)) {
            return false;
        }
        
        $current = $current_data[0];
        
        // Compare all fields to detect changes
        $changed_fields = array();
        $old_values = array();
        $new_values = array();
        
        foreach ($data as $key => $new_value) {
            $old_value = $current->$key ?? '';
            
            // Handle different data types for comparison
            if (is_array($new_value)) {
                $new_value = json_encode($new_value);
            }
            if (is_array($old_value)) {
                $old_value = json_encode($old_value);
            }
            
            // Convert to string for comparison
            $new_value = (string)$new_value;
            $old_value = (string)$old_value;
            
            if ($new_value !== $old_value) {
                $changed_fields[] = $key;
                $old_values[$key] = $old_value;
                $new_values[$key] = $new_value;
            }
        }
        
        // Only update if there are changes
        if (empty($changed_fields)) {
            return $current_data; // No changes, return current data
        }
        
        // Log the update with simplified changes
        if (function_exists('log_activity')) {
            $category_name = $current->category_name ?? 'Unknown';
            
            // Log to activity log - SIMPLE: log exactly what was saved to database
            $changes_description = array();
            foreach ($changed_fields as $field) {
                $old_val = $old_values[$field];
                $new_val = $new_values[$field];
                
                // Log exactly what was saved with HTML formatting
                $changes_description[] = "$field: '<span style=\"color: #999;\">$old_val</span>' → '<span style=\"color: #d32f2f; font-weight: bold;\">$new_val</span>'";
            }
            
            $description = "Updated category '$category_name': " . implode(', ', $changes_description);
            
            // Prepare old and new data for separate columns (update_cat_inside function)
            $old_data_json = json_encode($current_data[0], JSON_PRETTY_PRINT);
            $new_data_json = json_encode($update_data, JSON_PRETTY_PRINT);
            
            log_activity('category_update', $description, 'mac_cat_menu', 1, null, $old_data_json, $new_data_json);
            
            // Disabled: per-update file logs are no longer written to disk
        }
        
        // Perform the update
        $result = $wpdb->update(
            $this->_cat_menu,
            $data,
            ['id' => $id]
        );
        
        if ($result === false) {
            if (function_exists('log_activity')) {
                log_activity('database_error', "Failed to update category ID: $id", 'mac_cat_menu', 0, $wpdb->last_error);
            }
            return false;
        }
        
        return $this->find_cat_menu($id);
    }
    public function update_cat_inside($id, $data) {
        global $wpdb;
        
        // Lấy dữ liệu hiện tại
        $current_data = $this->find_cat_menu($id);
        if (empty($current_data)) {
            return false;
        }
        
        // Chỉ giữ lại những trường có thay đổi
        $update_data = array();
        foreach ($data as $key => $value) {
            if ($current_data[0]->$key !== $value) {
                $update_data[$key] = $value;
            }
        }
        
        // Nếu không có trường nào thay đổi, return luôn
        if (empty($update_data)) {
            return $current_data;
        }
        
        // Log the update with simplified changes
        if (function_exists('log_activity') && !empty($update_data)) {
            $category_name = $current_data[0]->category_name ?? 'Unknown';
            
            // Log to activity log - SIMPLE: log exactly what was saved to database
            $changes_description = array();
            foreach ($update_data as $field => $new_value) {
                $old_value = $current_data[0]->$field ?? '';
                
                // Handle different data types for comparison
                if (is_array($new_value)) {
                    $new_value_str = json_encode($new_value);
                } else {
                    $new_value_str = (string)$new_value;
                }
                if (is_array($old_value)) {
                    $old_value_str = json_encode($old_value);
                } else {
                    $old_value_str = (string)$old_value;
                }
                
                // Log exactly what was saved with HTML formatting
                $changes_description[] = "$field: '<span style=\"color: #999;\">$old_value_str</span>' → '<span style=\"color: #d32f2f; font-weight: bold;\">$new_value_str</span>'";
            }
            
            $description = "Updated category '$category_name': " . implode(', ', $changes_description);
            
            // Prepare old and new data for separate columns (update_cat_inside function)
            $old_data_json = json_encode($current_data[0], JSON_PRETTY_PRINT);
            $new_data_json = json_encode($update_data, JSON_PRETTY_PRINT);
            
            log_activity('category_update', $description, 'mac_cat_menu', 1, null, $old_data_json, $new_data_json);
            
            // Disabled: per-update file logs are no longer written to disk
        }
        
        // Update chỉ những trường thay đổi
        $wpdb->update(
            $this->_cat_menu, 
            $update_data,
            ['id' => $id]
        );
        
        // Return dữ liệu mới
        return $this->find_cat_menu($id);
    }
    public function destroy_Cat($id){
        global $wpdb;
    
        // Get category info before deletion for logging
        $category_data = $this->find_cat_menu($id);
        $category_name = $category_data[0]->category_name ?? 'Unknown';
        
        // Lấy tất cả id con của $id
        $child_ids = $wpdb->get_col(
            $wpdb->prepare("SELECT id FROM $this->_cat_menu WHERE parents_category = %d", $id)
        );
    
        // Đệ quy xóa từng id con
        foreach ($child_ids as $child_id) {
            $this->destroy_Cat($child_id);
        }
    
        // Xóa chính nó
        $wpdb->delete($this->_cat_menu, [ 'id' => $id ]);
        
        // Log the deletion
        if (function_exists('log_activity')) {
            $child_count = count($child_ids);
            $description = "Deleted category '$category_name' with $child_count child categories";
            log_activity('category_delete', $description, 'mac_cat_menu', 1 + $child_count);
        }
        
        return true;
    }
    // public function destroy_Cat($id){
    //     global $wpdb;
    //     $wpdb->delete($this->_cat_menu,[
    //         'id' => $id
    //     ]);
    //     return true;
    // }
    public function paginate_cat($limit = 100){
        global $wpdb;

        $s = isset( $_REQUEST['s'] ) ? $_REQUEST['s'] : '';
        $paged = isset( $_REQUEST['paged'] ) ? $_REQUEST['paged'] : 1;

        // Lấy tổng số records
        //$sql = "SELECT count(id) FROM $this->_cat_menu ";
        $sql = "SELECT count(id) FROM $this->_cat_menu WHERE `parents_category` = '0'";
        // Tim kiếm
        if( $s ){
            $sql .= " AND ( id LIKE '%$s%' )";
        }
        $total_items = $wpdb->get_var($sql);
        
        // Thuật toán phân trang
        /*
        Limit: limit
        Tổng số trang: total_pages
        Tính offset
        */
        $total_pages    = ceil( $total_items / $limit );
        $offset         = ( $paged * $limit ) - $limit;

        //$sql = "SELECT * FROM $this->_cat_menu WHERE `parents_category` = '0'";
        $sql = "
            SELECT t1.*
            FROM $this->_cat_menu AS t1
            LEFT JOIN $this->_cat_menu AS t2 ON t1.parents_category = t2.id
            WHERE t1.parents_category = 0 OR (t1.parents_category != 0 AND t2.id IS NULL)
        ";
        //$sql = "SELECT * FROM $this->_cat_menu ";
        // Tim kiếm
        if( $s ){
            $sql .= " AND ( id LIKE '%$s%' )";
        }
        $sql .= " ORDER BY `order` ASC";
        $sql .= " LIMIT $limit OFFSET $offset";


        $items = $wpdb->get_results($sql);

        return [
            'total_pages'   => $total_pages,
            'total_items'   => $total_items,
            'items'         => $items
        ];

    }
    /* all  */
    public function all_cat_by_not_is_table(){
        global $wpdb;
        $sql = "SELECT *
                FROM $this->_cat_menu WHERE 
                `is_table` = '0' ORDER BY `order` ASC ";

        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function all_cat_menu_has_item(){
        global $wpdb;
        $sql = "SELECT *
        FROM $this->_cat_menu WHERE `parents_category` = '0' and `is_hidden` = '0' ORDER BY `order` ASC";

        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function all_cat_by_parent_cat_menu($id){
        global $wpdb;
        // Nếu id không phải số (ví dụ 'new') thì bỏ qua
        if (!is_numeric($id)) {
            return array();
        }
        $sql = $wpdb->prepare(
            "SELECT * FROM $this->_cat_menu WHERE `parents_category` = %d ORDER BY `order` ASC ",
            intval($id)
        );
        $items = $wpdb->get_results($sql);
        return $items;
    }
    public function all_cat_by_parent_cat_menu_html($id){
        global $wpdb;
        // Nếu id không phải số (ví dụ 'new') thì bỏ qua
        if (!is_numeric($id)) {
            return array();
        }
        $sql = $wpdb->prepare(
            "SELECT * FROM $this->_cat_menu WHERE `parents_category` = %d and `is_hidden` = '0' ORDER BY `order` ASC ",
            intval($id)
        );
        $items = $wpdb->get_results($sql);
        return $items;
    }
    
    public function change_status($order_id,$status){
        global $wpdb;
        $wpdb->update(
            $this->_menu, 
            [
                'status' => $status
            ], 
            [
                'id' => $order_id
            ]
        );
        return true;
    }
    public function change_position($id,$position){
        global $wpdb;
        $wpdb->update(
            $this->_cat_menu, 
            
            [
                'order' => $position
            ],
            [
                'ID' => $id
            ]
        );
        
        return true;
    }
    public function change_position_cat($id,$position){
        global $wpdb;
        $wpdb->update(
            $this->_menu, 
            
            [
                'order' => $position
            ],
            [
                'ID' => $id
            ]
        );
        
        return true;
    }

    public function getAllIdCatChildInside($id_category) {
        $arrayCatId = array();
        $objmacMenu = new macMenu();
        $result = $objmacMenu->all_cat_by_parent_cat_menu($id_category);
       
            foreach( $result as $item ){
                if ($item->category_inside == 1){
                    $arrayCatId[] = $item->id;
                }
            }
      
        return $arrayCatId;
    }
    public function getAllIdCatChildInsideHTML($id_category) {
        $arrayCatId = array();
        $objmacMenu = new macMenu();
        $result = $objmacMenu->all_cat_by_parent_cat_menu_html($id_category);
       
            foreach( $result as $item ){
                if ($item->category_inside == 1){
                    $arrayCatId[] = $item->id;
                }
            }
      
        return $arrayCatId;
    }
}


class MacMenuActivityLog {
	private $_activity_log = '';

	public function __construct() {
		global $wpdb;
		$this->_activity_log = $wpdb->prefix . 'mac_menu_activity_log';
	}

	public function createTable() {
		global $wpdb;
		$table_name = $this->_activity_log;
		$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
		if ($table_exists) { return; }
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $table_name (
			id int(11) NOT NULL AUTO_INCREMENT,
			action_type varchar(50) NOT NULL,
			action_description text,
			old_data longtext,
			new_data longtext,
			affected_table varchar(100),
			affected_records int(11),
			user_id int(11),
			user_name varchar(100),
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			additional_data longtext,
			error_message text,
			error_code varchar(50),
			plugin_version varchar(20),
			PRIMARY KEY (id),
			KEY idx_created_at (created_at),
			KEY idx_action_type (action_type)
		) $charset_collate;";
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}

	public function forceCreateTable() {
		global $wpdb;
		$table_name = $this->_activity_log;
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id int(11) NOT NULL AUTO_INCREMENT,
			action_type varchar(50) NOT NULL,
			action_description text,
			old_data longtext,
			new_data longtext,
			affected_table varchar(100),
			affected_records int(11),
			user_id int(11),
			user_name varchar(100),
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			additional_data longtext,
			error_message text,
			error_code varchar(50),
			plugin_version varchar(20),
			PRIMARY KEY (id),
			KEY idx_created_at (created_at),
			KEY idx_action_type (action_type)
		) $charset_collate;";
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
		$this->migrateDropUnusedColumns();
	}

	public function migrateDropUnusedColumns() {
		global $wpdb;
		$table_name = $this->_activity_log;
		$columns = $wpdb->get_col( $wpdb->prepare(
			"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
			DB_NAME,
			$table_name
		));
		if (!$columns) { return; }
		if (in_array('ip_address', $columns, true)) {
			$wpdb->query("ALTER TABLE $table_name DROP COLUMN ip_address");
		}
		if (in_array('wp_version', $columns, true)) {
			$wpdb->query("ALTER TABLE $table_name DROP COLUMN wp_version");
		}
	}

	public function log($action_type, $description, $table = null, $records = 0, $error = null, $old_data = null, $new_data = null) {
		global $wpdb;
		$this->createTable();
		$table_name = $this->_activity_log;
		$current_user = wp_get_current_user();
		$user_id = $current_user->ID;
		$user_name = $current_user->display_name;
		if ( ! function_exists('get_plugin_data') ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugin_version = '';
		$plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/mac-menu/mac-menu.php', false, false);
		if ( ! empty($plugin_data['Version']) ) { $plugin_version = $plugin_data['Version']; }
		$hanoi_timezone = new DateTimeZone('Asia/Ho_Chi_Minh');
		$hanoi_datetime = new DateTime('now', $hanoi_timezone);
		$hanoi_timestamp = $hanoi_datetime->format('Y-m-d H:i:s');
		$data = array(
			'action_type' => $action_type,
			'action_description' => $description,
			'old_data' => $old_data,
			'new_data' => $new_data,
			'affected_table' => $table,
			'affected_records' => $records,
			'user_id' => $user_id,
			'user_name' => $user_name,
			'error_message' => $error,
			'plugin_version' => $plugin_version,
			'created_at' => $hanoi_timestamp
		);
		$wpdb->insert($table_name, $data);
		$this->cleanup();
	}

	public function cleanup() {
		global $wpdb;
		$table_name = $this->_activity_log;
		$hanoi_timezone = new DateTimeZone('Asia/Ho_Chi_Minh');
		$hanoi_datetime = new DateTime('now', $hanoi_timezone);
		$hanoi_datetime->sub(new DateInterval('P30D'));
		$cutoff_date = $hanoi_datetime->format('Y-m-d H:i:s');
		$wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE created_at < %s", $cutoff_date));
	}

	public function getLogs($limit = 50, $offset = 0, $action_type = null) {
		global $wpdb;
		$table_name = $this->_activity_log;
		$where_clause = '';
		if ($action_type) {
			$where_clause = $wpdb->prepare(" WHERE action_type = %s", $action_type);
		}
		$sql = "SELECT * FROM $table_name" . $where_clause . " ORDER BY created_at DESC LIMIT %d OFFSET %d";
		$sql = $wpdb->prepare($sql, $limit, $offset);
		return $wpdb->get_results($sql);
	}

	public function getLogCount($action_type = null) {
		global $wpdb;
		$table_name = $this->_activity_log;
		$where_clause = '';
		if ($action_type) {
			$where_clause = $wpdb->prepare(" WHERE action_type = %s", $action_type);
		}
		$sql = "SELECT COUNT(*) FROM $table_name" . $where_clause;
		return (int) $wpdb->get_var($sql);
	}

	// Static helper wrappers for backward compatibility
	public static function createTableStatic() { (new self())->createTable(); }
	public static function forceCreateTableStatic() { (new self())->forceCreateTable(); }
	public static function migrateDropUnusedColumnsStatic() { (new self())->migrateDropUnusedColumns(); }
	public static function logStatic($action_type, $description, $table = null, $records = 0, $error = null, $old_data = null, $new_data = null) {
		(new self())->log($action_type, $description, $table, $records, $error, $old_data, $new_data);
	}
	public static function cleanupStatic() { (new self())->cleanup(); }
	public static function getLogsStatic($limit = 50, $offset = 0, $action_type = null) { return (new self())->getLogs($limit, $offset, $action_type); }
	public static function getLogCountStatic($action_type = null) { return (new self())->getLogCount($action_type); }
}