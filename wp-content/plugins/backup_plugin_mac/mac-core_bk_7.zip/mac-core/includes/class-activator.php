<?php
namespace MAC_Core;

class Activator {
    public static function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Create licenses table
        $table_name = $wpdb->prefix . 'mac_licenses';
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            plugin_slug varchar(255) NOT NULL,
            license_key varchar(255) NOT NULL,
            status varchar(50) NOT NULL,
            expires_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY plugin_slug (plugin_slug)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Add default options
        add_option('mac_core_api_url', 'https://api.mac-marketing.com');
        add_option('mac_core_api_key', '');
        add_option('mac_core_debug_mode', '0');
        
        // Migrate domain manager data from MAC Menu
        self::migrate_domain_manager();
    }
    
    public static function migrate_domain_manager() {
        // Migrate options từ mac-menu
        $old_options = array(
            'mac_domain_valid_key' => 'mac_core_domain_mac-menu_key',
            'mac_domain_valid_status' => 'mac_core_domain_mac-menu_status',
            'mac_menu_github_key' => 'mac_core_domain_mac-menu_github_key'
        );
        
        foreach ($old_options as $old_key => $new_key) {
            $value = get_option($old_key);
            if ($value !== false) {
                update_option($new_key, $value);
                // Không xóa option cũ để tránh conflict
                // delete_option($old_key);
            }
        }
    }
} 