<?php
// Test CRM API endpoint
require_once('wp-config.php');

// Test function
function test_crm_api() {
    $url = 'https://wpm.macusaone.com/api/v1/plugins/mac-menu';
    
    $body = array(
        'url' => 'http://localhost/wpm/',
        'key' => '6a58a8a542936e750c87f20d9234ffc6',
        'action' => 'download'
    );
    
    $args = array(
        'method' => 'POST',
        'timeout' => 45,
        'sslverify' => true,
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept' => 'application/json'
        ),
        'body' => $body,
    );
    
    echo "Testing CRM API...\n";
    echo "URL: $url\n";
    echo "Body: " . print_r($body, true) . "\n";
    
    $response = wp_remote_post($url, $args);
    
    if (is_wp_error($response)) {
        echo "Error: " . $response->get_error_message() . "\n";
        return;
    }
    
    $code = wp_remote_retrieve_response_code($response);
    $body_str = wp_remote_retrieve_body($response);
    
    echo "Response Code: $code\n";
    echo "Response Body: $body_str\n";
    
    if ($code === 200) {
        $data = json_decode($body_str, true);
        if ($data) {
            echo "Decoded JSON: " . print_r($data, true) . "\n";
        }
    }
}

// Run test
test_crm_api();
?>

