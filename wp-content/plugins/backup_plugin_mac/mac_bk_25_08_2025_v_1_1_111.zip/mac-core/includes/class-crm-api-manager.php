<?php
namespace MAC_Core;

/**
 * CRM API Manager
 * 
 * Handles all API calls to CRM for domain validation, license checking, and domain registration
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CRM_API_Manager {
    
    // API endpoints
    const VALIDATE_KEY_URL = 'https://wpm.macusaone.com/api/v1/menu-license/validate-key';
    const VALIDATE_URL_URL = 'https://wpm.macusaone.com/api/v1/menu-license/validate-url';
    const REGISTER_DOMAIN_URL = 'https://wpm.macusaone.com/api/v1/menu-license/register-domain';
    const PLUGIN_REQUEST_URL_PATTERN = 'https://wpm.macusaone.com/api/v1/plugins/{slug}';
    const CSV_IMPORT_URL = 'https://wpm.macusaone.com/api/v1/mac-menu/import_csv';
    
    // Timeout for API requests
    const TIMEOUT = 45;
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Initialize options if they don't exist
        $this->initialize_options();
    }
    
    /**
     * Initialize MAC Menu options
     */
    private function initialize_options() {
        if (false === get_option('mac_domain_valid_key')) {
            add_option('mac_domain_valid_key', '');
        }
        if (false === get_option('mac_domain_valid_status')) {
            add_option('mac_domain_valid_status', '');
        }
    }
    
    /**
     * Validate key with CRM
     */
    public function validate_key($key, $domain, $version) {
        if (empty($key)) {
            // Don't reset options for empty key, just return error
            return array('success' => false, 'message' => 'Empty key provided');
        }
        
        $response = wp_remote_post(self::VALIDATE_KEY_URL, array(
            'method' => 'POST',
            'body' => array(
                'key' => $key,
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->process_domain_response($data, $key);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Validate URL with CRM (when no key exists)
     */
    public function validate_url($domain, $version) {
        $response = wp_remote_post(self::VALIDATE_URL_URL, array(
            'method' => 'POST',
            'body' => array(
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->process_domain_response($data);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Register domain with CRM
     */
    public function register_domain($key, $domain, $version) {
        $response = wp_remote_post(self::REGISTER_DOMAIN_URL, array(
            'method' => 'POST',
            'body' => array(
                'key' => $key,
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array('success' => false, 'message' => 'Invalid response format from server');
        }
        
        $this->process_domain_response($data);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Process domain response from CRM
     */
    private function process_domain_response($data, $key = null) {
        if (!isset($data['valid']) || !$data['valid']) {
            $this->reset_domain_options();
            return;
        }
        
        $this->update_domain_options($data);
    }
    
    /**
     * Update domain options
     */
    private function update_domain_options($data) {
        update_option('mac_domain_valid_key', $data['keyDomain']);
        update_option('mac_domain_valid_status', $data['statusDomain']);
    }
    
    /**
     * Reset domain options
     */
    private function reset_domain_options() {
        update_option('mac_domain_valid_key', null);
        update_option('mac_domain_valid_status', null);
    }
    
    /**
     * Get domain status
     */
    public function get_domain_status() {
        return get_option('mac_domain_valid_status', '');
    }
    
    /**
     * Get domain key
     */
    public function get_domain_key() {
        return get_option('mac_domain_valid_key', '');
    }
    
    /**
     * Get GitHub token
     */
    public function get_github_token() {
        return get_option('mac_menu_github_key', '');
    }
    
    /**
     * Check if license is valid
     */
    public function is_license_valid() {
        return (get_option('mac_domain_valid_status', '') === 'activate');
    }

    /**
     * Download a file to a temp path; returns ['success'=>true, 'file'=>path]
     */
    public function download_file_to_tmp($download_url, $timeout = 120) {
        $tmp = wp_tempnam($download_url);
        if (!$tmp) {
            return array('success' => false, 'message' => 'Failed to create temp file');
        }

        $args = array(
            'timeout' => $timeout,
            'sslverify' => true,
            'stream' => true,
            'filename' => $tmp,
            'headers' => array(
                'Accept' => 'application/zip, application/octet-stream'
            ),
        );

        $response = wp_remote_get($download_url, $args);
        if (is_wp_error($response)) {
            @unlink($tmp);
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            @unlink($tmp);
            return array('success' => false, 'message' => 'Download HTTP ' . $code);
        }

        return array('success' => true, 'file' => $tmp);
    }



    public function get_plugin_request_url($slug) {
        $default = str_replace('{slug}', $slug, self::PLUGIN_REQUEST_URL_PATTERN);
        if (function_exists('apply_filters')) {
            $default = apply_filters('mac_core/crm_plugin_request_url', $default, $slug);
        }
        return $default;
    }

    /**
     * Check for plugin updates from CRM
     * Returns: ['success'=>true, 'data'=>['version', 'needs_update', 'current_version']]
     */
    public function check_update($slug) {
        $url = $this->get_plugin_request_url($slug);
        // Debug logging for update check
        $this->crm_log('CRM API: check_update start for slug: ' . $slug);
        $this->crm_log('CRM API: check_update URL: ' . $url);

        $site_url = get_site_url();
        // Ensure URL has trailing slash
        if (substr($site_url, -1) !== '/') {
            $site_url .= '/';
        }
        $license_key = get_option('mac_domain_valid_key', '');

        $body = array(
            'url' => $site_url,
            'key' => $license_key,
            'action' => 'check_update'
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            ),
            'body' => $body,
        );

        $this->crm_log('CRM API: check_update request body: ' . print_r($body, true));
        $this->crm_log('CRM API: check_update request headers: ' . print_r($args['headers'], true));

        $response = wp_remote_post($url, $args);
        if (is_wp_error($response)) {
            $this->crm_log('CRM API: check_update WP_Error: ' . $response->get_error_message());
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_str = wp_remote_retrieve_body($response);
        $this->crm_log('CRM API: check_update response code: ' . $code);
        $this->crm_log('CRM API: check_update response body: ' . substr($body_str, 0, 500));
        if ($code !== 200) {
            $this->crm_log('CRM API: check_update non-200 HTTP: ' . $code);
            return array('success' => false, 'message' => 'CRM request HTTP ' . $code . ($body_str ? (': ' . substr($body_str, 0, 200)) : ''));
        }

        $data = json_decode($body_str, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->crm_log('CRM API: check_update JSON decode error: ' . json_last_error_msg());
            return array('success' => false, 'message' => 'Invalid CRM response');
        }

        // Get current version from installed plugin
        $current_version = $this->get_plugin_version($slug);
        
        // Compare versions
        $needs_update = false;
        if (!empty($data['version']) && !empty($current_version)) {
            $needs_update = version_compare($data['version'], $current_version, '>');
        }

        $this->crm_log('CRM API: check_update success. Latest: ' . (isset($data['version']) ? $data['version'] : 'unknown') . ', Current: ' . $current_version);
        return array(
            'success' => true, 
            'data' => array(
                'version' => isset($data['version']) ? $data['version'] : '',
                'current_version' => $current_version,
                'needs_update' => $needs_update
            )
        );
    }

    /**
     * Request download URL for plugin installation/update
     * Returns: ['success'=>true, 'data'=>['download_url', 'version']]
     */
    public function download_plugin($slug) {
        $this->crm_log('CRM API: Starting download_plugin for slug: ' . $slug);
        $url = $this->get_plugin_request_url($slug);
        $this->crm_log('CRM API: Request URL: ' . $url);

        $site_url = get_site_url();
        // Ensure URL has trailing slash
        if (substr($site_url, -1) !== '/') {
            $site_url .= '/';
        }
        $license_key = get_option('mac_domain_valid_key', '');
        
        $this->crm_log('CRM API: Site URL: ' . $site_url);
        $this->crm_log('CRM API: License Key: ' . ($license_key ? substr($license_key, 0, 8) . '...' : 'EMPTY'));

        $body = array(
            'url' => $site_url,
            'key' => $license_key,
            'action' => 'download'
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            ),
            'body' => $body,
        );

        $this->crm_log('CRM API: Request body: ' . print_r($body, true));
        $this->crm_log('CRM API: Request headers: ' . print_r($args['headers'], true));
        $this->crm_log('CRM API: Sending request to CRM...');
        $response = wp_remote_post($url, $args);
        if (is_wp_error($response)) {
            $this->crm_log('CRM API: Request error: ' . $response->get_error_message());
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_str = wp_remote_retrieve_body($response);
        $this->crm_log('CRM API: Response code: ' . $code);
        $this->crm_log('CRM API: Response body: ' . $body_str);
        
        if ($code !== 200) {
            $this->crm_log('CRM API: HTTP error code: ' . $code);
            return array('success' => false, 'message' => 'CRM request HTTP ' . $code . ': ' . $body_str);
        }

        $data = json_decode($body_str, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->crm_log('CRM API: JSON decode error: ' . json_last_error_msg());
            return array('success' => false, 'message' => 'Invalid CRM response');
        }

        $this->crm_log('CRM API: Decoded data: ' . print_r($data, true));

        if (empty($data['download_url'])) {
            $this->crm_log('CRM API: Missing download_url in response');
            return array('success' => false, 'message' => 'CRM response missing download_url');
        }

        $this->crm_log('CRM API: Download plugin successful');
        return array('success' => true, 'data' => $data);
    }

    /**
     * Get current version of installed plugin
     */
    private function get_plugin_version($slug) {
        if ($slug === 'mac-menu') {
            $plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
            if (file_exists($plugin_file)) {
                $plugin_data = get_plugin_data($plugin_file);
                return isset($plugin_data['Version']) ? $plugin_data['Version'] : '';
            }
        }
        return '';
    }

    /**
     * Upload CSV file to CRM for processing
     * Returns: ['success'=>true, 'data'=>['menu_data', 'settings']]
     */
    private function crm_log($message) {
        $log_file = WP_CONTENT_DIR . '/plugins/mac-core/crm-debug.log';
        $log_message = date('Y-m-d H:i:s') . ' ' . $message . PHP_EOL;
        file_put_contents($log_file, $log_message, FILE_APPEND);
    }

    public function upload_csv_to_crm($csv_file_path, $import_mode = 'replace') {
        $this->crm_log('=== CRM API: CSV UPLOAD TO CRM START ===');
        $this->crm_log('CRM STEP 1: Initialize upload process');
        $this->crm_log('- CSV file path: ' . $csv_file_path);
        $this->crm_log('- Import mode: ' . $import_mode);
        $this->crm_log('- File exists: ' . (file_exists($csv_file_path) ? 'YES' : 'NO'));
        
        if (!file_exists($csv_file_path)) {
            $this->crm_log('CRM STEP 1: CSV file NOT FOUND');
            $this->crm_log('=== CRM API: CSV UPLOAD FAILED ===');
            return array('success' => false, 'message' => 'CSV file not found');
        }

        $this->crm_log('- File size: ' . filesize($csv_file_path) . ' bytes');
        
        // Use the new endpoint
        $url = self::CSV_IMPORT_URL;
        $this->crm_log('CRM STEP 2: Preparing cURL request');
        $this->crm_log('- Target URL: ' . $url);
        
        // Prepare multipart form data using cURL
        $ch = curl_init();
        
        // Create CURLFile object for file upload
        $cfile = new \CURLFile($csv_file_path, 'text/csv', basename($csv_file_path));
        $this->crm_log('- CURLFile created: ' . basename($csv_file_path));
        
        $post_data = array(
            'file' => $cfile
        );
        $this->crm_log('- Post data prepared with file upload');
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'User-Agent: MAC-Menu-Plugin/1.0'
        ));
        
        $this->crm_log('CRM STEP 3: Sending CSV to CRM endpoint...');
        $this->crm_log('- cURL options configured');
        $this->crm_log('- Timeout: 120 seconds');
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        $this->crm_log('CRM STEP 4: CRM response received');
        $this->crm_log('- HTTP status code: ' . $http_code);
        $this->crm_log('- cURL error: ' . ($curl_error ? $curl_error : 'NONE'));
        $this->crm_log('- Response length: ' . strlen($response) . ' characters');
        $this->crm_log('- Response preview: ' . substr($response, 0, 200) . '...');
        
        if ($curl_error) {
            $this->crm_log('CRM STEP 4: cURL ERROR occurred');
            $this->crm_log('- Error: ' . $curl_error);
            $this->crm_log('=== CRM API: CSV UPLOAD FAILED ===');
            return array('success' => false, 'message' => 'cURL error: ' . $curl_error);
        }
        
        if ($http_code !== 200) {
            $this->crm_log('CRM STEP 4: HTTP ERROR occurred');
            $this->crm_log('- HTTP code: ' . $http_code);
            $this->crm_log('- Response body: ' . substr($response, 0, 500) . '...');
            $this->crm_log('=== CRM API: CSV UPLOAD FAILED ===');
            return array('success' => false, 'message' => 'CRM request HTTP ' . $http_code . ': ' . $response);
        }
        
        $this->crm_log('CRM STEP 5: Parsing JSON response...');
        $this->crm_log('- Raw response preview: ' . substr($response, 0, 200) . '...');
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->crm_log('CRM STEP 5: JSON DECODE ERROR');
            $this->crm_log('- JSON error: ' . json_last_error_msg());
            $this->crm_log('- Raw response: ' . $response);
            $this->crm_log('=== CRM API: CSV UPLOAD FAILED ===');
            return array('success' => false, 'message' => 'Invalid CRM response');
        }
        
        $this->crm_log('CRM STEP 5: JSON parsed successfully');
        $this->crm_log('- Data keys: ' . print_r(array_keys($data), true));
        if (isset($data['categories'])) {
            $this->crm_log('- Categories found: ' . count($data['categories']));
            if (count($data['categories']) > 0) {
                $this->crm_log('- First category sample: ' . print_r($data['categories'][0], true));
            }
        }
        if (isset($data['summary'])) {
            $this->crm_log('- Summary: ' . print_r($data['summary'], true));
        }
        if (isset($data['shop_info'])) {
            $this->crm_log('- Shop info: ' . print_r($data['shop_info'], true));
        }
        
        // Log full JSON response for debugging
        $this->crm_log('CRM STEP 5: Full JSON response from CRM:');
        $this->crm_log('- Raw JSON length: ' . strlen($response) . ' characters');
        $this->crm_log('- Raw JSON preview (first 500 chars): ' . substr($response, 0, 500));
        if (strlen($response) > 500) {
            $this->crm_log('- Raw JSON preview (last 500 chars): ' . substr($response, -500));
        }
        
        $this->crm_log('=== CRM API: CSV UPLOAD SUCCESS ===');
        return array('success' => true, 'data' => $data);
    }

    /**
     * Sync settings from CRM
     * Returns: ['success'=>true, 'data'=>['settings']]
     */
    public function sync_settings_from_crm() {
        $this->crm_log('CRM API: Starting settings sync from CRM');
        
        $site_url = get_site_url();
        if (substr($site_url, -1) !== '/') {
            $site_url .= '/';
        }
        $license_key = get_option('mac_domain_valid_key', '');

        $body = array(
            'url' => $site_url,
            'key' => $license_key,
            'action' => 'get_settings'
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            ),
            'body' => $body,
        );

        $this->crm_log('CRM API: Requesting settings from CRM...');
        $response = wp_remote_post(self::VALIDATE_KEY_URL, $args);
        
        if (is_wp_error($response)) {
            $this->crm_log('CRM API: Settings sync error: ' . $response->get_error_message());
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_str = wp_remote_retrieve_body($response);
        $this->crm_log('CRM API: Settings sync response code: ' . $code);
        $this->crm_log('CRM API: Settings sync response body: ' . $body_str);
        
        if ($code !== 200) {
            $this->crm_log('CRM API: Settings sync HTTP error: ' . $code);
            return array('success' => false, 'message' => 'CRM settings sync HTTP ' . $code . ': ' . $body_str);
        }

        $data = json_decode($body_str, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->crm_log('CRM API: Settings sync JSON decode error: ' . json_last_error_msg());
            return array('success' => false, 'message' => 'Invalid CRM settings response');
        }

        $this->crm_log('CRM API: Settings sync successful');
        return array('success' => true, 'data' => $data);
    }

    /**
     * Update settings to CRM
     * Returns: ['success'=>true, 'data'=>['message']]
     */
    public function update_settings_to_crm($settings) {
        $this->crm_log('CRM API: Starting settings update to CRM');
        
        $site_url = get_site_url();
        if (substr($site_url, -1) !== '/') {
            $site_url .= '/';
        }
        $license_key = get_option('mac_domain_valid_key', '');

        $body = array(
            'url' => $site_url,
            'key' => $license_key,
            'action' => 'update_settings',
            'settings' => json_encode($settings)
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            ),
            'body' => $body,
        );

        $this->crm_log('CRM API: Updating settings to CRM...');
        $response = wp_remote_post(self::VALIDATE_KEY_URL, $args);
        
        if (is_wp_error($response)) {
            $this->crm_log('CRM API: Settings update error: ' . $response->get_error_message());
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_str = wp_remote_retrieve_body($response);
        $this->crm_log('CRM API: Settings update response code: ' . $code);
        $this->crm_log('CRM API: Settings update response body: ' . $body_str);
        
        if ($code !== 200) {
            $this->crm_log('CRM API: Settings update HTTP error: ' . $code);
            return array('success' => false, 'message' => 'CRM settings update HTTP ' . $code . ': ' . $body_str);
        }

        $data = json_decode($body_str, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->crm_log('CRM API: Settings update JSON decode error: ' . json_last_error_msg());
            return array('success' => false, 'message' => 'Invalid CRM settings update response');
        }

        $this->crm_log('CRM API: Settings update successful');
        return array('success' => true, 'data' => $data);
    }
}
