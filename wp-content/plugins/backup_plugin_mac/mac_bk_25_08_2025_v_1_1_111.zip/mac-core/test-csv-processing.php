<?php
// Test CSV Processing with CRM
require_once('wp-config.php');

// Test function
function test_csv_processing() {
    echo "Testing CSV Processing with CRM...\n";
    
    try {
        // Check if CRM connection is active
        if (!class_exists('MAC_Core\CRM_API_Manager')) {
            echo "Error: CRM_API_Manager class not found\n";
            return;
        }
        
        $crm = MAC_Core\CRM_API_Manager::get_instance();
        echo "CRM API Manager loaded successfully\n";
        
        if (!$crm->is_license_valid()) {
            echo "Error: CRM connection not active\n";
            return;
        }
        
        echo "CRM connection is active\n";
        
        // Create a sample CSV file for testing
        $sample_csv = "id,category_name,category_description,price,featured_img,parents_category,is_hidden,is_table,table_heading,item_list_name,item_list_price,item_list_description,item_list_fw,item_list_img,item_list_position,category_inside,category_inside_order\n";
        $sample_csv .= "1,Test Category,Test Description,10.99,test.jpg,0,0,0,Test Table,Test Item,5.99,Test Item Description,0,item.jpg,1,0,1\n";
        
        $temp_file = tempnam(sys_get_temp_dir(), 'test_csv_');
        file_put_contents($temp_file, $sample_csv);
        
        echo "Created test CSV file: $temp_file\n";
        echo "CSV content:\n$sample_csv\n";
        
        // Test CSV upload to CRM
        echo "Testing CSV upload to CRM...\n";
        $result = $crm->upload_csv_to_crm($temp_file, 'replace');
        
        echo "Result: " . print_r($result, true) . "\n";
        
        // Clean up
        unlink($temp_file);
        echo "Cleaned up test file\n";
        
    } catch (Exception $e) {
        echo "Exception: " . $e->getMessage() . "\n";
        echo "Stack trace: " . $e->getTraceAsString() . "\n";
    }
}

// Run test
test_csv_processing();
echo "Test completed\n";
?>
