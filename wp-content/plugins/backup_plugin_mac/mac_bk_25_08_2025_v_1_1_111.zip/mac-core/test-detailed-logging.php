<?php
// Test detailed logging for CSV import flow
require_once('wp-config.php');

// Test function with detailed logging
function test_detailed_csv_logging() {
    echo "=== TESTING CSV IMPORT FLOW WITH DETAILED LOGGING ===\n";
    echo "Starting test at: " . date('Y-m-d H:i:s') . "\n\n";
    
    try {
        // Check if CRM connection is active
        echo "Checking CRM connection...\n";
        if (!class_exists('MAC_Core\CRM_API_Manager')) {
            echo "❌ Error: CRM_API_Manager class not found\n";
            return;
        }
        
        $crm = MAC_Core\CRM_API_Manager::get_instance();
        echo "✓ CRM API Manager loaded successfully\n";
        
        if (!$crm->is_license_valid()) {
            echo "❌ Error: CRM connection not active\n";
            return;
        }
        
        echo "✓ CRM connection is active\n\n";
        
        // Use the sample CSV file
        $csv_file = 'wp-content/plugins/mac-core/sample-menu.csv';
        
        if (!file_exists($csv_file)) {
            echo "❌ Error: Sample CSV file not found\n";
            return;
        }
        
        echo "✓ Using CSV file: $csv_file\n";
        echo "✓ CSV file size: " . filesize($csv_file) . " bytes\n\n";
        
        // Simulate the importCSV function call
        echo "=== SIMULATING importCSV() FUNCTION ===\n";
        
        $fileCSV = array(
            'name' => basename($csv_file),
            'tmp_name' => $csv_file,
            'error' => UPLOAD_ERR_OK,
            'size' => filesize($csv_file)
        );
        
        // Call the actual importCSV function
        echo "Calling importCSV function...\n";
        
        // Capture start time
        $start_time = microtime(true);
        
        // This will trigger all the detailed logging
        ob_start();
        importCSV($fileCSV, 0, '');
        $output = ob_get_clean();
        
        $end_time = microtime(true);
        $processing_time = round($end_time - $start_time, 2);
        
        echo "✓ importCSV function completed\n";
        echo "✓ Processing time: " . $processing_time . " seconds\n";
        
        if ($output) {
            echo "Function output: " . $output . "\n";
        }
        
        // Check database results
        echo "\n=== CHECKING DATABASE RESULTS ===\n";
        global $wpdb;
        $table_name = $wpdb->prefix . 'mac_cat_menu';
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        echo "✓ Total records in database: " . $count . "\n";
        
        // Show some sample records
        $sample_records = $wpdb->get_results("SELECT category_name, slug_category, parents_category FROM $table_name LIMIT 5", ARRAY_A);
        echo "✓ Sample records:\n";
        foreach ($sample_records as $record) {
            echo "  - " . $record['category_name'] . " (slug: " . $record['slug_category'] . ", parent: " . $record['parents_category'] . ")\n";
        }
        
    } catch (Exception $e) {
        echo "❌ Exception: " . $e->getMessage() . "\n";
        echo "Stack trace: " . $e->getTraceAsString() . "\n";
    }
    
    echo "\n=== TEST COMPLETED ===\n";
    echo "Check error logs for detailed flow information.\n";
}

// Run test
test_detailed_csv_logging();
?>

