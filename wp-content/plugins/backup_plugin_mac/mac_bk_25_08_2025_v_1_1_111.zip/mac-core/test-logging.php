<?php
// Test logging functionality
require_once('wp-config.php');

echo "=== TESTING LOGGING ===\n";
echo "Time: " . date('Y-m-d H:i:s') . "\n\n";

// Test basic logging
error_log('TEST LOGGING: Basic test message');
echo "✓ Basic error_log test sent\n";

// Test if CRM class exists
if (class_exists('MAC_Core\CRM_API_Manager')) {
    echo "✓ CRM_API_Manager class found\n";
    error_log('TEST LOGGING: CRM_API_Manager class exists');
    
    $crm = MAC_Core\CRM_API_Manager::get_instance();
    if ($crm->is_license_valid()) {
        echo "✓ CRM license is valid\n";
        error_log('TEST LOGGING: CRM license is valid');
        
        // Test CSV upload with logging
        $csv_file = 'wp-content/plugins/mac-core/sample-menu.csv';
        if (file_exists($csv_file)) {
            echo "✓ Sample CSV file exists\n";
            error_log('TEST LOGGING: Sample CSV file exists - ' . filesize($csv_file) . ' bytes');
            
            echo "\n=== TESTING CSV UPLOAD WITH LOGGING ===\n";
            $result = $crm->upload_csv_to_crm($csv_file, 'replace');
            
            echo "Result success: " . ($result['success'] ? 'YES' : 'NO') . "\n";
            if ($result['success']) {
                echo "Categories count: " . count($result['data']['categories']) . "\n";
            }
        } else {
            echo "❌ Sample CSV file not found\n";
        }
    } else {
        echo "❌ CRM license not valid\n";
    }
} else {
    echo "❌ CRM_API_Manager class not found\n";
}

echo "\n=== LOGGING TEST COMPLETED ===\n";
echo "Check error logs for 'TEST LOGGING:' messages\n";
?>
