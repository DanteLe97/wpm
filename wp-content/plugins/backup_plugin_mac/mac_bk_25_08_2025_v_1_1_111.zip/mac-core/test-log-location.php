<?php
// Test to find where logs are going
echo "=== TESTING LOG LOCATION ===\n";

// Test different logging methods
error_log('TEST: error_log message');
echo "✓ error_log() called\n";

// Test WordPress logging
if (function_exists('wp_debug_log')) {
    wp_debug_log('TEST: wp_debug_log message');
    echo "✓ wp_debug_log() called\n";
}

// Test file_put_contents to a known location
$test_log = 'wp-content/plugins/mac-core/test-debug.log';
file_put_contents($test_log, date('Y-m-d H:i:s') . " - TEST: file_put_contents message\n", FILE_APPEND);
echo "✓ file_put_contents() to $test_log\n";

// Check WordPress debug settings
echo "\n=== WORDPRESS DEBUG SETTINGS ===\n";
echo "WP_DEBUG: " . (defined('WP_DEBUG') && WP_DEBUG ? 'ON' : 'OFF') . "\n";
echo "WP_DEBUG_LOG: " . (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG ? 'ON' : 'OFF') . "\n";
if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
    echo "WP_DEBUG_LOG file: " . WP_CONTENT_DIR . '/debug.log' . "\n";
}

// Check if debug.log exists
$wp_debug_log = WP_CONTENT_DIR . '/debug.log';
if (file_exists($wp_debug_log)) {
    echo "✓ WordPress debug.log exists\n";
    echo "Last 5 lines:\n";
    $lines = file($wp_debug_log);
    $last_lines = array_slice($lines, -5);
    foreach ($last_lines as $line) {
        echo "  " . trim($line) . "\n";
    }
} else {
    echo "❌ WordPress debug.log not found\n";
}

echo "\n=== TEST COMPLETED ===\n";
?>
