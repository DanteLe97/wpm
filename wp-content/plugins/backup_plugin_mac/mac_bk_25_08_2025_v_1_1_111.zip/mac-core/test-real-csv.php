<?php
// Test real CSV data
require_once('wp-config.php');

// Test function
function test_real_csv() {
    echo "Testing real CSV data...\n";
    
    try {
        // Check if CRM connection is active
        if (!class_exists('MAC_Core\CRM_API_Manager')) {
            echo "Error: CRM_API_Manager class not found\n";
            return;
        }
        
        $crm = MAC_Core\CRM_API_Manager::get_instance();
        echo "CRM API Manager loaded successfully\n";
        
        if (!$crm->is_license_valid()) {
            echo "Error: CRM connection not active\n";
            return;
        }
        
        echo "CRM connection is active\n";
        
        // Use the sample CSV file
        $csv_file = 'wp-content/plugins/mac-core/sample-menu.csv';
        
        if (!file_exists($csv_file)) {
            echo "Error: Sample CSV file not found\n";
            return;
        }
        
        echo "Using CSV file: $csv_file\n";
        echo "CSV file size: " . filesize($csv_file) . " bytes\n";
        
        // Test CSV upload to CRM
        echo "Testing CSV upload to CRM...\n";
        $result = $crm->upload_csv_to_crm($csv_file, 'replace');
        
        echo "Result: " . print_r($result, true) . "\n";
        
        if ($result['success'] && !empty($result['data']['categories'])) {
            echo "Categories found: " . count($result['data']['categories']) . "\n";
            echo "Summary: " . print_r($result['data']['summary'], true) . "\n";
        }
        
    } catch (Exception $e) {
        echo "Exception: " . $e->getMessage() . "\n";
        echo "Stack trace: " . $e->getTraceAsString() . "\n";
    }
}

// Run test
test_real_csv();
echo "Test completed\n";
?>

