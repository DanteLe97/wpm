# MAC Menu Debug Log

## Vị trí file log:
```
wp-content/plugins/mac-menu/mac-menu-debug.log
```

## Cách đọc log:
1. Mở file `mac-menu-debug.log` bằng text editor
2. Log sẽ hiển thị theo format: `[YYYY-MM-DD HH:MM:SS] MESSAGE`
3. Mỗi lần import CSV sẽ tạo một session log mới

## Expected Log Flow khi import CSV:
```
[2025-08-22 08:30:00] === MAC MENU CSV IMPORT FLOW START ===
[2025-08-22 08:30:00] STEP 1: Initialize import process
[2025-08-22 08:30:00] - File name: mac-menu.csv
[2025-08-22 08:30:00] - File size: 9595 bytes
[2025-08-22 08:30:00] STEP 2: File upload successful, checking CRM connection...
[2025-08-22 08:30:00] STEP 2: Checking CRM connection...
[2025-08-22 08:30:00] - CRM class exists: YES
[2025-08-22 08:30:00] - CRM instance created: YES
[2025-08-22 08:30:00] STEP 2: CRM connection ACTIVE - proceeding with CRM import
[2025-08-22 08:30:00] STEP 3: Preparing CRM upload
[2025-08-22 08:30:00] STEP 4: Calling CRM API Manager...
[2025-08-22 08:30:00] STEP 4: CRM instance created
[2025-08-22 08:30:00] STEP 4: CRM upload_csv_to_crm completed
[2025-08-22 08:30:00] STEP 4.5: Logging CRM response details
[2025-08-22 08:30:00] MAC Menu: CRM upload_csv_to_crm result:
[2025-08-22 08:30:00] - Success: YES
[2025-08-22 08:30:00] - Data keys: Array(...)
[2025-08-22 08:30:00] - Categories count: 29
[2025-08-22 08:30:00] - Full JSON structure preview:
[2025-08-22 08:30:00]   Categories: 29 items
[2025-08-22 08:30:00]   Category 1: massage (items: 0)
[2025-08-22 08:30:00]   Category 2: Swedish Massage (items: 3)
[2025-08-22 08:30:00]   Category 3: Prenatal Massage (items: 1)
[2025-08-22 08:30:00] STEP 4.5: CRM response logging completed
[2025-08-22 08:30:00] STEP 5: CRM API response received
[2025-08-22 08:30:00] STEP 6: CRM processing successful, applying data to database...
[2025-08-22 08:30:00] === DATABASE UPDATE: APPLY CRM DATA START ===
[2025-08-22 08:30:00] === DATABASE INSERT: CATEGORIES DATA START ===
[2025-08-22 08:30:00] === DATABASE INSERT: CATEGORIES DATA SUCCESS ===
[2025-08-22 08:30:00] === DATABASE UPDATE: APPLY CRM DATA SUCCESS ===
[2025-08-22 08:30:00] STEP 7: Database update completed
[2025-08-22 08:30:00] === MAC MENU CSV IMPORT FLOW SUCCESS ===
```

## Troubleshooting:
- Nếu không thấy log từ STEP 4: CRM class không tồn tại hoặc license không valid
- Nếu thấy "CRM class NOT FOUND": Plugin mac-core chưa được kích hoạt
- Nếu thấy "CRM license NOT VALID": Domain key không hợp lệ
