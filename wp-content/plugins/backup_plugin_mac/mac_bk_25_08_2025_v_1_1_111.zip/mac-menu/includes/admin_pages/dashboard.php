<?php                           
    $keyDomain = !empty(get_option('mac_domain_valid_key')) ? get_option('mac_domain_valid_key') : "0" ;
    $statusDomain = !empty(get_option('mac_domain_valid_status')) ? get_option('mac_domain_valid_status') : "0" ;
    
    mac_menu_log('MAC Menu Dashboard: Loading at ' . date('Y-m-d H:i:s'));
    mac_menu_log('MAC Menu Dashboard: Domain key: ' . $keyDomain);
    mac_menu_log('MAC Menu Dashboard: Domain status: ' . $statusDomain);
    
    // DISABLED: Auto-check on page load
    // Now using manual check via button in MAC Core
    /*
    if(!empty($keyDomain)) {
        mac_menu_log('MAC Menu Dashboard: Calling kvp_handle_check_request with key: ' . $keyDomain);
        kvp_handle_check_request($keyDomain);
    }else{
        mac_menu_log('MAC Menu Dashboard: No domain key, calling kvp_handle_check_request_url');
        kvp_handle_check_request_url();
    }
    */

    if ( is_admin() ) {
        if( ! function_exists('get_plugin_data') ){
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }
        $plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $plugin_data = get_plugin_data( $plugin_file );
    }
    if(isset($plugin_data['Version'])){
        $current_version = $plugin_data['Version'];
    }else{
        $current_version = '1.0.1';
    }
    
?>
<div id="post-body" style="margin-top: 50px;">
    <?php 
        // Display success message for CSV import
        if (isset($_GET['csv_imported']) && $_GET['csv_imported'] === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p>CSV processed successfully via CRM! Menu has been updated.</p></div>';
        }
        
        global $wpdb;
        // Tên bảng
        $cattablename = $wpdb->prefix . 'mac_cat_menu';
        // Kiểm tra sự tồn tại của bảng
        $table_exists_query = $wpdb->prepare("SHOW TABLES LIKE %s", $cattablename);
        $table_exists = $wpdb->get_var($table_exists_query);
        if(current_user_can('edit_dashboard')):
        ?>
        <div class="page-settings-wrap">
            <div class="content">
                <div class="wrap mac-dashboard">
                    <h1 class="wp-heading-inline"></h1>
                    <?php if( !empty($statusDomain) && ($statusDomain =='activate' || $statusDomain =='deactivate') ){ ?>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>IMPORT MENU <?php if (class_exists('MAC_Core\CRM_API_Manager') && MAC_Core\CRM_API_Manager::get_instance()->is_license_valid()): ?><span style="color: #0073aa; font-size: 14px;">(via CRM)</span><?php endif; ?></h2>
                        </div>
                        
                        <div class="inside is-primary-category"> 
                            <?php if (class_exists('MAC_Core\CRM_API_Manager') && MAC_Core\CRM_API_Manager::get_instance()->is_license_valid()): ?>
                                <p style="color: #0073aa; margin-bottom: 10px;"><strong>✓ CRM Connected:</strong> CSV will be processed through CRM for enhanced features and better data structure.</p>
                            <?php else: ?>
                                <p style="color: #d63638; margin-bottom: 10px;"><strong>⚠ CRM Not Connected:</strong> Using local CSV processing. Connect to CRM for enhanced features.</p>
                            <?php endif; ?>
                            <select class="mac-selection-data mac-selection-import-mode">
                                <option value="" selected>Please select an import mode</option>
                                <option value="replace">Replace existing data (delete and re-import)</option>
                                <option value="append">Append to existing data (add new items only)</option>
                            </select>
                            <div class="mac-data-replace">
                                <?php
                                if ($table_exists === $cattablename):
                                    ?>
                                        <div class="form-add-cat-menu">
                                            <form action="<?php echo admin_url('admin.php?page=mac-menu'); ?>" method="post" id="posts-filter" enctype="multipart/form-data">
                                                <input id="input-delete-data" type="text" data-table="<?= $cattablename ?>" name="delete_data" value="" readonly style="border:none;padding:0; opacity: 0; width: 0;">
                                                <!-- <input id="input-export-table-data" type="text" name="export_table_data" value="" readonly style="border:none;padding:0; opacity: 0; width: 0;"> -->
                                                <input type="file" name="csv_file_cat" accept=".csv" required>
                                                <input type="button" name="submit-cat" value="submit" class="btn-delete-menu">
                                            </form>
                                        </div>
                                        <!-- -->
                                        <div class="overlay" id="overlay"></div>
                                        <div class="confirm-dialog" id="confirmDialog" >
                                            <p>Are you sure you want to delete existing data and import new CSV?</p>
                                            <div class="btn-wrap">
                                                <div id="confirmOk">OK</div>
                                                <div id="confirmCancel">Cancel</div>
                                            </div>
                                        </div>
                                    <?php
                                else:
                                    ?>
                                        <div class="form-add-cat-menu">
                                            <form action="" method="post" enctype="multipart/form-data">
                                                <input type="file" name="csv_file_cat" accept=".csv" required>
                                                <input type="submit" name="submit-cat" value="submit">
                                            </form>
                                        </div>
                                    <?php
                                endif;
                                ?>
                            </div>
                            <div class="mac-data-append">
                                <div class="form-append-cat-menu" > <!--style="display:none"-->
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <input type="text" name="name_shop" placeholder="Shop Name" required>
                                        <input type="file" name="csv_file_cat_append" accept=".csv" required>
                                        <input type="submit" name="submit-cat" value="submit">
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>EXPORT MENU</h2>
                        </div>
                        <div class="inside is-primary-category"> 
                            <?php
                            if ($table_exists === $cattablename):
                                ?>
                                    <a href="<?php echo admin_url('admin-post.php?action=export_csv&export_table_data=1'); ?>">Export CSV</a>
                            <?php
                            endif;
                            ?>
                        </div>
                    </div>
                    

            <?php } ?>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>Validate Key</h2>
                        </div>
                        <div class="inside"> 
                            <div id="kvp-container" class="key-domain-wrap" >
                                <form id="kvp-form">
                                    <label for="kvp-key-input">Enter your key:</label>
                                    <input type="text" id="kvp-key-input" name="key" value="MAC Menu" required>
                                    <button type="submit">Validate</button>
                                </form>
                                <div id="kvp-result"></div>
                            </div>
                        </div>
                    </div>
                    <div class="postbox">
                        <div class="postbox-header">
                            <h2>Setting Custom Meta Box Page</h2>
                        </div>
                        <div class="inside"> 
                            <div class="mac-custom-meta-box-page-wrap" >
                                <form id="mac-custom-meta-box-page-form" method="post" enctype="multipart/form-data">
                                    <label>Enter Name Meta Box Page:</label>
                                    <?php $ValueMetaBoxPage = !empty(get_option('mac_custom_meta_box_page')) ? get_option('mac_custom_meta_box_page') : "" ; ?>
                                    <input type="text" name="mac-custom-meta-box-page" value="<?=$ValueMetaBoxPage;?>" required>
                                    <button type="submit">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php if( !empty($statusDomain) && ($statusDomain =='activate' || $statusDomain =='deactivate') ){ ?>
                    <div class="form-add-settings-menu">
                        <form id="formCategorySettingsMain" method="post" enctype="multipart/form-data">
                            <div class="postbox">
                                <div class="postbox-header">
                                    <h2>SETTINGS</h2>
                                </div>
                                <div class="inside is-primary-category" <?php if($statusDomain =='pending' || $statusDomain =='0' ){ echo 'style="opacity: 0; visibility: hidden; height: 0;"';} ?>> 
                                    <table class="form-settings-page">
                                        <tr>
                                            <td>On/Off Description WP Editor </td>
                                            <td>
                                                <?php $editorTextValue = !empty(get_option('mac_menu_text_editor')) ? get_option('mac_menu_text_editor') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($editorTextValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-text-editor" value="<?= $editorTextValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr>  
                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:700;">Menu</h2></td>
                                        </tr>

                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">Content</h2></td>
                                        </tr>

                                        <tr>
                                            <td>On/Off Element Category</td>
                                            <td>
                                                <?php $elementCatValue = !empty(get_option('mac_menu_element_category')) ? get_option('mac_menu_element_category') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($elementCatValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-element-category" value="<?= $elementCatValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Element Category Table</td>
                                            <td>
                                                <?php $elementCatTableValue = !empty(get_option('mac_menu_element_category_table')) ? get_option('mac_menu_element_category_table') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($elementCatTableValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-element-category-table" value="<?= $elementCatTableValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 

                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">Style</h2></td>
                                        </tr>

                                        <tr>
                                            <td>On/Off Background</td>
                                            <td>
                                                <?php $bgValue = !empty(get_option('mac_menu_background')) ? get_option('mac_menu_background') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($bgValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-background" value="<?= $bgValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Spacing</td>
                                            <td>
                                                <?php $spacingValue = !empty(get_option('mac_menu_spacing')) ? get_option('mac_menu_spacing') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($spacingValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-spacing" value="<?= $spacingValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Image</td>
                                            <td>
                                                <?php $imgValue = !empty(get_option('mac_menu_img')) ? get_option('mac_menu_img') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($imgValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-img" value="<?= $imgValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>On/Off Item Image</td>
                                            <td>
                                                <?php $itemImgValue = !empty(get_option('mac_menu_item_img')) ? get_option('mac_menu_item_img') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($itemImgValue == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-item-img" value="<?= $itemImgValue ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">Typography</h2></td>
                                        </tr>
                                        <tr>
                                            <td>Rank</td>
                                            <td>
                                                <?php $rankNumber = !empty(get_option('mac_menu_rank')) ? get_option('mac_menu_rank') : "1" ; ?>
                                                <select class="mac-is-selection" name="mac-menu-rank">
                                                    <option value="1" <?= ($rankNumber == 1) ? "selected" : ""  ?>>1</option>
                                                    <option value="2" <?= ($rankNumber == 2) ? "selected" : ""  ?>>2</option>
                                                    <option value="3" <?= ($rankNumber == 3) ? "selected" : ""  ?>>3</option>
                                                    <option value="4" <?= ($rankNumber == 4) ? "selected" : ""  ?>>4</option>
                                                    <option value="5" <?= ($rankNumber == 5) ? "selected" : ""  ?>>5</option>
                                                </select>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td>Javascript Link Menu</td>
                                            <td>
                                                <?php $rankNumber = !empty(get_option('mac_menu_js_link')) ? get_option('mac_menu_js_link') : "0" ; ?>
                                                <select class="mac-is-selection" name="mac-menu-js-link">
                                                    <option value="0" <?= ($rankNumber == 0) ? "selected" : ""  ?>>Default</option>
                                                    <option value="1" <?= ($rankNumber == 1) ? "selected" : ""  ?>>Link Menu</option>
                                                </select>
                                            </td>
                                        </tr>   
                                        <?php do_action('mac_menu_add_on_additional_settings_row_dual_price'); ?>
                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">QR Code</h2></td>
                                        </tr>
                                        <tr>
                                            <td>On/Off QR Code</td>
                                            <td class="mac-qr-code">
                                                <?php $macQR = !empty(get_option('mac_qr_code')) ? get_option('mac_qr_code') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($macQR == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-menu-qr" value="<?= $macQR ?>" readonly/>
                                                </div>
                                                <?php $macHeading = !empty(get_option('mac_qr_title')) ? get_option('mac_qr_title') : "" ; ?>
                                                <label>Heading Title:</label>
                                                <input type="text" name="mac-qr-title" value="<?=$macHeading;?>">
                                            </td>
                                        </tr> 

                                        <tr>
                                            <td><h2 style="font-size: 18px; font-weight:500;">HTML New</h2></td>
                                        </tr>
                                        <tr>
                                            <td>On/Off HTML</td>
                                            <td class="mac-html">
                                                <?php $macHTMLOld = !empty(get_option('mac_html_old')) ? get_option('mac_html_old') : "0" ; ?>
                                                <div class="mac-switcher-wrap mac-switcher-btn <?php if($macHTMLOld == "1") echo 'active'; ?>">
                                                    <span class="mac-switcher-true">On</span>
                                                    <span class="mac-switcher-false">Off</span>
                                                    <input type="text" name="mac-html-old" value="<?= $macHTMLOld ?>" readonly/>
                                                </div>
                                            </td>
                                        </tr> 

                                        
                                        
                                       
                                    </table>
                                </div>
                                <!--
                                <div class="postbox-header" style="margin-top: 45px">
                                    <h2>Key</h2>
                                </div>
                                <div class="inside is-primary-category" 
                                <?php if($statusDomain =='pending' || $statusDomain =='0'){ echo 'style="opacity: 0; visibility: hidden; height: 0;"';} ?>
                                > 
                                    <table class="form-settings-page">
                                        <tr>
                                            <td>Insert KEY</td>
                                            <td>
                                                <input type="text" name="mac-menu-github-key" class="hidden-input" value="MAC Menu"/>
                                            </td>
                                        </tr>    
                                    </table>
                                </div>
                                -->
                            </div>
                            <input type="text" name="action" value="menu-settings" readonly style="display:none;">
                            <input type="submit" name="submit-settings" class="mac-btn-save-chages" value="Save Changes">
                        </form>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
            <?php
        else:
            wp_die('You do not have sufficient permissions to access this page.');
        endif;
    ?>
</div>
<?php
if (false === get_option('mac_custom_meta_box_page')) {
    add_option('mac_custom_meta_box_page', '0');
}
if (false === get_option('mac_menu_element_category')) {
    add_option('mac_menu_element_category', '0');
}
if (false === get_option('mac_menu_element_category_table')) {
    add_option('mac_menu_element_category_table', '0');
}
if (false === get_option('mac_menu_background')) {
    add_option('mac_menu_background', '0');
}
if (false === get_option('mac_menu_spacing')) {
    add_option('mac_menu_spacing', '0');
}
if (false === get_option('mac_menu_rank')) {
    add_option('mac_menu_rank', '1');
}
if (false === get_option('mac_menu_text_editor')) {
    add_option('mac_menu_text_editor', '0');
}
if (false === get_option('mac_menu_img')) {
    add_option('mac_menu_img', '0');
}
if (false === get_option('mac_menu_item_img')) {
    add_option('mac_menu_item_img', '0');
}
if (false === get_option('mac_menu_js_link')) {
    add_option('mac_menu_js_link', '0');
}
if (false === get_option('mac_qr_title')) {
    add_option('mac_qr_title', '');
}

if (false === get_option('mac_html_old')) {
    add_option('mac_html_old', '');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_REQUEST['mac-custom-meta-box-page']) && !empty($_REQUEST['mac-custom-meta-box-page']) ) {
        update_option('mac_custom_meta_box_page', $_REQUEST['mac-custom-meta-box-page']);
        mac_redirect('admin.php?page=mac-menu');
    }
    
}

if(isset($_REQUEST['action']) == 'menu-settings'):
    
    if(isset($_REQUEST['mac-menu-element-category']) ) {
        update_option('mac_menu_element_category', $_REQUEST['mac-menu-element-category']);
    }
    if(isset($_REQUEST['mac-menu-element-category-table']) ) {
        update_option('mac_menu_element_category_table', $_REQUEST['mac-menu-element-category-table']);
    }
    if(isset($_REQUEST['mac-menu-background'])) {
        update_option('mac_menu_background', $_REQUEST['mac-menu-background']);
    }
    if(isset($_REQUEST['mac-menu-spacing'])) {
        update_option('mac_menu_spacing', $_REQUEST['mac-menu-spacing']);
    }
    if(isset($_REQUEST['mac-menu-rank']) && !empty($_REQUEST['mac-menu-rank']) ) {
        update_option('mac_menu_rank', $_REQUEST['mac-menu-rank']);
    }
    if(isset($_REQUEST['mac-menu-text-editor']) ) {
        update_option('mac_menu_text_editor', $_REQUEST['mac-menu-text-editor']);
    }
    if(isset($_REQUEST['mac-menu-img']) ) {
        update_option('mac_menu_img', $_REQUEST['mac-menu-img']);
    }
    if(isset($_REQUEST['mac-menu-item-img']) ) {
        update_option('mac_menu_item_img', $_REQUEST['mac-menu-item-img']);
    }
    if(isset($_REQUEST['mac-menu-js-link']) ) {
        update_option('mac_menu_js_link', $_REQUEST['mac-menu-js-link']);
    }
    
    if(isset($_REQUEST['mac-menu-dp']) ) {
        update_option('mac_menu_dp', $_REQUEST['mac-menu-dp']);
    }
    if(isset($_REQUEST['mac-menu-dp-sw']) ) {
        update_option('mac_menu_dp_sw', $_REQUEST['mac-menu-dp-sw']);
    }
    if(isset($_REQUEST['mac-menu-dp-value']) ) {
        update_option('mac_menu_dp_value', $_REQUEST['mac-menu-dp-value']);
    }
    if(isset($_REQUEST['mac-menu-qr']) ) {
        update_option('mac_qr_code', $_REQUEST['mac-menu-qr']);
    }
    if(isset($_REQUEST['mac-qr-title']) ) {
        update_option('mac_qr_title', $_REQUEST['mac-qr-title']);
    }
    if(isset($_REQUEST['mac-html-old']) ) {
        update_option('mac_html_old', $_REQUEST['mac-html-old']);
    }
    
    
    mac_redirect('admin.php?page=mac-menu');
    exit();
endif;
function importCSV($fileCSV, $parentID = 0, $parentName = ''){
    // STEP 1: Initialize CSV import process
    mac_menu_log('=== MAC MENU CSV IMPORT FLOW START ===');
    mac_menu_log('STEP 1: Initialize import process');
    mac_menu_log('- File name: ' . (isset($fileCSV['name']) ? $fileCSV['name'] : 'Unknown'));
    mac_menu_log('- File size: ' . (isset($fileCSV['size']) ? $fileCSV['size'] : 'Unknown') . ' bytes');
    mac_menu_log('- Parent ID: ' . $parentID);
    mac_menu_log('- Parent Name: ' . $parentName);
    
    if($fileCSV['error'] === UPLOAD_ERR_OK ) {
        mac_menu_log('STEP 2: File upload successful, checking CRM connection...');
        
        // Check if CRM connection is active
        mac_menu_log('STEP 2: Checking CRM connection...');
        mac_menu_log('- CRM class exists: ' . (class_exists('MAC_Core\CRM_API_Manager') ? 'YES' : 'NO'));
        
        if (!class_exists('MAC_Core\CRM_API_Manager')) {
            mac_menu_log('STEP 2: CRM class NOT FOUND - falling back to local processing');
            return importCSV_local($fileCSV, $parentID, $parentName);
        }
        
        $crm_instance = MAC_Core\CRM_API_Manager::get_instance();
        mac_menu_log('- CRM instance created: ' . ($crm_instance ? 'YES' : 'NO'));
        
        if (!$crm_instance->is_license_valid()) {
            mac_menu_log('STEP 2: CRM license NOT VALID - falling back to local processing');
            mac_menu_log('- CRM license valid: ' . ($crm_instance->is_license_valid() ? 'YES' : 'NO'));
            return importCSV_local($fileCSV, $parentID, $parentName);
        }
        
        mac_menu_log('STEP 2: CRM connection ACTIVE - proceeding with CRM import');
        
        $csv_file = $fileCSV;
        $tmp_name = $csv_file["tmp_name"];
        
        // Determine import mode based on parent info
        $import_mode = (!empty($parentID) && !empty($parentName)) ? 'append' : 'replace';
        
        mac_menu_log('STEP 3: Preparing CRM upload');
        mac_menu_log('- Temp file path: ' . $tmp_name);
        mac_menu_log('- Import mode: ' . $import_mode);
        mac_menu_log('- Parent ID: ' . $parentID);
        mac_menu_log('- Parent Name: ' . $parentName);
        mac_menu_log('- File exists: ' . (file_exists($tmp_name) ? 'YES' : 'NO'));
        mac_menu_log('- File size: ' . (file_exists($tmp_name) ? filesize($tmp_name) : 'N/A') . ' bytes');
        
        // Log first few lines of the uploaded file
        if (file_exists($tmp_name)) {
            mac_menu_log('- File content preview:');
            $handle = fopen($tmp_name, 'r');
            if ($handle) {
                $line_count = 0;
                while (($line = fgets($handle)) !== false && $line_count < 3) {
                    mac_menu_log('  Line ' . ($line_count + 1) . ': ' . trim($line));
                    $line_count++;
                }
                fclose($handle);
            }
        }
        
        // Process CSV through CRM
        mac_menu_log('STEP 4: Calling CRM API Manager...');
        $crm = MAC_Core\CRM_API_Manager::get_instance();
        mac_menu_log('STEP 4: CRM instance created');
        $result = $crm->upload_csv_to_crm($tmp_name, $import_mode);
        mac_menu_log('STEP 4: CRM upload_csv_to_crm completed');
        
        // Log CRM response details
        mac_menu_log('STEP 4.5: Logging CRM response details');
        mac_menu_log('MAC Menu: CRM upload_csv_to_crm result:');
        mac_menu_log('- Success: ' . ($result['success'] ? 'YES' : 'NO'));
        if (!$result['success']) {
            mac_menu_log('- Error: ' . $result['message']);
        } else {
            $data_keys_string = print_r(array_keys($result['data']), true);
            mac_menu_log('- Data keys: ' . $data_keys_string);
            if (isset($result['data']['categories'])) {
                mac_menu_log('- Categories count: ' . count($result['data']['categories']));
                // Log first category as sample
                if (count($result['data']['categories']) > 0) {
                    $first_category_string = print_r($result['data']['categories'][0], true);
                    mac_menu_log('- First category sample: ' . $first_category_string);
                }
            }
            if (isset($result['data']['summary'])) {
                $summary_string = print_r($result['data']['summary'], true);
                mac_menu_log('- Summary: ' . $summary_string);
            }
            if (isset($result['data']['shop_info'])) {
                $shop_info_string = print_r($result['data']['shop_info'], true);
                mac_menu_log('- Shop info: ' . $shop_info_string);
            }
            
            // Log full JSON structure - ALL CATEGORIES
            mac_menu_log('- Full JSON structure - ALL CATEGORIES:');
            mac_menu_log('  Total Categories: ' . count($result['data']['categories']) . ' items');
            foreach ($result['data']['categories'] as $index => $category) {
                mac_menu_log('  ===== CATEGORY ' . ($index + 1) . ' =====');
                mac_menu_log('  Category Name: ' . $category['category_name']);
                mac_menu_log('  Slug: ' . $category['slug_category']);
                mac_menu_log('  Description: ' . $category['category_description']);
                mac_menu_log('  Price: ' . $category['price']);
                mac_menu_log('  Parents Category: ' . $category['parents_category']);
                mac_menu_log('  Order: ' . $category['order']);
                mac_menu_log('  Is Table: ' . $category['is_table']);
                mac_menu_log('  Is Hidden: ' . $category['is_hidden']);
                mac_menu_log('  Category Inside: ' . $category['category_inside']);
                mac_menu_log('  Category Inside Order: ' . $category['category_inside_order']);
                mac_menu_log('  Group Repeater Items: ' . count($category['group_repeater']));
                
                // Log all group_repeater items
                if (!empty($category['group_repeater'])) {
                    mac_menu_log('  --- GROUP REPEATER ITEMS ---');
                    foreach ($category['group_repeater'] as $item_index => $item) {
                        mac_menu_log('    Item ' . ($item_index + 1) . ':');
                        mac_menu_log('      Name: ' . $item['name']);
                        mac_menu_log('      Description: ' . $item['description']);
                        mac_menu_log('      Featured Image: ' . $item['featured_img']);
                        mac_menu_log('      Fullwidth: ' . $item['fullwidth']);
                        mac_menu_log('      Position: ' . $item['position']);
                        if (!empty($item['price-list'])) {
                            $price_list_string = print_r($item['price-list'], true);
                            mac_menu_log('      Price List: ' . $price_list_string);
                        }
                    }
                }
                mac_menu_log('  ===== END CATEGORY ' . ($index + 1) . ' =====');
            }
        }
        mac_menu_log('STEP 4.5: CRM response logging completed');
        
        // Log raw JSON response for complete data inspection
        mac_menu_log('=== RAW JSON RESPONSE FROM CRM ===');
        mac_menu_log('Raw JSON length: ' . strlen(json_encode($result['data'])) . ' characters');
        mac_menu_log('Complete JSON structure:');
        $json_string = print_r($result['data'], true);
        mac_menu_log($json_string);
        mac_menu_log('=== END RAW JSON RESPONSE ===');
        
        mac_menu_log('STEP 5: CRM API response received');
        mac_menu_log('- Success: ' . ($result['success'] ? 'YES' : 'NO'));
        if (!$result['success']) {
            mac_menu_log('- Error message: ' . $result['message']);
        }
        
        if ($result['success']) {
            mac_menu_log('STEP 6: CRM processing successful, applying data to database...');
            $data_structure_string = print_r(array_keys($result['data']), true);
            mac_menu_log('- Data structure: ' . $data_structure_string);
            if (isset($result['data']['categories'])) {
                mac_menu_log('- Categories count: ' . count($result['data']['categories']));
            }
            if (isset($result['data']['summary'])) {
                $summary_string = print_r($result['data']['summary'], true);
                mac_menu_log('- Summary: ' . $summary_string);
            }
            
            // Apply the processed data from CRM
            $applied = apply_crm_processed_data($result['data'], $parentID, $parentName);
            mac_menu_log('STEP 7: Database update completed');
            mac_menu_log('=== MAC MENU CSV IMPORT FLOW SUCCESS ===');
            return (bool) $applied;
        } else {
            mac_menu_log('STEP 6: CRM processing FAILED - falling back to local processing');
            mac_menu_log('- CRM error: ' . $result['message']);
            // Fallback to local processing if CRM fails
            importCSV_local($fileCSV, $parentID, $parentName);
            return false;
        }
    } else {
        mac_menu_log('STEP 1: File upload FAILED');
        mac_menu_log('- Upload error code: ' . $fileCSV['error']);
        mac_menu_log('=== MAC MENU CSV IMPORT FLOW FAILED ===');
        echo 'Upload Failed';
    }
}

// Fallback function for local CSV processing (old method)
function importCSV_local($fileCSV, $parentID = 0, $parentName = ''){
    if($fileCSV['error'] === UPLOAD_ERR_OK ) {
        $csv_file = $fileCSV;
        $tmp_name = $csv_file["tmp_name"];
        // Đọc nội dung từ file CSV
        $handle = fopen($tmp_name, "r");
        // Kiểm tra xem file có tồn tại không
        if ($handle === FALSE) {
            die("Failed to open uploaded file.");
        }
        $header = array_flip(fgetcsv($handle)); // Read header row
        // Đọc từng dòng của file CSV và xử lý dữ liệu
        $itemMenuIndex = 0;
        $itemChildrenIndex = 0;
        $numberX = 0;
        $rank = 0;
        $term = 0;
        $dataArray = [];
        while (($row = fgetcsv($handle)) !== FALSE) {
            if(!empty($row[$header['category_name']])){
                $dataArray[$itemMenuIndex] = [
                    "category_name" => $row[$header['category_name']],
                    "slug_category" => '',
                    "category_description" => ( isset($header['category_description']) && !empty($row[$header['category_description']])) ? $row[$header['category_description']] : "",
                    "price" => ( isset($header['price']) && !empty($row[$header['price']])) ? $row[$header['price']] : "",
                    "featured_img" => ( isset($header['featured_img']) && !empty($row[$header['featured_img']])) ? $row[$header['featured_img']] : "",
                    "parents_category" => ( isset($header['parents_category']) && !empty($row[$header['parents_category']])) ? (int)$row[$header['parents_category']] + $parentID  : $parentID,
                    "group_repeater" => [],
                    "is_table" => ( isset($header['is_table']) && !empty($row[$header['is_table']])) ? $row[$header['is_table']] : "0", 
                    "is_hidden" => ( isset($header['is_hidden']) && !empty($row[$header['is_hidden']])) ? $row[$header['is_hidden']] : "0", 
                    "data_table" => ( isset($header['table_heading']) && !empty($row[$header['table_heading']])) ? $row[$header['table_heading']] : "", 
                    "order" => '',
                    "category_inside" => ( isset($header['category_inside']) && !empty($row[$header['category_inside']])) ? $row[$header['category_inside']] : "1", 
                    "category_inside_order" => ( isset($header['category_inside_order']) && !empty($row[$header['category_inside_order']])) ? $row[$header['category_inside_order']] : NULL, 
                ];
                
                if (!empty($row[$header['item_list_name']])) {
                    $listItem = 0;
                    $dataArray[$itemMenuIndex]['group_repeater'][] = [
                        "name" => $row[$header['item_list_name']],
                        "featured_img" => ( isset($header['item_list_img']) && !empty($row[$header['item_list_img']])) ? $row[$header['item_list_img']] : "", 
                        "description"  => ( isset($header['item_list_description']) && !empty($row[$header['item_list_description']])) ? $row[$header['item_list_description']] : "", 
                        "fullwidth"    => ( isset($header['item_list_fw']) && !empty($row[$header['item_list_fw']])) ? $row[$header['item_list_fw']] : "0", 
                        "price-list"   => ( isset($header['item_list_price']) ) ? create_array($row[$header['item_list_price']],'price') : "",  
                        "position"   => ( isset($header['item_list_position']) && !empty($row[$header['item_list_position']])) ? $row[$header['item_list_position']] : $listItem + 1, 
                    ];
                    
                }
                $itemMenuIndex++;
            }else{
                if (!empty($row[$header['item_list_name']])) {
                    if(!isset($listItem) || $listItem == 0) {
                        $listItem = 1;
                    }
                    $dataArray[($itemMenuIndex - 1)]['group_repeater'][] = [
                        "name" => $row[$header['item_list_name']],
                        "featured_img" => ( isset($header['item_list_img']) && !empty($row[$header['item_list_img']])) ? $row[$header['item_list_img']] : "", 
                        "description"  => ( isset($header['item_list_description']) && !empty($row[$header['item_list_description']])) ? $row[$header['item_list_description']] : "", 
                        "fullwidth"    => ( isset($header['item_list_fw']) && !empty($row[$header['item_list_fw']])) ? $row[$header['item_list_fw']] : "0", 
                        "price-list"   => ( isset($header['item_list_price']) ) ? create_array($row[$header['item_list_price']],'price') : "",  
                        "position"   => ( isset($header['item_list_position']) && !empty($row[$header['item_list_position']])) ? $row[$header['item_list_position']] : $listItem + 1, 
                    ];
                    $listItem+=1;
                }
            }
           
        }
        fclose($handle);
       
        plugin_cat_table($dataArray,$parentID,$parentName);
    }else{
        echo 'Upload False';
    }
}

// Function to apply CRM processed data to local database
function apply_crm_processed_data($data, $parentID = 0, $parentName = '') {
    mac_menu_log('=== DATABASE UPDATE: APPLY CRM DATA START ===');
    mac_menu_log('DB STEP 1: Validating CRM response data');
    mac_menu_log('- Parent ID: ' . $parentID);
    mac_menu_log('- Parent Name: ' . $parentName);
    $data_structure_string = print_r(array_keys($data), true);
    mac_menu_log('- Data structure: ' . $data_structure_string);
    
    if (empty($data['categories'])) {
        mac_menu_log('DB STEP 1: VALIDATION FAILED - No categories data in CRM response');
        $available_keys_string = print_r(array_keys($data), true);
        mac_menu_log('- Available keys: ' . $available_keys_string);
        mac_menu_log('=== DATABASE UPDATE: APPLY CRM DATA FAILED ===');
        return false;
    }
    
    mac_menu_log('DB STEP 1: Validation successful');
    mac_menu_log('- Categories count: ' . count($data['categories']));
    
    // Apply categories data
    mac_menu_log('DB STEP 2: Starting database update...');
    apply_categories_data($data['categories'], $parentID, $parentName);
    
    mac_menu_log('DB STEP 3: Database update completed');
    mac_menu_log('=== DATABASE UPDATE: APPLY CRM DATA SUCCESS ===');
    return true;
}

// Function to apply categories data to local database
function apply_categories_data($categories, $parentID = 0, $parentName = '') {
    mac_menu_log('=== DATABASE INSERT: CATEGORIES DATA START ===');
    mac_menu_log('DB INSERT STEP 1: Initialize database operations');
    mac_menu_log('- Parent ID: ' . $parentID);
    mac_menu_log('- Parent Name: ' . $parentName);
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'mac_cat_menu';
    mac_menu_log('- Target table: ' . $table_name);
    mac_menu_log('- Categories to process: ' . count($categories));
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
    mac_menu_log('- Table exists: ' . ($table_exists ? 'YES' : 'NO'));
    if (!$table_exists) {
        if (function_exists('create_table_cat')) {
            mac_menu_log('- Table not found. Creating table...');
            create_table_cat();
        }
    }
    
    // Determine if this is append mode (has parent info)
    $is_append_mode = !empty($parentID) && !empty($parentName);
    mac_menu_log('- Is append mode: ' . ($is_append_mode ? 'YES' : 'NO'));
    
    if ($is_append_mode) {
        // APPEND MODE: Insert categories under parent
        mac_menu_log('DB INSERT STEP 2: Append mode - inserting under parent category');
        mac_menu_log('- Parent category ID: ' . $parentID);
        mac_menu_log('- Parent category name: ' . $parentName);
    } else {
        // REPLACE MODE: Clear existing data and reset IDs
        mac_menu_log('DB INSERT STEP 2: Replace mode - clearing existing data...');
        
        // Drop and recreate table to reset auto-increment ID
        mac_menu_log('- Dropping existing table to reset ID...');
        $wpdb->query("DROP TABLE IF EXISTS $table_name");
        mac_menu_log('- Table dropped successfully');
        
        // Recreate table
        if (function_exists('create_table_cat')) {
            mac_menu_log('- Recreating table...');
            create_table_cat();
            mac_menu_log('- Table recreated successfully');
            
            // Verify table structure and AUTO_INCREMENT
            $table_info = $wpdb->get_row("SHOW TABLE STATUS LIKE '$table_name'");
            if ($table_info) {
                mac_menu_log('- Table AUTO_INCREMENT reset to: ' . $table_info->Auto_increment);
            }
        } else {
            mac_menu_log('- ERROR: create_table_cat function not found');
            return false;
        }
    }
    
    // Insert new categories data
    mac_menu_log('DB INSERT STEP 3: Inserting categories data...');
    $inserted_count = 0;
    $error_count = 0;
    $order_index = 0;
    
    foreach ($categories as $index => $category) {
        mac_menu_log('DB INSERT STEP 3.' . ($index + 1) . ': Processing category - ' . $category['category_name']);
        
        // Log category structure
        mac_menu_log('- Category data structure:');
        mac_menu_log('  * category_name: ' . $category['category_name']);
        mac_menu_log('  * slug_category: ' . $category['slug_category']);
        mac_menu_log('  * parents_category: ' . $category['parents_category']);
        mac_menu_log('  * group_repeater items: ' . count($category['group_repeater']));
        mac_menu_log('  * is_table: ' . $category['is_table']);
        mac_menu_log('  * is_hidden: ' . $category['is_hidden']);
        
        // Prepare category data for database
        $slug_value = !empty($category['slug_category'])
            ? $category['slug_category']
            : (function_exists('create_slug') ? create_slug($category['category_name']) : $category['category_name']);
        
        $group_repeater_value = isset($category['group_repeater']) && is_array($category['group_repeater'])
            ? json_encode($category['group_repeater'])
            : (is_string($category['group_repeater']) ? $category['group_repeater'] : json_encode([]));
        
        $data_table_value = '';
        if (isset($category['data_table'])) {
            if (is_array($category['data_table'])) {
                $data_table_value = json_encode($category['data_table']);
            } else if (is_string($category['data_table'])) {
                // Convert delimited string to array then encode, to match plugin_cat_table behavior
                $data_table_value = json_encode(function_exists('create_array') ? create_array($category['data_table']) : $category['data_table']);
            }
        }
        
        // Handle parents_category for append mode
        $parents_category_value = $category['parents_category'];
        if ($is_append_mode) {
            // In append mode, if parents_category is 0, set it to parentID
            if ($category['parents_category'] == 0) {
                $parents_category_value = $parentID;
                mac_menu_log('  * APPEND MODE: Changed parents_category from 0 to ' . $parentID);
            } else {
                // If it has a parent, add parentID to it (like old logic)
                $parents_category_value = $category['parents_category'] + $parentID;
                mac_menu_log('  * APPEND MODE: Changed parents_category from ' . $category['parents_category'] . ' to ' . $parents_category_value);
            }
        }
        
        $category_data = array(
            'category_name' => $category['category_name'],
            'slug_category' => $slug_value,
            'category_description' => $category['category_description'],
            'price' => $category['price'],
            'featured_img' => $category['featured_img'],
            'parents_category' => $parents_category_value,
            'group_repeater' => $group_repeater_value,
            'is_table' => $category['is_table'],
            'is_hidden' => $category['is_hidden'],
            'data_table' => $data_table_value,
            'order' => $order_index,
            'category_inside' => $category['category_inside'],
            'category_inside_order' => $category['category_inside_order']
        );
        
        mac_menu_log('- Encoded group_repeater length: ' . strlen($group_repeater_value) . ' characters');
        
        $insert_result = $wpdb->insert($table_name, $category_data);
        
        if ($wpdb->last_error) {
            mac_menu_log('- INSERT ERROR: ' . $wpdb->last_error);
            $failed_data_string = print_r($category_data, true);
            mac_menu_log('- Failed data: ' . $failed_data_string);
            $error_count++;
        } else {
            mac_menu_log('- INSERT SUCCESS: ID = ' . $wpdb->insert_id);
            $inserted_count++;
            
            // Log first few IDs to confirm they start from 1
            if ($inserted_count <= 3) {
                mac_menu_log('- Confirmed: ID ' . $inserted_count . ' = ' . $wpdb->insert_id);
            }
        }
        $order_index++;
    }
    
    mac_menu_log('DB INSERT STEP 4: Summary');
    mac_menu_log('- Total processed: ' . count($categories));
    mac_menu_log('- Successfully inserted: ' . $inserted_count);
    mac_menu_log('- Errors: ' . $error_count);
    mac_menu_log('=== DATABASE INSERT: CATEGORIES DATA SUCCESS ===');
}


    // Debug: Log all POST and FILES data
    $post_data_string = print_r($_POST, true);
    mac_menu_log('MAC Menu: POST data: ' . $post_data_string);
    $files_data_string = print_r($_FILES, true);
    mac_menu_log('MAC Menu: FILES data: ' . $files_data_string);
    mac_menu_log('MAC Menu: REQUEST_METHOD: ' . $_SERVER['REQUEST_METHOD']);
    
    // Only process if this is a POST request with CSV file
    if($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['csv_file_cat'])) {
        // NEW: Use CRM import for all CSV processing
        mac_menu_log('MAC Menu: Processing CSV import via CRM - Form submitted');
        
        // Check if CRM connection is active
        if (!class_exists('MAC_Core\CRM_API_Manager') || !MAC_Core\CRM_API_Manager::get_instance()->is_license_valid()) {
            mac_menu_log('MAC Menu: CRM connection not active, using local processing');
            // Fallback to old local processing
            $deleteData = (isset($_REQUEST['delete_data']) && $_REQUEST['delete_data'] != '') ? $_REQUEST['delete_data'] : '';
            if($deleteData != '') {
                delete_table_cat($deleteData);
            }
            importCSV_local($_FILES['csv_file_cat'], 0, '');
            echo '<div class="notice notice-warning"><p>CRM connection not available. Using local CSV processing.</p></div>';
        } else {
            // Use CRM import
            try {
                $ok = importCSV($_FILES['csv_file_cat'], 0, '');
                if ($ok) {
                    // Success → go to mac-cat-menu
                    echo '<script>window.location.href = "' . admin_url('admin.php?page=mac-cat-menu') . '";</script>';
                    echo '<div class="notice notice-success"><p>CSV processed successfully! Redirecting to Menu...</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>CRM import failed or no data applied. Please check logs.</p></div>';
                }
            } catch (Exception $e) {
                echo '<div class="notice notice-error"><p>CRM import failed: ' . esc_html($e->getMessage()) . '</p></div>';
            }
        }
    }elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['csv_file_cat_append']) && !empty($_REQUEST['name_shop'])) {
    $shopName = trim($_REQUEST['name_shop']);
    
    // Check if CRM connection is active
    if (!class_exists('MAC_Core\CRM_API_Manager') || !MAC_Core\CRM_API_Manager::get_instance()->is_license_valid()) {
        mac_menu_log('MAC Menu: CRM connection not active, using local processing for append');
        // Fallback to old local processing
        $parentID = insert_category([
            'category_name' => $shopName,
            'slug_category' => create_slug($shopName),
            'category_description' => '',
            'price' => '',
            'featured_img' => '',
            'parents_category' => 0,
            'group_repeater' => [],
            'is_table' => 0,
            'is_hidden' => 0,
            'data_table' => '',
            'order' => '',
            'category_inside' => '',
            'category_inside_order' => NULL
        ]);
        if ($parentID) {
            importCSV_local($_FILES['csv_file_cat_append'], $parentID, $shopName);
        } else {
            echo "Không thể tạo danh mục cha.";
        }
        echo '<div class="notice notice-warning"><p>CRM connection not available. Using local CSV processing.</p></div>';
    } else {
        // Use CRM import for append mode
        mac_menu_log('MAC Menu: Processing CSV append via CRM');
        
        // Create parent category first (like old logic)
        $parentID = insert_category([
            'category_name' => $shopName,
            'slug_category' => create_slug($shopName),
            'category_description' => '',
            'price' => '',
            'featured_img' => '',
            'parents_category' => 0,
            'group_repeater' => [],
            'is_table' => 0,
            'is_hidden' => 0,
            'data_table' => '',
            'order' => '',
            'category_inside' => '',
            'category_inside_order' => NULL
        ]);
        
        if ($parentID) {
            mac_menu_log('MAC Menu: Parent category created with ID: ' . $parentID);
            try {
                $ok = importCSV($_FILES['csv_file_cat_append'], $parentID, $shopName);
                if ($ok) {
                    echo '<script>window.location.href = "' . admin_url('admin.php?page=mac-cat-menu') . '";</script>';
                    echo '<div class="notice notice-success"><p>CSV append processed successfully via CRM! Redirecting to Menu...</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>CRM append failed or no data applied. Please check logs.</p></div>';
                }
            } catch (Exception $e) {
                echo '<div class="notice notice-error"><p>CRM append failed: ' . esc_html($e->getMessage()) . '</p></div>';
            }
        } else {
            echo '<div class="notice notice-error"><p>Failed to create parent category for append mode.</p></div>';
        }
    }
}
function insert_category($data) {
    global $wpdb;
    $cattablename = $wpdb->prefix . "mac_cat_menu";
    $wpdb->insert($cattablename, [
        'category_name' => $data['category_name'],
        'slug_category' => $data['slug_category'],
        'category_description' => $data['category_description'],
        'price' => $data['price'],
        'featured_img' => $data['featured_img'],
        'parents_category' => $data['parents_category'],
        'group_repeater' => maybe_serialize($data['group_repeater']),
        'is_table' => $data['is_table'],
        'is_hidden' => $data['is_hidden'],
        'data_table' => $data['data_table'],
        'order' => $data['order'],
        'category_inside' => $data['category_inside'],
        'category_inside_order' => $data['category_inside_order']
    ]);

    return $wpdb->insert_id; // trả về ID của row vừa chèn
}

// Add JavaScript for Import Menu Processing
add_action('admin_footer', function() {
    if (isset($_GET['page']) && $_GET['page'] === 'mac-menu') {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // Import mode selection
            $('.mac-selection-import-mode').on('change', function() {
                var mode = $(this).val();
                if (mode === 'replace') {
                    $('.mac-data-replace').show();
                    $('.mac-data-append').hide();
                } else if (mode === 'append') {
                    $('.mac-data-replace').hide();
                    $('.mac-data-append').show();
                } else {
                    $('.mac-data-replace').hide();
                    $('.mac-data-append').hide();
                }
            });
            
            // Delete confirmation for replace mode
            $('.btn-delete-menu').on('click', function(e) {
                e.preventDefault();
                console.log('Submit button clicked');
                var form = $(this).closest('form');
                // Ensure hidden input has table value to trigger confirmation
                var $hidden = $('#input-delete-data');
                var tableName = $hidden.data('table');
                if ($hidden.val() === '' && typeof tableName !== 'undefined') {
                    $hidden.val(tableName);
                }
                var deleteData = $hidden.val();
                console.log('Delete data:', deleteData);
                
                if (deleteData) {
                    console.log('Showing confirmation dialog');
                    $('#overlay').show();
                    $('#confirmDialog').show();
                    
                    $('#confirmOk').off('click').on('click', function() {
                        console.log('OK clicked - submitting form');
                        $('#overlay').hide();
                        $('#confirmDialog').hide();
                        form.submit();
                    });
                    
                    $('#confirmCancel').off('click').on('click', function() {
                        console.log('Cancel clicked - hiding dialog');
                        $('#overlay').hide();
                        $('#confirmDialog').hide();
                    });
                } else {
                    console.log('No delete data - submitting form directly');
                    form.submit();
                }
            });
            
            // Show success/error messages
            <?php if (isset($_GET['csv_imported']) && $_GET['csv_imported'] === 'success'): ?>
            alert('CSV processed successfully via CRM! Menu has been updated.');
            <?php endif; ?>
        });
        </script>
        <?php
    }
});

// Add custom logging function at the top of the file
function mac_menu_log($message) {
    $log_file = WP_CONTENT_DIR . '/plugins/mac-menu/mac-menu-debug.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[{$timestamp}] {$message}\n";
    file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
}

?>