<?php
/**
 * MAC Menu Domain Manager
 * 
 * @package MAC Menu
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class MAC_Menu_Domain_Manager {
    private static $instance = null;
    private $current_version;
    private $plugin_file;
    private $crm_api;

    // Constants
    const DEFAULT_VERSION = '1.0.1';
    const TIMEOUT = 45;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
        $this->init_hooks();
    }

    private function init() {
        $this->plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $this->current_version = $this->get_plugin_version();
    }

    private function init_hooks() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
        add_action('wp_ajax_nopriv_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
    }

    private function get_plugin_version() {
        if (is_admin() && function_exists('get_plugin_data')) {
            $plugin_data = get_plugin_data($this->plugin_file);
            return isset($plugin_data['Version']) ? $plugin_data['Version'] : self::DEFAULT_VERSION;
        }
        return self::DEFAULT_VERSION;
    }

    /**
     * Get CRM API Manager instance (lazy loading)
     */
    private function get_crm_api() {
        if (!$this->crm_api && class_exists('MAC_Core\CRM_API_Manager')) {
            $this->crm_api = MAC_Core\CRM_API_Manager::get_instance();
        }
        return $this->crm_api;
    }

    public function enqueue_scripts() {
        wp_localize_script('admin-script', 'kvp_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac_menu_domain_nonce')
        ));
    }

    /**
     * Kiểm tra key có đúng không
     */
    public function handle_check_request($key_domain_check = null) {
        if (!$this->get_crm_api()) {
            return;
        }
        
        $domain = get_site_url() . '/';
        $result = $this->crm_api->validate_key($key_domain_check, $domain, $this->current_version);
        
        // Handle UI response if needed
        if (!$result['success']) {
            // Handle error case
        }
    }

    /**
     * Gửi domain tới CRM nếu key sai
     */
    public function handle_check_request_url() {
        if (!$this->get_crm_api()) {
            return;
        }
        
        $domain = get_site_url() . '/';
        $result = $this->crm_api->validate_url($domain, $this->current_version);
        
        // Handle UI response if needed
        if (!$result['success']) {
            // Handle error case
        }
    }

    /**
     * Gửi domain tới CRM để đăng ký
     */
    public function handle_ajax_request() {
        if (!$this->get_crm_api()) {
            wp_send_json_error('CRM API Manager not available.');
            return;
        }
        
        if (isset($_POST['nonce'])) {
            if (!wp_verify_nonce($_POST['nonce'], 'mac_menu_domain_nonce')) {
                wp_send_json_error('Invalid security token.');
                return;
            }
        }

        if (!isset($_POST['key'])) {
            wp_send_json_error('Key is required.');
            return;
        }

        $key = sanitize_text_field($_POST['key']);
        $domain = get_site_url() . '/';

        $result = $this->crm_api->register_domain($key, $domain, $this->current_version);

        if (!$result['success']) {
            wp_send_json_error($result['message']);
            return;
        }

        $this->process_ajax_response($result['data']);
    }



    private function process_ajax_response($data) {
        if (!isset($data['valid']) || !$data['valid']) {
            wp_send_json_error($data['message'] ?? 'Invalid key.');
            return;
        }
        
        // Send a simple success message instead of an object
        wp_send_json_success($data['message'] ?? 'Key is valid!');
    }


    

    

    

}

// Initialize the domain manager
if (defined('ABSPATH')) {
    add_action('plugins_loaded', array('MAC_Menu_Domain_Manager', 'get_instance'), 30); // Priority 30 to run after mac-core
}

// Wrapper functions for backward compatibility
function kvp_enqueue_scripts() {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->enqueue_scripts();
}

function kvp_handle_check_request($keyDomainCheck = null) {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->handle_check_request($keyDomainCheck);
}

function kvp_handle_check_request_url() {
    error_log('=== MAC Menu: kvp_handle_check_request_url() CALLED (wrapper) ===');
    error_log('MAC Menu: kvp_handle_check_request_url - Timestamp: ' . date('Y-m-d H:i:s'));
    
    if (class_exists('MAC_Menu_Domain_Manager')) {
        error_log('MAC Menu: kvp_handle_check_request_url - MAC_Menu_Domain_Manager class exists');
        $manager = MAC_Menu_Domain_Manager::get_instance();
        error_log('MAC Menu: kvp_handle_check_request_url - Manager instance created');
        $manager->handle_check_request_url();
        error_log('MAC Menu: kvp_handle_check_request_url() ENDING - Success');
    } else {
        error_log('MAC Menu: kvp_handle_check_request_url - MAC_Menu_Domain_Manager class NOT found');
        error_log('MAC Menu: kvp_handle_check_request_url() ENDING - Error');
    }
}

function kvp_handle_ajax_request() {
    $manager = MAC_Menu_Domain_Manager::get_instance();
    $manager->handle_ajax_request();
}

// Register the old function hooks
add_action('admin_enqueue_scripts', 'kvp_enqueue_scripts');
add_action('wp_ajax_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
add_action('wp_ajax_nopriv_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
