<?php
// ==========================
// API cho CRM sử dụng (GET) - Độc lập với add-on auto-login
// ==========================
add_action('init', function () {
    if (!isset($_GET['macapi_crm_login']) || $_GET['macapi_crm_login'] != 1) return;

    $auth_key = $_GET['auth_key'] ?? '';
    $user_login = sanitize_user($_GET['user'] ?? '');
    $shared_secret = 'my_secret_key'; // Đổi giá trị này khi triển khai

    header('Content-Type: application/json');

    if ($auth_key !== $shared_secret) {
        wp_send_json_error(['message' => 'Auth key không hợp lệ.'], 403);
    }

    if (empty($user_login)) {
        wp_send_json_error(['message' => 'Thiếu user.'], 400);
    }

    // Tìm user theo user_login
    $user = get_user_by('login', $user_login);
    if (!$user) {
        wp_send_json_error(['message' => 'Không tìm thấy user.'], 404);
    }

    // Gán token với prefix macapi_ (không cần thời gian hết hạn)
    $token = wp_generate_password(32, false, false);
    update_user_meta($user->ID, 'macapi_token', $token);
    update_user_meta($user->ID, 'macapi_usage_count', 0);
    update_user_meta($user->ID, 'macapi_created_time', time());

    // Trả JSON (không có expires_in)
    wp_send_json_success([
        'login_url'   => site_url('?macapi_token=' . $token),
        'username'    => $user->user_login,
        'role'        => implode(',', $user->roles)
    ]);
});
