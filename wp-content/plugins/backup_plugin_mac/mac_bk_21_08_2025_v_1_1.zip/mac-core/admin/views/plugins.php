<?php
if (!defined('ABSPATH')) {
    exit;
}

// MAC Core Add-ons array - định nghĩa các add-ons có sẵn
$mac_core_addons = array(
    'mac-menu' => array(
        'name' => 'MAC Menu',
        'description' => 'Create beautiful menu tables for your restaurant website.',
        'slug' => 'mac-menu',
        'file' => 'mac-menu/mac-menu.php',
        'github_repo' => 'DanteLe97/MAC_MENU',
        'github_token_option' => 'mac_menu_github_key'
    ),
    'mac-reservation' => array(
        'name' => 'MAC Add-ons 1', 
        'description' => 'Manage restaurant reservations and table bookings.',
        'slug' => 'mac-reservation',
        'file' => 'mac-reservation/mac-reservation.php',
        'github_repo' => 'DanteLe97/MAC_RESERVATION',
        'github_token_option' => 'mac_reservation_github_key'
    ),
    'mac-delivery' => array(
        'name' => 'MAC MAC Add-ons 2',
        'description' => 'Handle food delivery orders and tracking.',
        'slug' => 'mac-delivery',
        'file' => 'mac-delivery/mac-delivery.php',
        'github_repo' => 'DanteLe97/MAC_DELIVERY',
        'github_token_option' => 'mac_delivery_github_key'
    ),
    'mac-loyalty' => array(
        'name' => 'MAC MAC Add-ons 3',
        'description' => 'Customer loyalty program and rewards system.',
        'slug' => 'mac-loyalty',
        'file' => 'mac-loyalty/mac-loyalty.php',
        'github_repo' => 'DanteLe97/MAC_LOYALTY',
        'github_token_option' => 'mac_loyalty_github_key'
    )
);

// Function to get plugin description
function get_plugin_description($plugin_file) {
    if (!function_exists('get_plugin_data')) {
        require_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }
    
    $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file);
    return isset($plugin_data['Description']) ? $plugin_data['Description'] : '';
}

// Function to check if plugin is active
function is_mac_plugin_active($plugin_file) {
    return is_plugin_active($plugin_file);
}

// Get Update Manager instance
$update_manager = MAC_Core\Update_Manager::get_instance();
error_log("=== MAC Core Plugins Page Debug ===");

// Check which add-ons are installed and get their real data
$installed_addons = array();
$available_addons = array();
$domain_license_active = $update_manager->is_domain_license_active();
error_log("MAC Core: Domain license active: " . ($domain_license_active ? 'YES' : 'NO'));

foreach ($mac_core_addons as $addon_slug => $addon_data) {
    error_log("MAC Core: Processing addon: {$addon_slug}");
    
    $plugin_file = $addon_data['file'];
    $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_file;
    
    if (file_exists($plugin_path)) {
        // Plugin exists - get real data
        $real_version = $update_manager->get_plugin_version($addon_slug);
        $real_description = get_plugin_description($plugin_file);
        $is_active = is_mac_plugin_active($plugin_file);
        
        error_log("MAC Core: {$addon_slug} - Version: {$real_version}, Active: " . ($is_active ? 'YES' : 'NO'));
        
        // Check for updates if domain license is active
        $update_info = false;
        if ($domain_license_active) {
            error_log("MAC Core: Checking update for {$addon_slug}");
            $update_info = $update_manager->get_update_info($addon_slug, $addon_data['github_repo']);
            error_log("MAC Core: Update info for {$addon_slug}: " . ($update_info ? 'AVAILABLE' : 'NOT AVAILABLE'));
        } else {
            error_log("MAC Core: Skipping update check for {$addon_slug} - domain license not active");
        }
        
        $addon_data['version'] = $real_version;
        $addon_data['description'] = !empty($real_description) ? $real_description : $addon_data['description'];
        $addon_data['is_active'] = $is_active;
        $addon_data['file'] = $plugin_file;
        $addon_data['update_info'] = $update_info;
        $addon_data['github_user'] = $update_manager->check_github_token($addon_slug);
        
        if ($is_active) {
            $installed_addons[$addon_slug] = $addon_data;
            error_log("MAC Core: Added {$addon_slug} to installed_addons");
        } else {
            $available_addons[$addon_slug] = $addon_data;
            error_log("MAC Core: Added {$addon_slug} to available_addons");
        }
    } else {
        // Plugin doesn't exist - use default data
        error_log("MAC Core: {$addon_slug} - Plugin file not found");
        $addon_data['version'] = 'Not Installed';
        $addon_data['is_active'] = false;
        $addon_data['update_info'] = false;
        $addon_data['github_user'] = $update_manager->check_github_token($addon_slug);
        $available_addons[$addon_slug] = $addon_data;
    }
}

error_log("MAC Core: Total installed addons: " . count($installed_addons));
error_log("MAC Core: Total available addons: " . count($available_addons));
error_log("=== End MAC Core Plugins Page Debug ===");
?>

<div class="wrap">
    <h1><?php echo esc_html__('MAC Core Add-ons', 'mac-core'); ?></h1>

    <?php if (!$domain_license_active) : ?>
        <div class="notice notice-warning">
            <p><?php echo esc_html__('Domain license is not active. Update functionality is disabled.', 'mac-core'); ?></p>
        </div>
    <?php endif; ?>

    <div class="mac-core-addons-wrap">
        <div class="mac-core-addons-section">
            <h2><?php echo esc_html__('Available Add-ons', 'mac-core'); ?></h2>
            <div class="mac-core-addon-cards">
                <?php foreach ($available_addons as $addon_slug => $addon_data) : ?>
                    <div class="mac-core-addon-card" style="position: relative;">
                        <h3><?php echo esc_html($addon_data['name']); ?></h3>
                        <p><?php echo esc_html($addon_data['description']); ?></p>
                        <div class="mac-core-addon-meta">
                            <span class="mac-core-addon-version">
                                <?php if ($addon_data['version'] === 'Not Installed') : ?>
                                    <span class="version-not-installed"><?php echo esc_html__('Not Installed', 'mac-core'); ?></span>
                                <?php else : ?>
                                    <?php echo esc_html__('Version', 'mac-core'); ?>: <?php echo esc_html($addon_data['version']); ?>
                                <?php endif; ?>
                            </span>
                            <?php if ($addon_data['github_user']) : ?>
                                <span class="mac-core-github-user">GitHub: <?php echo esc_html($addon_data['github_user']); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="mac-core-addon-actions">
                            <?php if ($addon_data['version'] === 'Not Installed') : ?>
                                <button class="button button-primary mac-core-install-plugin" data-plugin-slug="<?php echo esc_attr($addon_slug); ?>">
                                    <?php echo esc_html__('Install Now', 'mac-core'); ?>
                                </button>
                            <?php else : ?>
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=mac-core-plugins&action=activate&addon=' . $addon_slug), 'mac_core_plugin_action')); ?>" class="button button-primary">
                                    <?php echo esc_html__('Activate', 'mac-core'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (!empty($installed_addons)) : ?>
        <div class="mac-core-addons-section">
            <h2><?php echo esc_html__('Active Add-ons', 'mac-core'); ?></h2>
            <div class="mac-core-installed-addons">
                <?php foreach ($installed_addons as $addon_slug => $addon_data) : ?>
                    <div class="mac-core-installed-addon">
                        <div class="mac-core-addon-info">
                            <h4><?php echo esc_html($addon_data['name']); ?></h4>
                            <span class="mac-core-addon-version"><?php echo esc_html__('Version', 'mac-core'); ?>: <?php echo esc_html($addon_data['version']); ?></span>
                            <?php if ($addon_data['update_info']) : ?>
                                <span class="mac-core-update-available"><?php echo esc_html__('Update Available', 'mac-core'); ?>: <?php echo esc_html($addon_data['update_info']['latest_version']); ?></span>
                            <?php endif; ?>
                            <span class="mac-core-addon-status mac-core-status-active"><?php echo esc_html__('Active', 'mac-core'); ?></span>
                        </div>
                        <div class="mac-core-addon-actions">
                            <?php if ($addon_data['update_info'] && $domain_license_active) : ?>
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=mac-core-plugins&action=update&addon=' . $addon_slug), 'mac_core_plugin_action')); ?>" class="button button-primary">
                                    <?php echo esc_html__('Update to', 'mac-core'); ?> <?php echo esc_html($addon_data['update_info']['latest_version']); ?>
                                </a>
                            <?php else : ?>
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=mac-core-plugins&action=update&addon=' . $addon_slug), 'mac_core_plugin_action')); ?>" class="button" disabled>
                                    <?php echo esc_html__('Update', 'mac-core'); ?>
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=mac-core-plugins&action=deactivate&addon=' . $addon_slug), 'mac_core_plugin_action')); ?>" class="button" 
                                onclick="return confirm('<?php echo esc_js(__('Are you sure you want to deactivate this add-on?', 'mac-core')); ?>');">
                                <?php echo esc_html__('Deactivate', 'mac-core'); ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.mac-core-addons-wrap {
    margin-top: 20px;
}

.mac-core-addons-section {
    background: #fff;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.mac-core-addons-section h2 {
    margin-top: 0;
    color: #23282d;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.mac-core-addon-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.mac-core-addon-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    background: #f9f9f9;
    transition: all 0.3s ease;
}

.mac-core-addon-card:hover {
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}

.mac-core-addon-card h3 {
    margin-top: 0;
    color: #23282d;
    font-size: 18px;
}

.mac-core-addon-card p {
    color: #666;
    margin-bottom: 15px;
}

.mac-core-addon-meta {
    margin-bottom: 15px;
}

.mac-core-addon-version {
    font-size: 12px;
    color: #888;
    background: #e7e7e7;
    padding: 4px 8px;
    border-radius: 3px;
    margin-right: 10px;
}

.mac-core-github-user {
    font-size: 12px;
    color: #0073aa;
    background: #e7f3ff;
    padding: 4px 8px;
    border-radius: 3px;
}

.version-not-installed {
    color: #dc3232;
    font-weight: bold;
}

.mac-core-addon-actions {
    text-align: center;
}

.mac-core-status {
    padding: 6px 12px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 12px;
    text-transform: uppercase;
}

.mac-core-status-active {
    background: #d4edda;
    color: #155724;
}

.mac-core-update-available {
    background: #fff3cd;
    color: #856404;
    padding: 4px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
    margin-left: 10px;
}

.mac-core-installed-addons {
    margin-top: 20px;
}

.mac-core-installed-addon {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-bottom: 10px;
    background: #f9f9f9;
}

.mac-core-addon-info h4 {
    margin: 0 0 5px 0;
    color: #23282d;
}

.mac-core-addon-status {
    margin-left: 10px;
}

.mac-core-addon-actions .button {
    margin-left: 10px;
}

.mac-core-addon-actions .button[disabled] {
    opacity: 0.5;
    cursor: not-allowed;
}
</style> 