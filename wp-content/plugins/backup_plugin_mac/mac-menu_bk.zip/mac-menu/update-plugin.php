<?php
/** Update plugin */

// ====== Cấu hình GitHub ======
$github_token = !empty(get_option('mac_menu_github_key')) ? get_option('mac_menu_github_key') : "";
if (!defined('UPDATE_CHECK_URL')) {
    define('UPDATE_CHECK_URL', 'https://api.github.com/repos/DanteLe97/MAC_MENU/contents/version.json');
}
if (!defined('GITHUB_TOKEN')) {
    define('GITHUB_TOKEN', $github_token);
}

// ====== Hàm gọi API GitHub an toàn với retry mechanism ======
function github_wp_get($url, $retries = 3)
{
    for ($i = 0; $i < $retries; $i++) {
        $args = array(
            'headers' => array(
                'Authorization' => 'token ' . GITHUB_TOKEN,
                'User-Agent'    => 'WordPress Plugin',
                'Accept'        => 'application/vnd.github.v3+json',
            ),
            'timeout' => 60, // Tăng timeout lên 60 giây
        );
        
        $response = wp_remote_get($url, $args);
        
        if (!is_wp_error($response)) {
            $code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            
            if ($code === 200) {
                return $body;
            }
            
            error_log("GitHub HTTP {$code} for {$url} (attempt " . ($i + 1) . ")");
        } else {
            error_log('GitHub request error (attempt ' . ($i + 1) . '): ' . $response->get_error_message());
        }
        
        // Wait before retry (except for last attempt)
        if ($i < $retries - 1) {
            sleep(2);
        }
    }
    
    error_log("GitHub request failed after {$retries} attempts for {$url}");
    return false;
}

// ====== Check key domain ======
$keyDomain = !empty(get_option('mac_domain_valid_key')) ? get_option('mac_domain_valid_key') : "0";
if (!empty($keyDomain)) {
    if (class_exists('MAC_Menu_Domain_Manager')) {
        $manager = MAC_Menu_Domain_Manager::get_instance();
        $manager->handle_check_request($keyDomain);
    } else {
        // Fallback: log error if MAC Core is not available
        error_log('MAC Menu: kvp_handle_check_request called but MAC Core is not available');
    }
}

// ====== Lấy thông tin version ======
global $latest_version, $download_url;
$body = github_wp_get(UPDATE_CHECK_URL);
if ($body !== false) {
    $data = json_decode($body, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($data) && isset($data['content'])) {
        $version_data = base64_decode($data['content']);
        $version_info = json_decode($version_data, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($version_info)) {
            $latest_version = $version_info['version'];
            $download_url   = $version_info['download_url'];
        }
    }
}

// ====== Check update ======
function check_update()
{
    global $latest_version, $download_url;
    if (empty($latest_version) || empty($download_url)) {
        return false;
    }

    if (is_admin()) {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $plugin_data = get_plugin_data($plugin_file);
    }

    $current_version = isset($plugin_data['Version']) ? $plugin_data['Version'] : '1.3.1';
    $required_version = '1.2.0';

    if (version_compare($latest_version, $required_version, '>=') &&
        version_compare($current_version, $latest_version, '<')) {
        return true;
    }

    return false;
}

// ====== Check GitHub Token ======
function check_github_token()
{
    $body = github_wp_get('https://api.github.com/user');
    if ($body === false) {
        return false;
    }
    $data = json_decode($body);
    if (isset($data->login)) {
        return 'Người dùng hiện tại là ' . esc_html($data->login);
    }
    return 'Không thể lấy thông tin người dùng.';
}

// ====== Hiển thị thông báo update ======
if (check_update() === true) {
    add_filter('plugin_row_meta', 'my_plugin_row_meta', 10, 2);
}
function my_plugin_row_meta($links, $file)
{
    if ($file === 'mac-menu/mac-menu.php') {
        global $latest_version, $download_url;
        if (empty($latest_version) || empty($download_url)) {
            return $links;
        }
        $statusDomain = !empty(get_option('mac_domain_valid_status')) ? get_option('mac_domain_valid_status') : "0";
        $buttonUpdate = ($statusDomain === 'activate') ? ' <a href="plugins.php?update_mac=mac-menu">Update Now</a>' : '';
        $update_notice = '<p class="update-message notice inline notice-warning notice-alt">There is a new version <strong>' . $latest_version . '</strong> for plugin.' . $buttonUpdate . '</p>';
        array_unshift($links, $update_notice);
    }
    return $links;
}

// ====== List files trong GitHub ======
function list_files_in_directory($directory)
{
    $body = github_wp_get('https://api.github.com/repos/DanteLe97/MAC_MENU/contents/' . ltrim($directory, '/'));
    if ($body === false) {
        return array();
    }
    $data = json_decode($body, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
        error_log('list_files_in_directory JSON error: ' . json_last_error_msg());
        return array();
    }
    return $data;
}

// ====== Download file content từ GitHub với validation ======
function download_file_content($file_url)
{
    $body = github_wp_get($file_url);
    if ($body === false) {
        error_log('Failed to download file content from: ' . $file_url);
        return '';
    }
    
    $file_info = json_decode($body, true);
    if (json_last_error() === JSON_ERROR_NONE && isset($file_info['content'])) {
        $content = base64_decode($file_info['content']);
        
        // Validate decoded content
        if ($content === false) {
            error_log('Failed to decode base64 content from: ' . $file_url);
            return '';
        }
        
        return $content;
    }
    
    error_log('Invalid file info format from: ' . $file_url);
    return '';
}

// ====== Xóa thư mục ======
function delete_directory($dir)
{
    if (is_dir($dir)) {
        $objects = array_diff(scandir($dir), array('.', '..'));
        foreach ($objects as $object) {
            $file = $dir . '/' . $object;
            (is_dir($file)) ? delete_directory($file) : unlink($file);
        }
        rmdir($dir);
    }
}

// ====== Liệt kê files trong temp directory để debug ======
function list_temp_files($dir, $prefix = '')
{
    $files = array();
    if (is_dir($dir)) {
        $objects = array_diff(scandir($dir), array('.', '..'));
        foreach ($objects as $object) {
            $path = $dir . '/' . $object;
            if (is_dir($path)) {
                $files[] = $prefix . $object . '/';
                $sub_files = list_temp_files($path, $prefix . $object . '/');
                $files = array_merge($files, $sub_files);
            } else {
                $files[] = $prefix . $object;
            }
        }
    }
    return $files;
}

// ====== Download thư mục con với error handling ======
function download_sub_directory_files($sub_directory, $tmp_root)
{
    $files = list_files_in_directory($sub_directory);
    if (!is_array($files) || empty($files)) {
        error_log('No files found in subdirectory: ' . $sub_directory);
        return false;
    }
    
    $plugin_path = $tmp_root . '/' . $sub_directory;
    if (!wp_mkdir_p($plugin_path)) {
        error_log('Failed to create directory: ' . $plugin_path);
        return false;
    }
    
    $success_count = 0;
    $total_files = count($files);
    
    foreach ($files as $file) {
        if (!is_array($file) || !isset($file['type'])) {
            continue;
        }
        
        if ($file['type'] === 'file') {
            $content = download_file_content($file['url']);
            if (empty($content)) {
                error_log('Failed to download file: ' . $file['name'] . ' in ' . $sub_directory);
                continue;
            }
            
            $file_path = $plugin_path . '/' . $file['name'];
            $result = file_put_contents($file_path, $content);
            
            if ($result === false) {
                error_log('Failed to write file: ' . $file_path);
                continue;
            }
            
            $success_count++;
            
        } elseif ($file['type'] === 'dir') {
            $result = download_sub_directory_files($sub_directory . '/' . $file['name'], $tmp_root);
            if ($result) {
                $success_count++;
            }
        }
    }
    
    // Return true if at least 80% of files were downloaded successfully
    return ($success_count / $total_files) >= 0.8;
}

// ====== Download và thay thế plugin với backup và validation ======
function download_and_replace_plugin_files()
{
    $directory = 'mac-menu';
    $files = list_files_in_directory($directory);
    if (!is_array($files) || empty($files)) {
        error_log('No files returned from GitHub for ' . $directory);
        return false;
    }

    $tmp_dir = WP_CONTENT_DIR . '/mac-menu-update-tmp-' . time();
    if (!wp_mkdir_p($tmp_dir)) {
        error_log('Failed to create temporary directory: ' . $tmp_dir);
        return false;
    }
    
    $plugin_base_tmp = $tmp_dir . '/' . $directory;
    if (!wp_mkdir_p($plugin_base_tmp)) {
        error_log('Failed to create plugin temporary directory: ' . $plugin_base_tmp);
        delete_directory($tmp_dir);
        return false;
    }

    $downloaded_files = array();
    $failed_files = array();
    $download_success = true; // Flag để track toàn bộ quá trình download

    // Bước 1: Download tất cả files trước
    foreach ($files as $file) {
        if (!is_array($file) || !isset($file['type'])) {
            continue;
        }
        
        if ($file['type'] === 'file') {
            $content = download_file_content($file['url']);
            
            if (empty($content)) {
                $failed_files[] = $file['name'];
                error_log('Failed to download file: ' . $file['name']);
                $download_success = false;
                continue;
            }
            
            $file_path = $plugin_base_tmp . '/' . $file['name'];
            $result = file_put_contents($file_path, $content);
            
            if ($result === false) {
                $failed_files[] = $file['name'];
                error_log('Failed to write file: ' . $file_path);
                $download_success = false;
                continue;
            }
            
            $downloaded_files[] = $file['name'];
            
        } elseif ($file['type'] === 'dir') {
            $result = download_sub_directory_files($directory . '/' . $file['name'], $tmp_dir);
            if (!$result) {
                $failed_files[] = $file['name'];
                error_log('Failed to download subdirectory: ' . $file['name']);
                $download_success = false;
            }
        }
    }

    // Bước 2: Kiểm tra xem có file nào bị lỗi không
    if (!empty($failed_files) || !$download_success) {
        error_log('Download failed: ' . count($failed_files) . ' files/subdirectories failed');
        error_log('Successfully downloaded files: ' . implode(', ', $downloaded_files));
        error_log('Failed files/subdirectories: ' . implode(', ', $failed_files));
        
        // Debug: Kiểm tra temp directory để xem files đã download
        if (is_dir($tmp_dir)) {
            error_log('Temp directory created at: ' . $tmp_dir);
            $temp_files = list_temp_files($tmp_dir);
            error_log('Files actually present in temp directory: ' . implode(', ', $temp_files));
        }
        
        // Xóa temp directory và trả về false - không thay đổi gì
        delete_directory($tmp_dir);
        return false;
    }

    // Bước 3: Chỉ khi download thành công 100%, mới tạo backup và thay thế
    $plugin_path = WP_PLUGIN_DIR . '/' . $directory;
    $backup_path = null;
    
    if (file_exists($plugin_path)) {
        $backup_path = WP_CONTENT_DIR . '/mac-menu-backup-' . time();
        if (!rename($plugin_path, $backup_path)) {
            error_log('Failed to create backup of existing plugin');
            delete_directory($tmp_dir);
            return false;
        }
    }

    // Bước 4: Thay thế plugin
    $result = rename($plugin_base_tmp, $plugin_path);
    if (!$result) {
        error_log('Failed to replace plugin directory');
        
        // Restore backup nếu có
        if ($backup_path && file_exists($backup_path)) {
            rename($backup_path, $plugin_path);
            error_log('Restored plugin from backup');
        }
        
        delete_directory($tmp_dir);
        return false;
    }

    // Bước 5: Chỉ khi mọi thứ thành công, mới cleanup
    delete_directory($tmp_dir);
    
    // Remove backup after successful update (optional - keep for safety)
    // if ($backup_path && file_exists($backup_path)) {
    //     delete_directory($backup_path);
    // }
    
    error_log('Plugin updated successfully. Backup available at: ' . $backup_path);
    return true;
}

// ====== Trigger update với error handling ======
if (isset($_GET['update_mac']) && $_GET['update_mac'] === 'mac-menu') {
    $result = download_and_replace_plugin_files();
    
    if ($result) {
        // Update successful
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>Plugin updated successfully!</p></div>';
        });
    } else {
        // Update failed
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error is-dismissible"><p>Plugin update failed. Please check error logs and try again.</p></div>';
        });
    }
    
    // Redirect back to plugins page
    if (function_exists('mac_redirect')) {
        mac_redirect('plugins.php');
    } else {
        wp_redirect(admin_url('plugins.php'));
    }
    exit();
}
