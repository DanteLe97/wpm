<?php
// Shortcode hiển thị QR code của trang hiện tại
if (!function_exists('display_page_qr_code')) {
    function display_page_qr_code($atts) {
        global $post;
        
        // Kiểm tra xem có post ID được truyền từ settings không (cho PDF)
        $post_id = null;
        if (isset($atts['post_id']) && !empty($atts['post_id'])) {
            $post_id = intval($atts['post_id']);
        } elseif ($post) {
            $post_id = $post->ID;
        }
        
        $macQRCode = !empty(get_option('mac_qr_code')) ? get_option('mac_qr_code') : 0;
        if (!$post_id || empty($macQRCode)) {
            return '';
        }

        $qr_dir = MAC_PATH . 'adds-on/qr-code-pages/qr-images/';
        $qr_url = MAC_URI . 'adds-on/qr-code-pages/qr-images/';
        $file_name = 'qr-' . $post_id . '.png';
        $file_path = $qr_dir . $file_name;

        // Load thư viện QR nếu chưa tồn tại QR
        if (!file_exists($file_path)) {
            if (!file_exists(MAC_PATH . 'adds-on/qr-code-pages/assets/phpqrcode/phpqrcode.php')) {
                return '<span style="color:red">Thiếu thư viện QR code.</span>';
            }
            require_once MAC_PATH . 'adds-on/qr-code-pages/assets/phpqrcode/phpqrcode.php';

            $site_url = get_site_url();
            $encrypted_id = qrcode_encrypt_id($post_id);
            $qr_data = $site_url . '/qr-redirect/?id=' . $encrypted_id;

            QRcode::png($qr_data, $file_path, QR_ECLEVEL_L, 3);
        }

        return '<img src="' . esc_url($qr_url . $file_name) . '" width="150" height="150" alt="QR Code for ' . esc_attr(get_the_title($post_id)) . '" />';
    }
}
add_shortcode('page_qr_code', 'display_page_qr_code');


// Shortcode tạo nút PDF cho Elementor
if (!function_exists('mac_elementor_pdf_button')) {
    function mac_elementor_pdf_button() {
        $macQRCode = !empty(get_option('mac_qr_code')) ? get_option('mac_qr_code') : 0;
        if (empty($macQRCode)) {
            return '';
        }

        return '<a id="download-pdf-1" class="no-print mac-pdf-button">Download PDF</a>';
        // <a id="download-pdf" class="no-print mac-pdf-button">Download PDF</a>
    }
}
add_shortcode('elementor_pdf_button', 'mac_elementor_pdf_button');
