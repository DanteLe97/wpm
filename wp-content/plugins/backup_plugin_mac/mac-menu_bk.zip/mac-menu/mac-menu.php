<?php
/*
Plugin Name:  MAC Menu
Description:  Menu Services
Version:      1.6.3
Author:       Mac Marketing
Author URI:   https://macmarketing.us/
License:      GPL v1
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  mac-plugin
Domain Path:  /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

add_action('plugins_loaded', function() {
    $mac_core_path = WP_PLUGIN_DIR . '/mac-core/mac-core.php';

    // Nếu plugin A tồn tại mà chưa load, thì load nó
    if ( file_exists($mac_core_path) && !class_exists('MAC_Core') ) {
        require_once $mac_core_path;

        if ( defined('WP_DEBUG') && WP_DEBUG ) {
            error_log('MAC Core loaded via MAC Menu plugin');
        }
    }
}, 1);

// Load MAC Core plugin first to ensure compatibility functions are available
// $mac_core_path = WP_PLUGIN_DIR . '/mac-core/mac-core.php';
// if (file_exists($mac_core_path) && !defined('MAC_CORE_VERSION')) {
//     require_once $mac_core_path;
    
//     // Log for debugging
//     if (defined('WP_DEBUG') && WP_DEBUG) {
//         error_log('MAC Core loaded via MAC Menu plugin');
//     }
// }



define('MAC_PATH', plugin_dir_path( __FILE__ ) );
define('MAC_URI', plugin_dir_url( __FILE__ ) );

// Compatibility layer is now handled by MAC Core plugin

// Test compatibility is now handled by MAC Core debug page

// define('MAC_MENU_VALIDATE_KEY', 'http://localhost/Domain_Management/validate_key.php');
// define('MAC_MENU_VALIDATE_URL', 'http://localhost/Domain_Management/validate_url.php');
// define('MAC_MENU_REGISTER_DOMAIN', 'http://localhost/Domain_Management/register-domain.php');

// hosting
// define('MAC_MENU_VALIDATE_KEY', 'https://menulicense.macmarketing.us/validate_key.php');
// define('MAC_MENU_VALIDATE_URL', 'https://menulicense.macmarketing.us/validate_url.php');
// define('MAC_MENU_REGISTER_DOMAIN', 'https://menulicense.macmarketing.us/register-domain.php');

define('MAC_MENU_VALIDATE_KEY', 'https://wpm.macusaone.com/api/v1/menu-license/validate-key');
define('MAC_MENU_VALIDATE_URL', 'https://wpm.macusaone.com/api/v1/menu-license/validate-url');
define('MAC_MENU_REGISTER_DOMAIN', 'https://wpm.macusaone.com/api/v1/menu-license/register-domain');

/* xây lớp bảo mật */
/**  Bảo vệ tệp wp-config.php */
function protect_wp_config() {
    $htaccess_file = ABSPATH . '.htaccess';
    if (file_exists($htaccess_file) && is_writable($htaccess_file)) {
        $rules = "\n<files wp-config.php>\norder allow,deny\ndenY from all\n</files>\n";
        file_put_contents($htaccess_file, $rules, FILE_APPEND);
    }
}
register_activation_hook(__FILE__, 'protect_wp_config');

/**  Chặn XML-RPC */
add_filter('xmlrpc_enabled', '__return_false');

add_action('admin_menu','mac_admin_menu');
function mac_admin_menu(){
    // Thêm menu cha
        add_menu_page(
            'MAC Menu',
            'MAC Menu',
            'edit_published_pages',
            'mac-cat-menu',//menu_slug
            'mac_menu_admin_page_cat_menu',
            'dashicons-admin-page',
            26
        );
        add_submenu_page(
            'mac-cat-menu',
            'New Menu',
            'New Menu',
            'edit_published_pages',
            'mac-new-cat-menu',
            'mac_menu_admin_page_news_cat_menu',
            26
        );
        add_submenu_page(
            'mac-cat-menu',
            'Settings/Import',
            'Settings/Import',
            'edit_published_pages',
            'mac-menu',
            'mac_menu_admin_page_dashboard',
            26
        );
}

function change_media_label(){
    global $submenu;
    if(isset($submenu['mac-cat-menu'])):
        $submenu['mac-cat-menu'][0][0] = 'All Menu';
    endif;
}
add_action( 'admin_menu', 'change_media_label' );
function mac_menu_admin_page_dashboard(){
    include_once MAC_PATH.'includes/admin_pages/dashboard.php';
}

function mac_menu_admin_page_cat_menu(){
    include_once MAC_PATH.'includes/admin_pages/cat.php';
}

function mac_menu_admin_page_news_cat_menu(){
    mac_redirect('admin.php?page=mac-cat-menu&id=new');
}

if( !function_exists('mac_redirect') ){
    function mac_redirect($url){
        echo("<script>location.href = '".$url."'</script>");
    }
}

// Làm việc với CSDL trong wordpress
include_once MAC_PATH.'includes/classes/macMenu.php';

$htmlNew = get_option('mac_html_old',0);
if(!empty($htmlNew)) {
    include_once MAC_PATH.'/blocks/new_html/render/render-module.php';
    include_once MAC_PATH.'/blocks/new_html/module/cat_menu_basic.php';
    include_once MAC_PATH.'/blocks/new_html/module/cat_menu_table.php';
}else{
    include_once MAC_PATH.'/blocks/render/render-module.php';
    include_once MAC_PATH.'/blocks/module/cat_menu_basic.php';
    include_once MAC_PATH.'/blocks/module/cat_menu_table.php';
}

include_once MAC_PATH.'/includes/admin_pages/table-list-menu.php';

// create or update data
if (false === get_option('my_plugin_schema_version')) {
    add_option('my_plugin_schema_version', '2');
}
create_or_update_cat_table();

function add_media_button_shortcode() {
    ob_start();
    ?>
    <div class="add-media-button-container">
        <input type="text" id="custom_media_url" name="custom_media_url" size="25" readonly />
        <button type="button" id="add_media_button">Add Media</button>
        <img id="media_preview" class="featured_img" src="" style="max-width: 200px; display: none;" />
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('add_media_button', 'add_media_button_shortcode');

// Kết hợp với enqueue scripts và styles
function mac_enqueue_scripts() {
    wp_enqueue_style( 'mac-style', MAC_URI . 'public/css/mac-menu-style.css' );
    wp_enqueue_script( 'mac-script', MAC_URI . 'public/js/mac-menu-script.js', array( 'jquery' ), '', true );
}
add_action( 'wp_enqueue_scripts', 'mac_enqueue_scripts' );
function mac_admin_enqueue_scripts() {
    global $pagenow;
    wp_enqueue_script( 'jquery' );
    if ( isset( $_GET['page']) && 
            (   $_GET['page'] == 'mac-new-cat-menu' ||
                $_GET['page'] == 'mac-cat-menu' ||
                $_GET['page'] == 'mac-menu'
            )
            
        )  {
            wp_enqueue_media();
            /* jquery ui */
            wp_enqueue_style( 'jquery-ui', MAC_URI . 'admin/css/jquery-ui.css' );
            wp_enqueue_style( 'admin-style', MAC_URI . 'admin/css/admin-style.css' );
            wp_enqueue_script( 'jquery-ui', MAC_URI . 'admin/js/jquery-ui.js', array( 'jquery' ), '', true );
            wp_enqueue_script( 'jquery-repeater', MAC_URI . 'admin/js/jquery.repeater.js', array( 'jquery' ), '', true );
            wp_enqueue_script( 'admin-script', MAC_URI . 'admin/js/admin-script.js', array( 'jquery-repeater' ), '', true );
    }
}
add_action( 'admin_enqueue_scripts', 'mac_admin_enqueue_scripts' );

function create_slug($string) {
    $string = strtolower($string);
    $string = preg_replace('/[áàảãạăắằẳẵặâấầẩẫậ]/u', 'a', $string);
    $string = preg_replace('/[éèẻẽẹêếềểễệ]/u', 'e', $string);
    $string = preg_replace('/[íìỉĩị]/u', 'i', $string);
    $string = preg_replace('/[óòỏõọôốồổỗộơớờởỡợ]/u', 'o', $string);
    $string = preg_replace('/[úùủũụưứừửữự]/u', 'u', $string);
    $string = preg_replace('/[ýỳỷỹỵ]/u', 'y', $string);
    $string = preg_replace('/[đ]/u', 'd', $string);
    
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    $string = preg_replace('/[\s-]+/', '-', $string);
    $string = trim($string, '-');
    
    return $string;
}
function create_array($string,$name=null) {
    $new_array = explode('|', $string);
    if(!empty($name)){
        $result = array();
        foreach ($new_array as $item) {
            $result[] = array($name => $item);
        }
        return $result;
    }else{
        return $new_array;
    }
}

function getGalleryFromIds($ids,$url = null) {
    $htmlGallery = '';
    $image_ids_array = explode('|', $ids);
    if (!empty($image_ids_array)) {
        foreach ($image_ids_array as $image_id) {
            $image_url = wp_get_attachment_image_src($image_id, 'full');
            if ($image_url) {
                if( isset($url) ):
                    $htmlGallery .= '<img src="' . esc_url($image_url[0]) . '" alt="image">';
                else:
                    $htmlGallery .= '<div class="image-preview" data-id="' . $image_id . '">';
                    $htmlGallery .= '<img src="' . esc_url($image_url[0]) . '" alt="image">';
                    $htmlGallery .= '<span class="remove-img-button" data-id="' . $image_id . '">x</span>';
                    $htmlGallery .= '</div>';
                endif;
            }
        }
    } else {
        echo 'No images found.';
    }
    return $htmlGallery;
}

add_action( 'elementor/widgets/register', 'mac_register_custom_widget' );
function mac_register_custom_widget( $widgets_manager ) {
    require_once( MAC_PATH. 'blocks/mac-menu.php' );
    
    $widgets_manager->register( new \Mac_Module_Widget() );
    /* QR code Module */
    include_once MAC_PATH.'adds-on/qr-module.php';
    $widgets_manager->register( new \Mac_Module_Widget_QR() );
}

// phân quyền admin
function add_custom_capabilities() {
    $role = get_role('editor');
    if ($role) {
        $role->add_cap('edit_published_pages');
    }
}
add_action('init', 'add_custom_capabilities');

function remove_custom_capabilities() {
    // Lấy vai trò người dùng
    $role = get_role('editor');
    // Xóa quyền cho vai trò
    if ($role) {
        $role->remove_cap('edit_published_pages');
    }
}
//add_action('init', 'remove_custom_capabilities');

// Hàm để loại bỏ ký tự escape từ chuỗi
function remove_slashes_from_array(&$item, $key) {
    if (is_array($item)) {
        array_walk_recursive($item, 'remove_slashes_from_array');
    } else {
        $item = stripslashes($item);
    }
}

function buildTree(array $elements, $parentId = 0) {
    $branch = array();
    
    foreach ($elements as $element) {
        if ($element->parents_category == $parentId) {
            $children = buildTree($elements, $element->id);
            if ($children) {
                $element['children'] = $children;
            }
            $branch[] = $element;
        }
    }
    return $branch;
}
function buildOptions($tree, $prefix = '') {
    $html = '';
    foreach ($tree as $branch) {
        $html .= '<option value="' . $tree->id . '">' . $prefix .  $tree->category_name . '</option>';
        if (isset($branch['children'])) {
            $html .= buildOptions($branch['children'], $prefix . '--');
        }
    }
    return $html;
}

/* wp editor */
function custom_tinymce_config($init) {
    $init['wpautop'] = false;
    $init['apply_source_formatting'] = true;
    return $init;
}
add_filter('tiny_mce_before_init', 'custom_tinymce_config');

/** Dynamic */
function register_request_dynamic_tag_group( $dynamic_tags_manager ) {
    $dynamic_tags_manager->register_group(
        'request-mac-menu',
        [
            'title' => esc_html__( 'Mac Category', 'mac-plugin' )
        ]
    );
}
add_action( 'elementor/dynamic_tags/register', 'register_request_dynamic_tag_group' );

function register_request_dynamic_tag_item_menu_group( $dynamic_tags ) {
    $dynamic_tags->register_group(
        'request-mac-item-menu',
        [
            'title' => esc_html__( 'Mac Category List Item', 'mac-plugin' )
        ]
    );
}
add_action( 'elementor/dynamic_tags/register', 'register_request_dynamic_tag_item_menu_group' );

function register_dynamic_tag( $dynamic_tags_manager ) {
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-name.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-description.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-price.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-img.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-gallery.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-heading-col.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-list-item.php' );
    require_once( MAC_PATH . '/dynamic-tags/cat-menu/mac-menu-dynamic-tag-content.php' );

    /** item menu */

    require_once( MAC_PATH . '/dynamic-tags/item-menu/mac-menu-dynamic-tag-item-name.php' );
    require_once( MAC_PATH . '/dynamic-tags/item-menu/mac-menu-dynamic-tag-item-description.php' );
    require_once( MAC_PATH . '/dynamic-tags/item-menu/mac-menu-dynamic-tag-item-price.php' );
    require_once( MAC_PATH . '/dynamic-tags/item-menu/mac-menu-dynamic-tag-item-img.php' );


    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Name );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Description );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Price );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Img );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Gallery );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Heading_Col );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_List_Item );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Content );

    /** item menu */

    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Item_Name );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Item_Description );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Item_Price );
    $dynamic_tags_manager->register( new \Elementor_Dynamic_Tag_Mac_Menu_Item_Img );
}
add_action( 'elementor/dynamic_tags/register', 'register_dynamic_tag' );

/** add field set current menu */
function custom_meta_box() {
    $option_value = get_option('mac_custom_meta_box_page');
    $nameMetaBoxPage = !empty($option_value) ? $option_value : "page";
    add_meta_box(
        'custom_meta_box_id',
        'MAC Menu',
        'custom_meta_box_callback',
        $nameMetaBoxPage,
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'custom_meta_box');

function custom_meta_box_callback($post) {
    $value = get_post_meta($post->ID, '_custom_meta_key', true);
    echo '<label for="custom_meta_box_text">Category </label>';
    echo '<input type="text" id="custom_meta_box_text" name="custom_meta_box_text" value="' . esc_attr($value) . '" />';
}

function save_custom_meta_box_data($post_id) {
    if (array_key_exists('custom_meta_box_text', $_POST)) {
        update_post_meta(
            $post_id,
            '_custom_meta_key',
            $_POST['custom_meta_box_text']
        );
    }
}
add_action('save_post', 'save_custom_meta_box_data');

global $custom_id,$custom_index,$custom_array;
$custom_array = [];
$custom_id = null;
$custom_index = null;

function set_custom_array($array) {
    global $custom_array;
    $custom_array = $array;
}

function get_custom_array() {
    global $custom_array;
    return $custom_array;
}

function set_custom_index($index) {
    global $custom_index;
    $custom_index = $index;
}

function get_custom_index() {
    global $custom_index;
    return $custom_index;
}
/* register domain and update plugin */
if (false === get_option('mac_menu_github_key')) {
    add_option('mac_menu_github_key', '0');
}
if (false === get_option('mac_domain_valid_key')) {
    add_option('mac_domain_valid_key', '0');
}
if (false === get_option('mac_domain_valid_status')) {
    add_option('mac_domain_valid_status', '0');
}

// gửi và đăng ký domain
function mac_register_domain_on_activation() {
    $api_url = MAC_MENU_REGISTER_DOMAIN;
    $domain = get_site_url(); 
    $response = wp_remote_post($api_url, array(
        'method'    => 'POST',
        'body'      => array(
            'url' => $domain
        ),
        'timeout'   => 45,
    ));
    if (is_wp_error($response)) {
        error_log('Error sending domain to API: ' . $response->get_error_message());
    } else {
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if ($data['status'] == 'success') {
            error_log('Domain registered successfully.');
        } else {
            error_log('Failed to register domain: ' . $data['message']);
        }
    }
}
// Kích hoạt hàm khi plugin được kích hoạt
//register_activation_hook(__FILE__, 'mac_register_domain_on_activation');

// require_once( MAC_PATH . '/domain-manager.php'); // Moved to MAC Core

require_once( MAC_PATH . '/update-plugin.php' );

// export data menu
function export_data_to_csv() {
    if (isset($_REQUEST['export_table_data']) && $_REQUEST['export_table_data'] == '1') {
        global $wpdb;

        // Lấy dữ liệu từ bảng trong database
        $table_name = $wpdb->prefix . "mac_cat_menu"; // Thay đổi theo bảng của bạn
        $data = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

        // Nếu có dữ liệu
        if (!empty($data)) {

            // Xóa tất cả các buffer trước khi xuất
            ob_clean();
            // Xử lý headers để xuất file CSV
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="exported_data.csv"');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');

            // Mở luồng ghi CSV
            $output = fopen('php://output', 'w');

            // Thêm dòng tiêu đề vào CSV
            fputcsv($output, array(
                'id', 
                'category_name', 
                'category_description', 
                'price', 
                'featured_img', 
                'parents_category', 
                'is_hidden', 
                'is_table', 
                'table_heading', 
                'item_list_name', 
                'item_list_price', 
                'item_list_description', 
                'item_list_fw', 
                'item_list_img',
                'item_list_position',
                'category_inside',
                'category_inside_order'
            ));
            
            // Duyệt qua các bản ghi và thêm vào CSV
            foreach ($data as $row) {
                // Tạo dữ liệu cho từng dòng
                $rowData = array(
                    $row['id'],
                    $row['category_name'],
                    $row['category_description'], 
                    $row['price'],
                    $row['featured_img'],
                    $row['parents_category'],
                    $row['is_hidden'],
                    $row['is_table'],
                    '', '', '', '', '', '','', $row['category_inside'], $row['category_inside_order']
                );

                // Kiểm tra và xử lý các trường 'data_table' và 'group_repeater'
                if (!empty($row['data_table'])) {
                    $arrayDataTable = json_decode($row['data_table'], true);
                    $rowData[8] = implode('|', $arrayDataTable); // Chuyển data_table thành chuỗi
                }
                $index = 0;
                

                if (!empty($row['group_repeater'])) {

                    $arrayGroupRepeater = json_decode($row['group_repeater'], true);
                    if(!empty($arrayGroupRepeater)) {
                        foreach ($arrayGroupRepeater as $item) {
                            $rowData1 = $rowData;
                            $rowData1['id']  = $row['id']++;
                            // Cập nhật dữ liệu từ 'group_repeater'
                            if(!empty($item['name'])){
                                $rowData1[9] = $item['name'];
                                if (!empty($item['price-list'])) {
                                    $prices = array_column($item['price-list'], 'price');
                                    $stringPrices = implode('|', $prices);
                                    $rowData1[10] = $stringPrices;
                                }
                                $rowData1[11] = $item['description'];
                                $rowData1[12] = $item['fullwidth'];
                                $rowData1[13] = $item['featured_img'];
                                $rowData1[14] = isset($item['position']) ? $item['position'] : '0';

                                $rowData[9] = $item['name'];
                                if (!empty($item['price-list'])) {
                                    $prices = array_column($item['price-list'], 'price');
                                    $stringPrices = implode('|', $prices);
                                    $rowData[10] = $stringPrices;
                                }
                                $rowData[11] = $item['description'];
                                $rowData[12] = $item['fullwidth'];
                                $rowData[13] = $item['featured_img'];
    
                                // Ghi dòng dữ liệu vào CSV
                                
                                if ($index > 0) {
                                    // Nếu không phải dòng đầu tiên, giữ lại dữ liệu của group_repeater mà không lặp lại các thông tin chung
                                    $rowData1[0] = ''; 
                                    $rowData1[1] = ''; 
                                    $rowData1[2] = '';
                                    $rowData1[3] = '';
                                    $rowData1[4] = '';
                                    $rowData1[5] = '';
                                    $rowData1[6] = '';
                                    $rowData1[7] = '';
                                    $rowData1[8] = '';
                                    $rowData1[15] = '';
                                    $rowData1[16] = '';
                                    $rowData1[17] = '';
                                }
    
                                // Ghi vào CSV
                                $index++;
                                fputcsv($output, $rowData1);
                            
                            }
                                
                        }
                    }else{
                        fputcsv($output, $rowData);
                    }
                    

                }else{
                    // Ghi dòng cuối cùng của bản ghi vào CSV
                    //fputcsv($output, $rowData);
                }

                
            }

            // Đóng file output
            //fputcsv($output, $rowData);
            
            fclose($output);
            
            // Dừng script và xuất file CSV
            exit();
        }

        exit();
    }
}
add_action('admin_post_export_csv', 'export_data_to_csv');  // Đăng ký hàm export với WordPress admin hook
add_action('admin_post_nopriv_export_csv', 'export_data_to_csv'); // Cho phép người dùng không đăng nhập sử dụng


////////////////////
/// *** Privacy Policy Settings
////////////////////////

include_once(   MAC_PATH .  '/mac-privacy-policy-settings.php' );

////////////////////
/// *** Adds on
////////////////////////

include_once MAC_PATH.'adds-on/dual-price.php';


if (false === get_option('mac_qr_code')) {
    add_option('mac_qr_code', '0');
}
$macQRCode = !empty(get_option('mac_qr_code')) ? get_option('mac_qr_code') : 0;
/* QR code pages */
if($macQRCode == 1) {
    include_once MAC_PATH.'adds-on/qr-code-pages/qr-code-pages.php';
}
include_once MAC_PATH.'adds-on/qr-code-pages/short-code.php';

include_once MAC_PATH . '/adds-on/popup-tuner.php';

class My_Custom_CSS_Elementor {
    public function __construct() {
        add_action('elementor/element/after_section_end', [$this, 'add_custom_css_section'], 10, 2);
        add_action('elementor/element/parse_css', [$this, 'add_custom_css_to_elementor'], 10, 2);
    }

    public function add_custom_css_section($element, $section_id) {
        if ('section_advanced' !== $section_id) {
            return;
        }

        $element->start_controls_section(
            'mac_section_custom_css', // Thêm tiền tố 'mac'
            [
                'label' => esc_html__('Custom CSS', 'my-custom-css'),
                'tab' => \Elementor\Controls_Manager::TAB_ADVANCED,
            ]
        );

        $element->add_control(
            'mac_custom_css', // Thêm tiền tố 'mac'
            [
                'label' => esc_html__('Add your own custom CSS', 'my-custom-css'),
                'type' => \Elementor\Controls_Manager::CODE,
                'language' => 'css',
                'render_type' => 'ui',
            ]
        );

        $element->end_controls_section();
    }

    public function add_custom_css_to_elementor($post_css, $element) {
        $element_settings = $element->get_settings();
        if (empty($element_settings['mac_custom_css'])) { // Cập nhật tên control
            return;
        }

        $css = trim($element_settings['mac_custom_css']); // Cập nhật tên control
        if (empty($css)) {
            return;
        }

        $css = str_replace('selector', $post_css->get_element_unique_selector($element), $css);
        $post_css->get_stylesheet()->add_raw_css($css);
    }
}

// Khởi tạo plugin
add_action('plugins_loaded', function() {
    if (did_action('elementor/loaded')) {
        new My_Custom_CSS_Elementor();
    }
});


/** custom link auto editor */
include_once MAC_PATH.'adds-on/auto-login.php';

include_once MAC_PATH.'adds-on/mac-authorize-policy-and-terms-settings.php';



/** API */

require_once MAC_PATH . 'includes/api/mac-api.php';
