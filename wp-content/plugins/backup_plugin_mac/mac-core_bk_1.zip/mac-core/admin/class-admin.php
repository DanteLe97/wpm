<?php
namespace MAC_Core\Admin;

class Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function add_admin_menu() {
        add_menu_page(
            __('MAC Core', 'mac-core'),
            __('MAC Core', 'mac-core'),
            'manage_options',
            'mac-core',
            array($this, 'render_admin_page'),
            'dashicons-admin-plugins',
            30
        );

        add_submenu_page(
            'mac-core',
            __('Dashboard', 'mac-core'),
            __('Dashboard', 'mac-core'),
            'manage_options',
            'mac-core',
            array($this, 'render_admin_page')
        );



        add_submenu_page(
            'mac-core',
            __('Add-ons', 'mac-core'),
            __('Add-ons', 'mac-core'),
            'manage_options',
            'mac-core-plugins',
            array($this, 'render_plugins_page')
        );


    }

    public function enqueue_scripts($hook) {
        if (strpos($hook, 'mac-core') === false) {
            return;
        }

        wp_enqueue_style(
            'mac-core-admin',
            MAC_CORE_URL . 'admin/css/admin.css',
            array(),
            MAC_CORE_VERSION
        );

        wp_enqueue_script(
            'mac-core-admin',
            MAC_CORE_URL . 'admin/js/admin.js',
            array('jquery'),
            MAC_CORE_VERSION,
            true
        );

        wp_localize_script('mac-core-admin', 'macCoreAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac-core-admin'),
            'i18n' => array(
                'confirmDelete' => __('Are you sure you want to delete this item?', 'mac-core'),
                'error' => __('An error occurred. Please try again.', 'mac-core'),
                'success' => __('Operation completed successfully.', 'mac-core')
            )
        ));
    }

    public function render_admin_page() {
        require_once MAC_CORE_PATH . 'admin/views/dashboard.php';
    }



    public function render_plugins_page() {
        require_once MAC_CORE_PATH . 'admin/views/plugins.php';
    }

} 