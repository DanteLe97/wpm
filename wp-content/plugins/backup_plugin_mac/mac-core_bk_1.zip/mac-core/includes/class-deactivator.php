<?php
namespace MAC_Core;

class Deactivator {
    public static function deactivate() {
        // Clear plugin transients
        delete_transient('mac_core_plugin_updates');
        delete_transient('mac_core_license_status');

        // Clear cache
        wp_cache_flush();
    }
} 