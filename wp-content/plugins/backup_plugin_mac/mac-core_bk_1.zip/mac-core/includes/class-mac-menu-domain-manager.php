<?php
/**
 * MAC Menu Domain Manager Class
 * 
 * This class was moved from mac-menu plugin to provide compatibility
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// MAC Menu API Constants
if (!defined('MAC_MENU_VALIDATE_KEY')) {
    define('MAC_MENU_VALIDATE_KEY', 'https://wpm.macusaone.com/api/v1/menu-license/validate-key');
}
if (!defined('MAC_MENU_VALIDATE_URL')) {
    define('MAC_MENU_VALIDATE_URL', 'https://wpm.macusaone.com/api/v1/menu-license/validate-url');
}
if (!defined('MAC_MENU_REGISTER_DOMAIN')) {
    define('MAC_MENU_REGISTER_DOMAIN', 'https://wpm.macusaone.com/api/v1/menu-license/register-domain');
}

class MAC_Menu_Domain_Manager {
    private static $instance = null;
    private $current_version;
    private $plugin_file;

    // Constants
    const DEFAULT_VERSION = '1.0.1';
    const TIMEOUT = 45;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
        $this->init_hooks();
    }

    private function init() {
        $this->plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $this->current_version = $this->get_plugin_version();
    }

    private function init_hooks() {
        // Hooks are now handled by compatibility layer to avoid conflicts
        // add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        // add_action('wp_ajax_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
        // add_action('wp_ajax_nopriv_kvp_handle_ajax_request', array($this, 'handle_ajax_request'));
    }

    private function get_plugin_version() {
        if (is_admin() && function_exists('get_plugin_data')) {
            $plugin_data = get_plugin_data($this->plugin_file);
            return isset($plugin_data['Version']) ? $plugin_data['Version'] : self::DEFAULT_VERSION;
        }
        return self::DEFAULT_VERSION;
    }

    public function enqueue_scripts() {
        wp_localize_script('admin-script', 'kvp_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac_menu_domain_nonce')
        ));
    }

    public function handle_check_request($key_domain_check = null) {
        if (empty($key_domain_check)) {
            $this->reset_domain_options();
            return;
        }

        $api_url = MAC_MENU_VALIDATE_KEY;
        $domain = get_site_url() . '/';
        
        $response = $this->make_api_request($api_url, array(
            'key' => $key_domain_check,
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            error_log('MAC Menu Domain Check Error: ' . $response->get_error_message());
            // Không reset khi API lỗi, giữ nguyên options cũ
            return;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('MAC Menu: Empty response from API, keeping existing options');
            return; // Không reset khi response rỗng
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('MAC Menu: JSON parse error, keeping existing options');
            return; // Không reset khi JSON lỗi
        }

        $this->process_domain_response($data, $key_domain_check);
    }

    public function handle_check_request_url() {
        $api_url = MAC_MENU_VALIDATE_URL;
        $domain = get_site_url() . '/';
        
        $response = $this->make_api_request($api_url, array(
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            error_log('MAC Menu Domain URL Check Error: ' . $response->get_error_message());
            return; // Không reset khi API lỗi
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('MAC Menu: Empty response from URL check API, keeping existing options');
            return; // Không reset khi response rỗng
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('MAC Menu: JSON parse error in URL check, keeping existing options');
            return; // Không reset khi JSON lỗi
        }

        $this->process_domain_url_response($data);
    }

    public function force_sync_license() {
        // Public method để force sync license với CRM
        error_log('MAC Menu: Force sync requested by admin');
        $this->force_sync_with_crm();
    }
    
    public function handle_ajax_request() {
        // Debug: Log the nonce for debugging
        error_log('MAC Menu AJAX Request - POST data: ' . print_r($_POST, true));
        
        // Verify nonce if it exists
        if (isset($_POST['nonce'])) {
            if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
                error_log('MAC Menu AJAX Request - Nonce verification failed');
                wp_send_json_error('Invalid security token.');
                return;
            }
        }

        if (!isset($_POST['key'])) {
            wp_send_json_error('Key is required.');
            return;
        }

        $key = sanitize_text_field($_POST['key']);
        $api_url = MAC_MENU_REGISTER_DOMAIN;
        $domain = get_site_url() . '/';

        $response = $this->make_api_request($api_url, array(
            'key' => $key,
            'url' => $domain,
            'menuversion' => $this->current_version
        ));

        if (is_wp_error($response)) {
            wp_send_json_error('API request failed: ' . $response->get_error_message());
            return;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            wp_send_json_error('Empty response from server.');
            return;
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error('Invalid response format from server.');
            return;
        }

        $this->process_ajax_response($data);
    }

    private function make_api_request($url, $body) {
        // Debug: Log API request details
        error_log('MAC Menu API Request - URL: ' . $url);
        error_log('MAC Menu API Request - Body: ' . print_r($body, true));
        
        $response = wp_remote_post($url, array(
            'method' => 'POST',
            'body' => $body,
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded'
            )
        ));
        
        // Debug: Log API response
        if (is_wp_error($response)) {
            error_log('MAC Menu API Response - Error: ' . $response->get_error_message());
        } else {
            $body_response = wp_remote_retrieve_body($response);
            $status_code = wp_remote_retrieve_response_code($response);
            error_log('MAC Menu API Response - Status: ' . $status_code);
            error_log('MAC Menu API Response - Body: ' . $body_response);
        }
        
        return $response;
    }

    private function process_domain_response($data, $key = null) {
        // Kiểm tra xem có phải lỗi API không
        if ($this->is_api_error($data)) {
            error_log('MAC Menu: API Error detected, keeping existing options');
            return; // Không reset khi API lỗi
        }
        
        // Kiểm tra key có hợp lệ không
        if (!isset($data['valid']) || !$data['valid']) {
            // Nếu có license active, cần thêm kiểm tra để tránh reset nhầm
            if ($this->should_preserve_license()) {
                error_log('MAC Menu: Invalid key but active license exists, double-checking before reset');
                // Có thể thêm logic kiểm tra thêm ở đây
            }
            
            error_log('MAC Menu: Invalid key detected, resetting options');
            $this->reset_domain_options();
            return;
        }

        $current_status = get_option('mac_domain_valid_status', '0');
        
        if ($current_status !== $data['statusDomain']) {
            $this->update_domain_options($data);
            $this->reload_page();
        }
    }
    
    private function process_domain_url_response($data) {
        // Kiểm tra xem có phải lỗi API không
        if ($this->is_api_error($data)) {
            error_log('MAC Menu: API Error detected in URL check, keeping existing options');
            return; // Không reset khi API lỗi
        }
        
        // Kiểm tra domain có được đăng ký trong CRM không
        if (!isset($data['valid']) || !$data['valid']) {
            error_log('MAC Menu: Domain not found in CRM, resetting options');
            $this->reset_domain_options();
            return;
        }
        
        // Nếu domain hợp lệ nhưng không có key, cũng reset
        if (!isset($data['keyDomain']) || empty($data['keyDomain'])) {
            error_log('MAC Menu: Domain valid but no key assigned, resetting options');
            $this->reset_domain_options();
            return;
        }
        
        // Kiểm tra key hiện tại trong database có khớp với key từ CRM không
        $current_key = get_option('mac_domain_valid_key', '');
        if (!empty($current_key) && $current_key !== $data['keyDomain']) {
            error_log('MAC Menu: Key mismatch - DB: ' . $current_key . ' vs CRM: ' . $data['keyDomain'] . ', resetting options');
            $this->reset_domain_options();
            return;
        }
        
        // Nếu domain và key đều hợp lệ, cập nhật options
        $current_status = get_option('mac_domain_valid_status', '0');
        
        if ($current_status !== $data['statusDomain']) {
            $this->update_domain_options($data);
            $this->reload_page();
        }
    }
    
    private function is_api_error($data) {
        // Kiểm tra các trường hợp lỗi API
        if (empty($data)) {
            return true; // Response rỗng
        }
        
        // Kiểm tra có phải error response không
        if (isset($data['error']) || isset($data['error_code'])) {
            return true;
        }
        
        // Kiểm tra có phải HTML error page không
        if (is_string($data) && (strpos($data, '<html') !== false || strpos($data, 'error') !== false)) {
            return true;
        }
        
        // Kiểm tra có phải JSON parse error không
        if (json_last_error() !== JSON_ERROR_NONE) {
            return true;
        }
        
        return false;
    }

    private function process_ajax_response($data) {
        // Debug: Log the response data
        error_log('MAC Menu Process AJAX Response - Data: ' . print_r($data, true));
        
        if (!isset($data['valid']) || !$data['valid']) {
            error_log('MAC Menu Process AJAX Response - Invalid key');
            wp_send_json_error($data['message'] ?? 'Invalid key.');
            return;
        }

        error_log('MAC Menu Process AJAX Response - Valid key, updating options');
        $this->update_domain_options($data);
        
        // Send a simple success message instead of an object
        wp_send_json_success($data['message'] ?? 'Key is valid!');
    }

    private function update_domain_options($data) {
        // Debug: Log the options being updated
        error_log('MAC Menu Update Domain Options - Data: ' . print_r($data, true));
        
        update_option('mac_domain_valid_key', $data['keyDomain']);
        update_option('mac_domain_valid_status', $data['statusDomain']);
        
        // Update last sync time
        update_option('mac_domain_last_sync', time());
        error_log('MAC Menu Update Domain Options - Last sync time updated: ' . date('Y-m-d H:i:s'));

        if (in_array($data['statusDomain'], array('activate', 'deactivate'))) {
            update_option('mac_menu_github_key', $data['keytoken']);
            error_log('MAC Menu Update Domain Options - GitHub key updated: ' . $data['keytoken']);
        } else {
            update_option('mac_menu_github_key', null);
            error_log('MAC Menu Update Domain Options - GitHub key cleared');
        }
        
        error_log('MAC Menu Update Domain Options - Domain key: ' . $data['keyDomain']);
        error_log('MAC Menu Update Domain Options - Status: ' . $data['statusDomain']);
    }

    private function reset_domain_options() {
        error_log('MAC Menu: Resetting domain options');
        update_option('mac_domain_valid_key', null);
        update_option('mac_domain_valid_status', null);
        update_option('mac_menu_github_key', null);
        
        // Update last sync time when resetting
        update_option('mac_domain_last_sync', time());
        error_log('MAC Menu: Last sync time updated on reset: ' . date('Y-m-d H:i:s'));
    }
    
    private function has_active_license() {
        $status = get_option('mac_domain_valid_status', '');
        return $status === 'activate';
    }
    
    private function should_preserve_license() {
        // Nếu có license active, chỉ reset khi chắc chắn key invalid
        if ($this->has_active_license()) {
            error_log('MAC Menu: Active license detected, being cautious about reset');
            return true;
        }
        return false;
    }
    
    private function check_crm_sync_status() {
        // Kiểm tra xem plugin có đồng bộ với CRM không
        $current_key = get_option('mac_domain_valid_key', '');
        $current_status = get_option('mac_domain_valid_status', '');
        
        if (empty($current_key) || empty($current_status)) {
            error_log('MAC Menu: No local license data found');
            return false;
        }
        
        error_log('MAC Menu: Local license - Key: ' . $current_key . ', Status: ' . $current_status);
        return true;
    }
    
    private function force_sync_with_crm() {
        // Force sync bằng cách gọi URL check
        error_log('MAC Menu: Force syncing with CRM...');
        
        // Update last sync time before force sync
        update_option('mac_domain_last_sync', time());
        error_log('MAC Menu: Last sync time updated before force sync: ' . date('Y-m-d H:i:s'));
        
        $this->handle_check_request_url();
    }

    private function reload_page() {
        ?>
        <script type="text/javascript">
            window.location.reload();
        </script>
        <?php
    }
}
