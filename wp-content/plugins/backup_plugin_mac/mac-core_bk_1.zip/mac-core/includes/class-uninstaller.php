<?php
namespace MAC_Core;

// If uninstall not called from WordPress, then exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

class Uninstaller {
    public static function uninstall() {
        // Deactivate all MAC plugins
        $plugins = get_plugins();
        foreach ($plugins as $plugin_file => $plugin_data) {
            if (strpos($plugin_file, 'mac-') === 0) {
                deactivate_plugins($plugin_file);
            }
        }

        // Clear cache
        wp_cache_flush();
    }
}