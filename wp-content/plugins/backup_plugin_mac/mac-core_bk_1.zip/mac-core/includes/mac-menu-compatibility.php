<?php
/**
 * MAC Menu Compatibility Layer
 * 
 * This file provides compatibility functions for MAC Menu plugin
 * to ensure it continues working after domain management is moved to MAC Core
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Wrapper functions for MAC Menu compatibility
if (!function_exists('kvp_enqueue_scripts')) {
    function kvp_enqueue_scripts() {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->enqueue_scripts();
        } else {
            error_log('MAC Menu: kvp_enqueue_scripts called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

if (!function_exists('kvp_handle_check_request')) {
    function kvp_handle_check_request($keyDomainCheck = null) {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->handle_check_request($keyDomainCheck);
        } else {
            error_log('MAC Menu: kvp_handle_check_request called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

if (!function_exists('kvp_handle_check_request_url')) {
    function kvp_handle_check_request_url() {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->handle_check_request_url();
        } else {
            error_log('MAC Menu: kvp_handle_check_request_url called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

if (!function_exists('kvp_handle_ajax_request')) {
    function kvp_handle_ajax_request() {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->handle_ajax_request();
        } else {
            error_log('MAC Menu: kvp_handle_ajax_request called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

// Note: Update functionality is now handled by MAC_Core\Update_Manager class

// Helper functions for add-ons to easily use Update Manager
if (!function_exists('mac_get_update_manager')) {
    function mac_get_update_manager() {
        if (class_exists('MAC_Core\Update_Manager')) {
            return MAC_Core\Update_Manager::get_instance();
        }
        return null;
    }
}

if (!function_exists('mac_check_github_token')) {
    function mac_check_github_token($addon_slug) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->check_github_token($addon_slug);
        }
        return false;
    }
}

if (!function_exists('mac_check_plugin_update')) {
    function mac_check_plugin_update($addon_slug, $github_repo) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->get_update_info($addon_slug, $github_repo);
        }
        return false;
    }
}

if (!function_exists('mac_is_update_available')) {
    function mac_is_update_available($addon_slug, $github_repo) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->is_update_available($addon_slug, $github_repo);
        }
        return false;
    }
}

if (!function_exists('mac_get_update_url')) {
    function mac_get_update_url($addon_slug) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->get_update_url($addon_slug);
        }
        return admin_url('plugins.php?update_mac=' . $addon_slug);
    }
}

// Register the old function hooks for MAC Menu compatibility
add_action('admin_enqueue_scripts', 'kvp_enqueue_scripts');
add_action('wp_ajax_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
add_action('wp_ajax_nopriv_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
