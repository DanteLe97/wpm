<?php
/**
 * Plugin Name: MAC Core
 * Plugin URI: https://mac-marketing.com
 * Description: Core plugin for managing MAC Marketing plugins, licenses, and updates
 * Version: 1.0.0
 * Author: MAC Marketing
 * Author URI: https://mac-marketing.com
 * Text Domain: mac-core
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// MAC Core is now loaded via mu-plugins to ensure it loads before other MAC plugins

// Define plugin constants
define('MAC_CORE_VERSION', '1.0.0');
define('MAC_CORE_FILE', __FILE__);
define('MAC_CORE_PATH', plugin_dir_path(__FILE__));
define('MAC_CORE_URL', plugin_dir_url(__FILE__));
define('MAC_CORE_BASENAME', plugin_basename(__FILE__));

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'MAC_Core\\';
    $base_dir = MAC_CORE_PATH . 'includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Initialize plugin
function mac_core_init() {
    // Load text domain
    load_plugin_textdomain('mac-core', false, dirname(MAC_CORE_BASENAME) . '/languages');

    // Initialize components
    if (is_admin()) {
        require_once MAC_CORE_PATH . 'admin/class-admin.php';
        new MAC_Core\Admin\Admin();
    }

    // Initialize API
    require_once MAC_CORE_PATH . 'includes/class-api.php';
    new MAC_Core\API();

    // Initialize License Manager
    require_once MAC_CORE_PATH . 'includes/class-license-manager.php';
    global $mac_core_license_manager;
    $mac_core_license_manager = new MAC_Core\License_Manager();

    // Initialize Plugin Manager
    // require_once MAC_CORE_PATH . 'includes/class-plugin-manager.php';
    // new MAC_Core\Plugin_Manager();
    
    // Load MAC Menu Domain Manager class FIRST
    require_once MAC_CORE_PATH . 'includes/class-mac-menu-domain-manager.php';
require_once MAC_CORE_PATH . 'includes/class-update-manager.php';
    
    // Initialize MAC Menu Domain Manager for compatibility
    if (class_exists('MAC_Menu_Domain_Manager')) {
        add_action('plugins_loaded', array('MAC_Menu_Domain_Manager', 'get_instance'));
    }
    
    // Load MAC Menu compatibility layer AFTER class is available
    require_once MAC_CORE_PATH . 'includes/mac-menu-compatibility.php';
    
    // Load debug helper (remove in production)
    if (defined('WP_DEBUG') && WP_DEBUG) {
        require_once MAC_CORE_PATH . 'debug-mac-menu.php';
    }
}

add_action('plugins_loaded', 'mac_core_init');

// Activation hook
register_activation_hook(__FILE__, function() {
    require_once MAC_CORE_PATH . 'includes/class-activator.php';
    MAC_Core\Activator::activate();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    require_once MAC_CORE_PATH . 'includes/class-deactivator.php';
    MAC_Core\Deactivator::deactivate();
});

// Uninstall hook
function mac_core_uninstall() {
    require_once MAC_CORE_PATH . 'includes/class-uninstaller.php';
    MAC_Core\Uninstaller::uninstall();
}
register_uninstall_hook(__FILE__, 'mac_core_uninstall');

// Add settings link to plugins page
add_filter('plugin_action_links_' . MAC_CORE_BASENAME, function($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=mac-core') . '">' . __('Settings', 'mac-core') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
});

// Add plugin row meta
add_filter('plugin_row_meta', function($links, $file) {
    if ($file === MAC_CORE_BASENAME) {
        $row_meta = array(
            'docs' => '<a href="' . esc_url('https://mac-marketing.com/docs') . '" aria-label="' . esc_attr__('View MAC Core documentation', 'mac-core') . '">' . esc_html__('Documentation', 'mac-core') . '</a>',
            'support' => '<a href="' . esc_url('https://mac-marketing.com/support') . '" aria-label="' . esc_attr__('Visit support forum', 'mac-core') . '">' . esc_html__('Support', 'mac-core') . '</a>'
        );
        return array_merge($links, $row_meta);
    }
    return $links;
}, 10, 2);