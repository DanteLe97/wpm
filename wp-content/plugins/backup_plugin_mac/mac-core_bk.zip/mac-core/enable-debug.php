<?php
/**
 * Enable WordPress Debug Log
 * 
 * Add this to your wp-config.php or include this file to enable debug logging
 */

// Enable WordPress debug logging
if (!defined('WP_DEBUG')) {
    define('WP_DEBUG', true);
}

if (!defined('WP_DEBUG_LOG')) {
    define('WP_DEBUG_LOG', true);
}

if (!defined('WP_DEBUG_DISPLAY')) {
    define('WP_DEBUG_DISPLAY', false);
}

// Optional: Set custom log file location
if (!defined('WP_DEBUG_LOG')) {
    define('WP_DEBUG_LOG', WP_CONTENT_DIR . '/debug.log');
}

// Add custom debug function for MAC Menu
if (!function_exists('mac_menu_debug_log')) {
    function mac_menu_debug_log($message, $type = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $timestamp = current_time('Y-m-d H:i:s');
            $log_message = "[{$timestamp}] MAC Menu Debug [{$type}]: {$message}" . PHP_EOL;
            error_log($log_message);
        }
    }
}

// Instructions for manual setup:
echo '<div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 20px 0; border-radius: 4px;">';
echo '<h3>🔧 Debug Setup Instructions:</h3>';
echo '<p><strong>To enable debug logging, add these lines to your wp-config.php:</strong></p>';
echo '<pre style="background: #f8f9fa; padding: 10px; border-radius: 3px;">';
echo "define('WP_DEBUG', true);\n";
echo "define('WP_DEBUG_LOG', true);\n";
echo "define('WP_DEBUG_DISPLAY', false);\n";
echo '</pre>';
echo '<p><strong>Debug log file location:</strong> ' . WP_CONTENT_DIR . '/debug.log</p>';
echo '<p><strong>After enabling debug:</strong> Go to MAC Core → Debug to test APIs</p>';
echo '</div>';
