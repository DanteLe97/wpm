<?php
namespace MAC_Core;

// MAC Menu API Constants
if (!defined('MAC_MENU_VALIDATE_KEY')) {
    define('MAC_MENU_VALIDATE_KEY', 'https://wpm.macusaone.com/api/v1/menu-license/validate-key');
}
if (!defined('MAC_MENU_VALIDATE_URL')) {
    define('MAC_MENU_VALIDATE_URL', 'https://wpm.macusaone.com/api/v1/menu-license/validate-url');
}
if (!defined('MAC_MENU_REGISTER_DOMAIN')) {
    define('MAC_MENU_REGISTER_DOMAIN', 'https://wpm.macusaone.com/api/v1/menu-license/register-domain');
}

class License_Manager {
    private $api;
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'mac_licenses';
        $this->api = new API();

        // Initialize MAC Menu options
        $this->initialize_mac_menu_options();

        // Initialize MAC Menu Domain Manager
        $this->init_mac_menu_domain();
        // Note: Hooks are now handled by compatibility layer
        // $this->init_mac_menu_domain_hooks();

        add_action('admin_init', array($this, 'check_licenses'));
        add_action('admin_notices', array($this, 'display_license_notices'));
        
        // Domain Manager hooks
        add_action('admin_enqueue_scripts', array($this, 'enqueue_domain_scripts'));
        add_action('wp_ajax_mac_core_validate_domain', array($this, 'handle_ajax_validation'));
        add_action('wp_ajax_mac_core_register_domain', array($this, 'handle_ajax_registration'));
        add_action('wp_ajax_mac_core_get_domain_status', array($this, 'handle_ajax_status'));
        add_action('wp_ajax_mac_core_check_plugin_status', array($this, 'handle_ajax_check_status'));
        add_action('wp_ajax_mac_core_add_license', array($this, 'handle_ajax_add_license'));
        add_action('wp_ajax_mac_core_activate_license', array($this, 'handle_ajax_activate_license'));
        add_action('wp_ajax_mac_core_deactivate_license', array($this, 'handle_ajax_deactivate_license'));
        add_action('wp_ajax_mac_core_delete_license', array($this, 'handle_ajax_delete_license'));
        add_action('wp_ajax_mac_core_activate_master_license', array($this, 'handle_ajax_activate_master_license'));
        add_action('wp_ajax_mac_core_deactivate_master_license', array($this, 'handle_ajax_deactivate_master_license'));
        add_action('wp_ajax_mac_core_delete_master_license', array($this, 'handle_ajax_delete_master_license'));
        add_action('wp_ajax_mac_core_force_sync_license', array($this, 'handle_ajax_force_sync_license'));
        
            // MAC Menu compatibility hooks - These are now handled by compatibility layer
    // add_action('wp_ajax_kvp_handle_ajax_request', array($this, 'mac_menu_handle_ajax_request'));
    // add_action('wp_ajax_nopriv_kvp_handle_ajax_request', array($this, 'mac_menu_handle_ajax_request'));
        
        add_action('admin_init', array($this, 'check_domain_status'));
    }

    /**
     * Initialize MAC Menu options
     * Moved from mac-menu plugin
     */
    private function initialize_mac_menu_options() {
        if (false === get_option('mac_domain_valid_key')) {
            add_option('mac_domain_valid_key', '0');
        }
        if (false === get_option('mac_domain_valid_status')) {
            add_option('mac_domain_valid_status', '0');
        }
    }

    public function check_licenses() {
        $licenses = $this->get_all_licenses();
        foreach ($licenses as $license) {
            if ($license['status'] === 'active') {
                $result = $this->api->validate_license($license['license_key'], $license['plugin_slug']);
                if (!$result['success']) {
                    $this->update_license_status($license['id'], 'invalid');
                }
            }
        }
    }

    public function display_license_notices() {
        $licenses = $this->get_all_licenses();
        foreach ($licenses as $license) {
            if ($license['status'] === 'invalid') {
                echo '<div class="error"><p>' . 
                    sprintf(__('Your license for %s is invalid. Please <a href="%s">update your license</a>.', 'mac-core'),
                        $license['plugin_name'],
                        admin_url('admin.php?page=mac-core-licenses')
                    ) . '</p></div>';
            }
        }
    }

    public function get_all_licenses() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$this->table_name}", ARRAY_A);
    }

    public function get_license($plugin_slug) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE plugin_slug = %s", $plugin_slug),
            ARRAY_A
        );
    }

    public function add_license($license_key, $plugin_slug, $plugin_name) {
        global $wpdb;

        $result = $this->api->activate_license($license_key, $plugin_slug);
        if (!$result['success']) {
            return $result;
        }

        $wpdb->insert(
            $this->table_name,
            array(
                'license_key' => $license_key,
                'plugin_slug' => $plugin_slug,
                'plugin_name' => $plugin_name,
                'status' => 'active',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );

        return array(
            'success' => true,
            'message' => __('License activated successfully.', 'mac-core')
        );
    }
    
    public function add_master_license($license_key) {
        global $wpdb;
        
        // Check if master license already exists
        $existing_master = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE plugin_slug = %s", 'master'),
            ARRAY_A
        );
        
        if ($existing_master) {
            return array(
                'success' => false,
                'message' => __('Master license already exists. Please remove the existing one first.', 'mac-core')
            );
        }
        
        // Validate master license with API
        $result = $this->api->activate_license($license_key, 'master');
        if (!$result['success']) {
            return $result;
        }
        
        // Add master license
        $wpdb->insert(
            $this->table_name,
            array(
                'license_key' => $license_key,
                'plugin_slug' => 'master',
                'plugin_name' => 'MAC Master License',
                'status' => 'active',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        // Store master license key in options for easy access
        update_option('mac_core_master_license_key', $license_key);
        update_option('mac_core_master_license_status', 'active');
        
        return array(
            'success' => true,
            'message' => __('Master license activated successfully for all MAC plugins.', 'mac-core')
        );
    }

    public function update_license($license_id, $license_key) {
        global $wpdb;

        $license = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );

        if (!$license) {
            return array(
                'success' => false,
                'message' => __('License not found.', 'mac-core')
            );
        }

        $result = $this->api->activate_license($license_key, $license['plugin_slug']);
        if (!$result['success']) {
            return $result;
        }

        $wpdb->update(
            $this->table_name,
            array(
                'license_key' => $license_key,
                'status' => 'active',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $license_id),
            array('%s', '%s', '%s'),
            array('%d')
        );

        return array(
            'success' => true,
            'message' => __('License updated successfully.', 'mac-core')
        );
    }

    public function deactivate_license($license_id) {
        global $wpdb;

        $license = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );

        if (!$license) {
            return array(
                'success' => false,
                'message' => __('License not found.', 'mac-core')
            );
        }

        $result = $this->api->deactivate_license($license['license_key'], $license['plugin_slug']);
        if (!$result['success']) {
            return $result;
        }

        $wpdb->update(
            $this->table_name,
            array(
                'status' => 'inactive',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $license_id),
            array('%s', '%s'),
            array('%d')
        );

        return array(
            'success' => true,
            'message' => __('License deactivated successfully.', 'mac-core')
        );
    }

    public function delete_license($license_id) {
        global $wpdb;

        $license = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );

        if (!$license) {
            return array(
                'success' => false,
                'message' => __('License not found.', 'mac-core')
            );
        }

        if ($license['status'] === 'active') {
            $this->api->deactivate_license($license['license_key'], $license['plugin_slug']);
        }

        $wpdb->delete(
            $this->table_name,
            array('id' => $license_id),
            array('%d')
        );

        return array(
            'success' => true,
            'message' => __('License deleted successfully.', 'mac-core')
        );
    }

    private function update_license_status($license_id, $status) {
        global $wpdb;
        $wpdb->update(
            $this->table_name,
            array(
                'status' => $status,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $license_id),
            array('%s', '%s'),
            array('%d')
        );
    }
    
    // Domain Manager Methods
    public function enqueue_scripts() {
        // This method is for MAC Menu compatibility
        // It enqueues the same scripts as enqueue_domain_scripts but for any admin page
        wp_enqueue_style(
            'mac-core-domain-manager',
            MAC_CORE_URL . 'admin/css/domain-manager.css',
            array(),
            MAC_CORE_VERSION
        );
        
        wp_enqueue_script(
            'mac-core-domain-manager',
            MAC_CORE_URL . 'admin/js/domain-manager.js',
            array('jquery'),
            MAC_CORE_VERSION,
            true
        );
        
        // MAC Menu compatibility script
        wp_enqueue_script(
            'mac-core-mac-menu-compatibility',
            MAC_CORE_URL . 'admin/js/mac-menu-compatibility.js',
            array('jquery'),
            MAC_CORE_VERSION,
            true
        );
        
        wp_localize_script('mac-core-domain-manager', 'macCoreDomain', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac_core_domain_nonce'),
            'i18n' => array(
                'validating' => __('Validating...', 'mac-core'),
                'registering' => __('Registering...', 'mac-core'),
                'loading' => __('Loading...', 'mac-core'),
                'checking' => __('Checking...', 'mac-core'),
                'error' => __('An error occurred.', 'mac-core'),
                'success' => __('Operation completed successfully.', 'mac-core')
            )
        ));
        
        // MAC Menu compatibility parameters
        wp_localize_script('mac-core-mac-menu-compatibility', 'kvp_params', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }

    public function enqueue_domain_scripts($hook) {
        if (strpos($hook, 'mac-core') === false) {
            return;
        }
        
        wp_enqueue_style(
            'mac-core-domain-manager',
            MAC_CORE_URL . 'admin/css/domain-manager.css',
            array(),
            MAC_CORE_VERSION
        );
        
        wp_enqueue_script(
            'mac-core-domain-manager',
            MAC_CORE_URL . 'admin/js/domain-manager.js',
            array('jquery'),
            MAC_CORE_VERSION,
            true
        );
        
        wp_localize_script('mac-core-domain-manager', 'macCoreDomain', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mac_core_domain_nonce'),
            'i18n' => array(
                'validating' => __('Validating...', 'mac-core'),
                'registering' => __('Registering...', 'mac-core'),
                'loading' => __('Loading...', 'mac-core'),
                'checking' => __('Checking...', 'mac-core'),
                'error' => __('An error occurred.', 'mac-core'),
                'success' => __('Operation completed successfully.', 'mac-core')
            )
        ));
    }
    
    public function validate_domain($license_key, $plugin_slug = 'mac-core') {
        $domain = get_site_url() . '/';
        $version = $this->get_plugin_version($plugin_slug);
        
        $response = $this->api->validate_domain($license_key, $domain, $version);
        
        if ($response['success']) {
            $this->update_domain_status($plugin_slug, $response['data']);
        }
        
        return $response;
    }
    
    public function register_domain($license_key, $plugin_slug = 'mac-core') {
        $domain = get_site_url() . '/';
        $version = $this->get_plugin_version($plugin_slug);
        
        $response = $this->api->register_domain($license_key, $domain, $version);
        
        if ($response['success']) {
            $this->update_domain_status($plugin_slug, $response['data']);
        }
        
        return $response;
    }
    
    public function check_domain_status() {
        $plugins = $this->get_registered_plugins();
        
        foreach ($plugins as $plugin_slug) {
            $license = $this->get_license($plugin_slug);
            if ($license && $license['status'] === 'active') {
                $this->validate_domain($license['license_key'], $plugin_slug);
            }
        }
    }
    
    private function update_domain_status($plugin_slug, $data) {
        $option_prefix = 'mac_core_domain_' . $plugin_slug;
        
        update_option($option_prefix . '_key', $data['key'] ?? '');
        update_option($option_prefix . '_status', $data['status'] ?? '');
        update_option($option_prefix . '_expires', $data['expires'] ?? '');
        update_option($option_prefix . '_last_check', current_time('mysql'));
    }
    
    private function get_plugin_version($plugin_slug) {
        // Logic để lấy version của plugin
        switch ($plugin_slug) {
            case 'mac-core':
                return MAC_CORE_VERSION;
            case 'mac-menu':
                return '1.0.0'; // Cần lấy từ plugin data
            default:
                return '1.0.0';
        }
    }
    
    private function get_registered_plugins() {
        return array('mac-core', 'mac-menu');
    }
    
    // AJAX handlers
    public function handle_ajax_validation() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_domain_nonce')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $license_key = sanitize_text_field($_POST['license_key']);
        $plugin_slug = sanitize_text_field($_POST['plugin_slug'] ?? 'mac-core');
        
        $result = $this->validate_domain($license_key, $plugin_slug);
        wp_send_json($result);
    }
    
    public function handle_ajax_registration() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_domain_nonce')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $license_key = sanitize_text_field($_POST['license_key']);
        $plugin_slug = sanitize_text_field($_POST['plugin_slug'] ?? 'mac-core');
        
        $result = $this->register_domain($license_key, $plugin_slug);
        wp_send_json($result);
    }
    
    public function handle_ajax_status() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_domain_nonce')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $html = $this->get_domain_status_html();
        wp_send_json_success(array('html' => $html));
    }
    
    private function get_domain_status_html() {
        $plugins = $this->get_registered_plugins();
        $html = '<table class="wp-list-table widefat fixed striped">';
        $html .= '<thead><tr>';
        $html .= '<th>' . __('Plugin', 'mac-core') . '</th>';
        $html .= '<th>' . __('Status', 'mac-core') . '</th>';
        $html .= '<th>' . __('Last Check', 'mac-core') . '</th>';
        $html .= '<th>' . __('Actions', 'mac-core') . '</th>';
        $html .= '</tr></thead><tbody>';
        
        foreach ($plugins as $plugin_slug) {
            $option_prefix = 'mac_core_domain_' . $plugin_slug;
            $status = get_option($option_prefix . '_status', '');
            $last_check = get_option($option_prefix . '_last_check', '');
            
            $status_class = $status === 'active' ? 'status-active' : 'status-inactive';
            $status_text = $status === 'active' ? __('Active', 'mac-core') : __('Inactive', 'mac-core');
            
            $html .= '<tr>';
            $html .= '<td>' . esc_html($plugin_slug) . '</td>';
            $html .= '<td><span class="' . $status_class . '">' . $status_text . '</span></td>';
            $html .= '<td>' . ($last_check ? date('Y-m-d H:i:s', strtotime($last_check)) : __('Never', 'mac-core')) . '</td>';
            $html .= '<td><button class="button check-status" data-plugin="' . $plugin_slug . '">' . __('Check Status', 'mac-core') . '</button></td>';
            $html .= '</tr>';
        }
        
        $html .= '</tbody></table>';
        return $html;
    }
    
    public function handle_ajax_check_status() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_domain_nonce')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $plugin_slug = sanitize_text_field($_POST['plugin_slug']);
        $license = $this->get_license($plugin_slug);
        
        if (!$license || $license['status'] !== 'active') {
            wp_send_json_error(__('No active license found for this plugin.', 'mac-core'));
        }
        
        $result = $this->validate_domain($license['license_key'], $plugin_slug);
        wp_send_json($result);
    }
    
    // License Management AJAX handlers
    public function handle_ajax_add_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $license_key = sanitize_text_field($_POST['license_key']);
        
        // Add master license for all MAC plugins
        $result = $this->add_master_license($license_key);
        wp_send_json($result);
    }
    
    public function handle_ajax_activate_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $license_id = intval($_POST['license_id']);
        $license = $this->get_license_by_id($license_id);
        
        if (!$license) {
            wp_send_json_error(__('License not found.', 'mac-core'));
        }
        
        $result = $this->api->activate_license($license['license_key'], $license['plugin_slug']);
        if ($result['success']) {
            $this->update_license_status($license_id, 'active');
            wp_send_json_success(__('License activated successfully.', 'mac-core'));
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    public function handle_ajax_deactivate_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $license_id = intval($_POST['license_id']);
        $license = $this->get_license_by_id($license_id);
        
        if (!$license) {
            wp_send_json_error(__('License not found.', 'mac-core'));
        }
        
        $result = $this->api->deactivate_license($license['license_key'], $license['plugin_slug']);
        if ($result['success']) {
            $this->update_license_status($license_id, 'inactive');
            wp_send_json_success(__('License deactivated successfully.', 'mac-core'));
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    public function handle_ajax_delete_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $license_id = intval($_POST['license_id']);
        $result = $this->delete_license($license_id);
        wp_send_json($result);
    }
    
    private function get_license_by_id($license_id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $license_id),
            ARRAY_A
        );
    }
    
    public function get_plugin_name($plugin_slug) {
        $plugin_names = array(
            'mac-core' => 'MAC Core',
            'mac-menu' => 'MAC Menu',
            'mac-other' => 'MAC Other Plugin'
        );
        
        return isset($plugin_names[$plugin_slug]) ? $plugin_names[$plugin_slug] : $plugin_slug;
    }
    
    // Master License AJAX handlers
    public function handle_ajax_activate_master_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $master_license_key = get_option('mac_core_master_license_key', '');
        if (!$master_license_key) {
            wp_send_json_error(__('No master license key found.', 'mac-core'));
        }
        
        $result = $this->api->activate_license($master_license_key, 'master');
        if ($result['success']) {
            update_option('mac_core_master_license_status', 'active');
            wp_send_json_success(__('Master license activated successfully.', 'mac-core'));
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    public function handle_ajax_deactivate_master_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        $master_license_key = get_option('mac_core_master_license_key', '');
        if (!$master_license_key) {
            wp_send_json_error(__('No master license key found.', 'mac-core'));
        }
        
        $result = $this->api->deactivate_license($master_license_key, 'master');
        if ($result['success']) {
            update_option('mac_core_master_license_status', 'inactive');
            wp_send_json_success(__('Master license deactivated successfully.', 'mac-core'));
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    public function handle_ajax_delete_master_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        global $wpdb;
        
        // Delete from database
        $wpdb->delete(
            $this->table_name,
            array('plugin_slug' => 'master'),
            array('%s')
        );
        
        // Delete options
        delete_option('mac_core_master_license_key');
        delete_option('mac_core_master_license_status');
        
        wp_send_json_success(__('Master license deleted successfully.', 'mac-core'));
    }
    
    public function handle_ajax_force_sync_license() {
        if (!wp_verify_nonce($_POST['nonce'], 'mac_core_add_license')) {
            wp_send_json_error(__('Invalid security token.', 'mac-core'));
        }
        
        // Get MAC Menu Domain Manager instance and force sync
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $domain_manager = \MAC_Menu_Domain_Manager::get_instance();
            $domain_manager->force_sync_license();
            wp_send_json_success(__('License sync completed successfully.', 'mac-core'));
        } else {
            wp_send_json_error(__('MAC Menu Domain Manager not available.', 'mac-core'));
        }
    }
    
    // MAC Menu Domain Manager Methods (Compatibility) - REMOVED DUPLICATE METHODS
    // These methods have been replaced by the new MAC Menu Domain Manager methods below
    
    /**
     * Register domain on activation
     * Moved from mac-menu plugin
     */
    public function mac_register_domain_on_activation() {
        $api_url = MAC_MENU_REGISTER_DOMAIN;
        $domain = get_site_url() . '/'; 
        $response = wp_remote_post($api_url, array(
            'method'    => 'POST',
            'body'      => array(
                'url' => $domain
            ),
            'timeout'   => 45,
        ));
        if (is_wp_error($response)) {
            error_log('Error sending domain to API: ' . $response->get_error_message());
        } else {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            if ($data['status'] == 'success') {
                error_log('Domain registered successfully.');
            } else {
                error_log('Failed to register domain: ' . $data['message']);
            }
        }
    }

    // ========================================
    // MAC Menu Domain Manager - Moved to separate class
    // ========================================



    private function init_mac_menu_domain() {
        // MAC Menu Domain Manager is now handled by separate class
        // This method is kept for compatibility but no longer needed
    }


} 