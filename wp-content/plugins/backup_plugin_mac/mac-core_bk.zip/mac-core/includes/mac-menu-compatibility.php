<?php
/**
 * MAC Menu Compatibility Layer
 * 
 * This file provides compatibility functions for MAC Menu plugin
 * to ensure it continues working after domain management is moved to MAC Core
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Wrapper functions for MAC Menu compatibility
if (!function_exists('kvp_enqueue_scripts')) {
    function kvp_enqueue_scripts() {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->enqueue_scripts();
        } else {
            error_log('MAC Menu: kvp_enqueue_scripts called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

if (!function_exists('kvp_handle_check_request')) {
    function kvp_handle_check_request($keyDomainCheck = null) {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->handle_check_request($keyDomainCheck);
        } else {
            error_log('MAC Menu: kvp_handle_check_request called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

if (!function_exists('kvp_handle_check_request_url')) {
    function kvp_handle_check_request_url() {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->handle_check_request_url();
        } else {
            error_log('MAC Menu: kvp_handle_check_request_url called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

if (!function_exists('kvp_handle_ajax_request')) {
    function kvp_handle_ajax_request() {
        if (class_exists('MAC_Menu_Domain_Manager')) {
            $manager = MAC_Menu_Domain_Manager::get_instance();
            $manager->handle_ajax_request();
        } else {
            error_log('MAC Menu: kvp_handle_ajax_request called but MAC_Menu_Domain_Manager is not available');
        }
    }
}

// Register the old function hooks for MAC Menu compatibility
add_action('admin_enqueue_scripts', 'kvp_enqueue_scripts');
add_action('wp_ajax_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
add_action('wp_ajax_nopriv_kvp_handle_ajax_request', 'kvp_handle_ajax_request');
