<?php
if (!defined('ABSPATH')) {
    exit;
}

// Classes are already loaded in mac_core_init()

global $mac_core_license_manager;
$license_manager = $mac_core_license_manager;

$licenses = $license_manager->get_all_licenses();
// $plugins = $plugin_manager->get_installed_plugins(); // Plugin Manager not implemented yet

// Ensure kvp_params is available for the form
?>
<script>
var kvp_params = {
    ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>'
};
</script>

<div class="wrap">
    <h1><?php echo esc_html__('MAC Core Dashboard', 'mac-core'); ?></h1>

    <div class="mac-core-dashboard">
        <!-- License Management Section -->
        <div class="mac-core-dashboard-section">
            <h2><?php echo esc_html__('License Management', 'mac-core'); ?></h2>
            
            <!-- Add License Form -->
            <div class="mac-core-form-container">
                <h3><?php echo esc_html__('Add Master License', 'mac-core'); ?></h3>
                <div id="kvp-container" class="key-domain-wrap">
                    <form id="kvp-form">
                        <?php wp_nonce_field('mac_core_add_license', 'mac_core_license_nonce'); ?>
                        <label for="kvp-key-input"><?php echo esc_html__('Enter your key:', 'mac-core'); ?></label>
                        <input type="text" id="kvp-key-input" name="key" value="MAC Menu" required>
                        <button type="submit"><?php echo esc_html__('Validate', 'mac-core'); ?></button>
                    </form>
                    <div id="kvp-result"></div>
                </div>
            </div>

            <!-- Existing Licenses -->
            <div class="mac-core-licenses-list">
                <h3><?php echo esc_html__('Master License Status', 'mac-core'); ?></h3>
                <?php 
                $master_license = $license_manager->get_license('master');
                $master_license_key = get_option('mac_core_master_license_key', '');
                $master_license_status = get_option('mac_core_master_license_status', '');
                ?>
                
                <?php if (!$master_license && !$master_license_key) : ?>
                    <p><?php echo esc_html__('No master license found. Add a master license above to manage all MAC plugins.', 'mac-core'); ?></p>
                <?php else : ?>
                    <div class="mac-core-master-license-info">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php echo esc_html__('License Type', 'mac-core'); ?></th>
                                    <th><?php echo esc_html__('License Key', 'mac-core'); ?></th>
                                    <th><?php echo esc_html__('Status', 'mac-core'); ?></th>
                                    <th><?php echo esc_html__('Domain Status', 'mac-core'); ?></th>
                                    <th><?php echo esc_html__('Actions', 'mac-core'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong><?php echo esc_html__('MAC Master License', 'mac-core'); ?></strong></td>
                                    <td>
                                        <code><?php echo esc_html(substr($master_license_key, 0, 8) . '...'); ?></code>
                                    </td>
                                    <td>
                                        <span class="mac-core-status mac-core-status-<?php echo esc_attr($master_license_status ?: 'inactive'); ?>">
                                            <?php echo esc_html(ucfirst($master_license_status ?: 'inactive')); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                        $domain_status = get_option('mac_core_domain_master_status', '');
                                        $domain_status_text = $domain_status === 'active' ? __('Active', 'mac-core') : __('Inactive', 'mac-core');
                                        $domain_status_class = $domain_status === 'active' ? 'status-active' : 'status-inactive';
                                        ?>
                                        <span class="<?php echo esc_attr($domain_status_class); ?>">
                                            <?php echo esc_html($domain_status_text); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="button check-domain-status" data-plugin="master">
                                            <?php echo esc_html__('Check Domain', 'mac-core'); ?>
                                        </button>
                                        <button class="button force-sync-license">
                                            <?php echo esc_html__('Force Sync', 'mac-core'); ?>
                                        </button>
                                        <?php if ($master_license_status === 'active') : ?>
                                            <button class="button deactivate-master-license">
                                                <?php echo esc_html__('Deactivate', 'mac-core'); ?>
                                            </button>
                                        <?php else : ?>
                                            <button class="button activate-master-license">
                                                <?php echo esc_html__('Activate', 'mac-core'); ?>
                                            </button>
                                        <?php endif; ?>
                                        <button class="button delete-master-license">
                                            <?php echo esc_html__('Delete', 'mac-core'); ?>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <!-- Plugin Status Summary -->
                        <div class="mac-core-plugin-summary">
                            <h4><?php echo esc_html__('Plugin Status Summary', 'mac-core'); ?></h4>
                            <div class="mac-core-plugin-grid">
                                <?php
                                $plugins = array('mac-core', 'mac-menu');
                                foreach ($plugins as $plugin_slug) :
                                    $plugin_name = $license_manager->get_plugin_name($plugin_slug);
                                    $plugin_status = $master_license_status === 'active' ? 'active' : 'inactive';
                                ?>
                                <div class="mac-core-plugin-item">
                                    <span class="plugin-name"><?php echo esc_html($plugin_name); ?></span>
                                    <span class="mac-core-status mac-core-status-<?php echo esc_attr($plugin_status); ?>">
                                        <?php echo esc_html(ucfirst($plugin_status)); ?>
                                    </span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Plugin Management Section -->
        <div class="mac-core-dashboard-section">
            <h2><?php echo esc_html__('Plugin Management', 'mac-core'); ?></h2>
            <?php if (empty($plugins)) : ?>
                <p><?php echo esc_html__('No MAC plugins installed.', 'mac-core'); ?></p>
            <?php else : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Plugin', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('Version', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('License Status', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('Actions', 'mac-core'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($plugins as $plugin) : ?>
                            <tr>
                                <td><?php echo esc_html($plugin['name']); ?></td>
                                <td><?php echo esc_html($plugin['version']); ?></td>
                                <td>
                                    <?php
                                    $license = $license_manager->get_license($plugin['slug']);
                                    if ($license && $license['status'] === 'active') {
                                        echo '<span class="mac-core-status mac-core-status-active">' . esc_html__('Active', 'mac-core') . '</span>';
                                    } else {
                                        echo '<span class="mac-core-status mac-core-status-inactive">' . esc_html__('Inactive', 'mac-core') . '</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <button class="button update-plugin" data-plugin="<?php echo esc_attr($plugin['slug']); ?>">
                                        <?php echo esc_html__('Update', 'mac-core'); ?>
                                    </button>
                                    <button class="button uninstall-plugin" data-plugin="<?php echo esc_attr($plugin['slug']); ?>">
                                        <?php echo esc_html__('Uninstall', 'mac-core'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Quick Actions -->
        <div class="mac-core-dashboard-section">
            <h2><?php echo esc_html__('Quick Actions', 'mac-core'); ?></h2>
            <div class="mac-core-quick-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-domain-manager')); ?>" class="button button-primary">
                    <?php echo esc_html__('Domain Manager', 'mac-core'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-settings')); ?>" class="button button-secondary">
                    <?php echo esc_html__('Settings', 'mac-core'); ?>
                </a>
                <button class="button check-all-licenses">
                    <?php echo esc_html__('Check All Licenses', 'mac-core'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.mac-core-dashboard {
    margin-top: 20px;
}

/* kvp-form styles from MAC Menu */
.key-domain-wrap form label {
    display: block;
    margin-bottom: 10px;
}

.key-domain-wrap form button {
    margin-top: 15px;
    display: block;
    background-color: #0073aa !important;
    color: #fff;
    border: none !important;
    padding: 7px 25px !important;
    border-radius: 5px;
    font-weight: 400;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    cursor: pointer;
}

.key-domain-wrap form input[type="text"] {
    width: 100%;
    max-width: 400px;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

#kvp-result {
    margin-top: 10px;
    font-weight: bold;
}

.mac-core-dashboard-section {
    background: #fff;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.mac-core-form-container {
    background: #f9f9f9;
    padding: 15px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.mac-core-form-container h3 {
    margin-top: 0;
    color: #23282d;
}

.mac-core-status {
    padding: 4px 8px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 12px;
}

.mac-core-status-active {
    background: #d4edda;
    color: #155724;
}

.mac-core-status-inactive {
    background: #f8d7da;
    color: #721c24;
}

.mac-core-status-invalid {
    background: #fff3cd;
    color: #856404;
}

.status-active {
    color: #46b450;
    font-weight: bold;
    background: #f7fcf7;
    padding: 4px 8px;
    border-radius: 4px;
    border: 1px solid #46b450;
}

.status-inactive {
    color: #dc3232;
    font-weight: bold;
    background: #fdf7f7;
    padding: 4px 8px;
    border-radius: 4px;
    border: 1px solid #dc3232;
}

.mac-core-quick-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.mac-core-quick-actions .button {
    margin: 0;
}

.mac-core-plugin-summary {
    margin-top: 20px;
    padding: 15px;
    background: #f9f9f9;
    border-radius: 4px;
}

.mac-core-plugin-summary h4 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #23282d;
}

.mac-core-plugin-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
}

.mac-core-plugin-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.mac-core-plugin-item .plugin-name {
    font-weight: 500;
}

.mac-core-master-license-info {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 15px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Add License Form - Using kvp-form from MAC Menu
    $('#kvp-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $button = $form.find('button[type="submit"]');
        var $result = $('#kvp-result');
        var originalButtonText = $button.text();
        
        if ($('#kvp-key-input').val() != '' && $('#kvp-key-input').val() != 'MAC Menu') {
            var key = $('#kvp-key-input').val();
            
            // Show loading state
            $button.prop('disabled', true).text('Validating...');
            $result.html('<div style="color: blue; font-weight: bold;">🔄 Đang gửi request...</div>');
            
            console.log('🔍 Debug: Sending AJAX request');
            console.log('📤 Request data:', {
                action: 'kvp_handle_ajax_request',
                key: key,
                nonce: $('#mac_core_license_nonce').val()
            });
            
            $.ajax({
                url: kvp_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'kvp_handle_ajax_request',
                    key: key,
                    nonce: $('#mac_core_license_nonce').val()
                },
                beforeSend: function() {
                    console.log('🚀 AJAX request started');
                },
                success: function(response) {
                    console.log('✅ AJAX response received:', response);
                    $result.append('<div style="color: green; margin-top: 10px;">📥 Response: ' + JSON.stringify(response, null, 2) + '</div>');
                    
                    if (response.success) {
                        $result.append('<div style="color: green; font-weight: bold; margin-top: 10px;">✅ Success: ' + response.data + '</div>');
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        $result.append('<div style="color: red; font-weight: bold; margin-top: 10px;">❌ Error: ' + response.data + '</div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.log('❌ AJAX error:', {xhr: xhr, status: status, error: error});
                    $result.append('<div style="color: red; font-weight: bold; margin-top: 10px;">❌ AJAX Error: ' + status + ' - ' + error + '</div>');
                    $result.append('<div style="color: orange; margin-top: 5px;">📋 Response Text: ' + xhr.responseText + '</div>');
                },
                complete: function() {
                    console.log('🏁 AJAX request completed');
                    $button.prop('disabled', false).text(originalButtonText);
                }
            });
        } else {
            $result.html('<div style="color: orange;">⚠️ Vui lòng nhập key hợp lệ</div>');
        }
    });
    
    // Check Domain Status
    $('.check-domain-status').on('click', function() {
        var $button = $(this);
        var pluginSlug = $button.data('plugin');
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Checking...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_check_plugin_status',
                nonce: $('#mac_core_license_nonce').val(),
                plugin_slug: pluginSlug
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Activate License
    $('.activate-license').on('click', function() {
        if (!confirm('Are you sure you want to activate this license?')) {
            return;
        }
        
        var $button = $(this);
        var licenseId = $button.data('id');
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Activating...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_activate_license',
                nonce: $('#mac_core_license_nonce').val(),
                license_id: licenseId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Deactivate License
    $('.deactivate-license').on('click', function() {
        if (!confirm('Are you sure you want to deactivate this license?')) {
            return;
        }
        
        var $button = $(this);
        var licenseId = $button.data('id');
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Deactivating...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_deactivate_license',
                nonce: $('#mac_core_license_nonce').val(),
                license_id: licenseId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Delete License
    $('.delete-license').on('click', function() {
        if (!confirm('Are you sure you want to delete this license? This action cannot be undone.')) {
            return;
        }
        
        var $button = $(this);
        var licenseId = $button.data('id');
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Deleting...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_delete_license',
                nonce: $('#mac_core_license_nonce').val(),
                license_id: licenseId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Master License handlers
    $('.activate-master-license').on('click', function() {
        if (!confirm('Are you sure you want to activate the master license?')) {
            return;
        }
        
        var $button = $(this);
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Activating...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_activate_master_license',
                nonce: $('#mac_core_license_nonce').val()
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    $('.deactivate-master-license').on('click', function() {
        if (!confirm('Are you sure you want to deactivate the master license?')) {
            return;
        }
        
        var $button = $(this);
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Deactivating...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_deactivate_master_license',
                nonce: $('#mac_core_license_nonce').val()
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    $('.delete-master-license').on('click', function() {
        if (!confirm('Are you sure you want to delete the master license? This action cannot be undone.')) {
            return;
        }
        
        var $button = $(this);
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Deleting...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_delete_master_license',
                nonce: $('#mac_core_license_nonce').val()
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Force Sync License
    $('.force-sync-license').on('click', function() {
        if (!confirm('Force sync will check CRM status and update local license data. Continue?')) {
            return;
        }
        
        var $button = $(this);
        var originalText = $button.text();
        
        $button.prop('disabled', true).text('Syncing...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mac_core_force_sync_license',
                nonce: $('#mac_core_license_nonce').val()
            },
            success: function(response) {
                if (response.success) {
                    alert('Sync completed successfully!');
                    location.reload();
                } else {
                    alert('Sync failed: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred during sync. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text(originalText);
            }
        });
    });
});
</script>