<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

$api_url = get_option('mac_core_api_url', 'https://api.mac-marketing.com');
$api_key = get_option('mac_core_api_key', '');
$debug_mode = get_option('mac_core_debug_mode', '0');
?>

<div class="wrap">
    <h1><?php echo esc_html__('MAC Core Settings', 'mac-core'); ?></h1>

    <?php settings_errors(); ?>

    <form method="post" action="options.php">
        <?php settings_fields('mac_core_settings'); ?>
        <?php do_settings_sections('mac_core_settings'); ?>

        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="mac_core_api_url"><?php echo esc_html__('API URL', 'mac-core'); ?></label>
                </th>
                <td>
                    <input type="url" id="mac_core_api_url" name="mac_core_api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text">
                    <p class="description"><?php echo esc_html__('The URL of the MAC Marketing API.', 'mac-core'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mac_core_api_key"><?php echo esc_html__('API Key', 'mac-core'); ?></label>
                </th>
                <td>
                    <input type="text" id="mac_core_api_key" name="mac_core_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
                    <p class="description"><?php echo esc_html__('Your MAC Marketing API key.', 'mac-core'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="mac_core_debug_mode"><?php echo esc_html__('Debug Mode', 'mac-core'); ?></label>
                </th>
                <td>
                    <label>
                        <input type="checkbox" id="mac_core_debug_mode" name="mac_core_debug_mode" value="1" <?php checked($debug_mode, '1'); ?>>
                        <?php echo esc_html__('Enable debug mode', 'mac-core'); ?>
                    </label>
                    <p class="description"><?php echo esc_html__('Enable this to show detailed error messages.', 'mac-core'); ?></p>
                </td>
            </tr>
        </table>

        <?php submit_button(); ?>
    </form>

    <div class="mac-core-system-info">
        <h2><?php echo esc_html__('System Information', 'mac-core'); ?></h2>
        <table class="widefat">
            <tbody>
                <tr>
                    <td><strong><?php echo esc_html__('WordPress Version', 'mac-core'); ?></strong></td>
                    <td><?php echo esc_html(get_bloginfo('version')); ?></td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('PHP Version', 'mac-core'); ?></strong></td>
                    <td><?php echo esc_html(PHP_VERSION); ?></td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('MySQL Version', 'mac-core'); ?></strong></td>
                    <td><?php echo esc_html($wpdb->get_var('SELECT VERSION()')); ?></td>
                </tr>
                <tr>
                    <td><strong><?php echo esc_html__('MAC Core Version', 'mac-core'); ?></strong></td>
                    <td><?php echo esc_html(MAC_CORE_VERSION); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div> 