<?php
if (!defined('ABSPATH')) {
    exit;
}

// Classes are already loaded in mac_core_init()

// $plugin_manager = new MAC_Core\Plugin_Manager(); // Plugin Manager not implemented yet
global $mac_core_license_manager;
$license_manager = $mac_core_license_manager;

// $plugins = $plugin_manager->get_installed_plugins(); // Plugin Manager not implemented yet
$plugins = array(); // Temporary empty array until Plugin Manager is implemented
$action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
$plugin_slug = isset($_GET['plugin']) ? sanitize_text_field($_GET['plugin']) : '';

if ($action && $plugin_slug) {
    // Plugin Manager actions are temporarily disabled
    add_settings_error('mac_core', 'plugin_manager_disabled', __('Plugin Manager is not implemented yet.', 'mac-core'), 'warning');
    
    /*
    switch ($action) {
        case 'update':
            $result = $plugin_manager->update_plugin($plugin_slug, 'latest');
            if ($result['success']) {
                add_settings_error('mac_core', 'plugin_updated', $result['message'], 'success');
            } else {
                add_settings_error('mac_core', 'plugin_update_failed', $result['message'], 'error');
            }
            break;

        case 'activate':
            $result = $plugin_manager->activate_plugin($plugin_slug);
            if ($result['success']) {
                add_settings_error('mac_core', 'plugin_activated', $result['message'], 'success');
            } else {
                add_settings_error('mac_core', 'plugin_activate_failed', $result['message'], 'error');
            }
            break;

        case 'uninstall':
            $result = $plugin_manager->uninstall_plugin($plugin_slug);
            if ($result['success']) {
                add_settings_error('mac_core', 'plugin_uninstalled', $result['message'], 'success');
            } else {
                add_settings_error('mac_core', 'plugin_uninstall_failed', $result['message'], 'error');
            }
            break;
    }
    */
}
?>

<div class="wrap">
    <h1><?php echo esc_html__('Manage Plugins', 'mac-core'); ?></h1>

    <?php settings_errors('mac_core'); ?>

    <div class="mac-core-plugins-wrap">
        <div class="mac-core-plugins-section">
            <h2><?php echo esc_html__('Installed Plugins', 'mac-core'); ?></h2>
            <?php if (empty($plugins)) : ?>
                <p><?php echo esc_html__('No MAC plugins installed.', 'mac-core'); ?></p>
            <?php else : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Plugin', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('Version', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('License', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('Status', 'mac-core'); ?></th>
                            <th><?php echo esc_html__('Actions', 'mac-core'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($plugins as $plugin) : ?>
                            <?php
                            $license = $license_manager->get_license($plugin['slug']);
                            $has_valid_license = $license && $license['status'] === 'active';
                            $is_plugin_active = is_plugin_active($plugin['file']);
                            ?>
                            <tr>
                                <td><?php echo esc_html($plugin['name']); ?></td>
                                <td><?php echo esc_html($plugin['version']); ?></td>
                                <td>
                                    <?php if ($license) : ?>
                                        <span class="mac-core-license-key"><?php echo esc_html($license['license_key']); ?></span>
                                    <?php else : ?>
                                        <span class="mac-core-no-license"><?php echo esc_html__('No license', 'mac-core'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($is_plugin_active) : ?>
                                        <span class="mac-core-status mac-core-status-active"><?php echo esc_html__('Active', 'mac-core'); ?></span>
                                    <?php else : ?>
                                        <span class="mac-core-status mac-core-status-inactive"><?php echo esc_html__('Inactive', 'mac-core'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($has_valid_license) : ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-plugins&action=update&plugin=' . $plugin['slug'])); ?>" class="button">
                                            <?php echo esc_html__('Update', 'mac-core'); ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($is_plugin_active) : ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-plugins&action=uninstall&plugin=' . $plugin['slug'])); ?>" class="button" 
                                            onclick="return confirm('<?php echo esc_js(__('Are you sure you want to deactivate this plugin?', 'mac-core')); ?>');">
                                            <?php echo esc_html__('Deactivate', 'mac-core'); ?>
                                        </a>
                                    <?php else : ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-plugins&action=activate&plugin=' . $plugin['slug'])); ?>" class="button button-primary">
                                            <?php echo esc_html__('Activate', 'mac-core'); ?>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="mac-core-plugins-section">
            <h2><?php echo esc_html__('Available Plugins', 'mac-core'); ?></h2>
            <div class="mac-core-plugin-cards">
                <div class="mac-core-plugin-card">
                    <h3><?php echo esc_html__('MAC Menu', 'mac-core'); ?></h3>
                    <p><?php echo esc_html__('Create beautiful menu tables for your restaurant website.', 'mac-core'); ?></p>
                    <div class="mac-core-plugin-actions">
                        <?php
                        $is_installed = false;
                        foreach ($plugins as $plugin) {
                            if ($plugin['slug'] === 'mac-menu') {
                                $is_installed = true;
                                break;
                            }
                        }
                        if ($is_installed) :
                        ?>
                            <span class="mac-core-status mac-core-status-installed"><?php echo esc_html__('Installed', 'mac-core'); ?></span>
                        <?php else : ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-plugins&action=install&plugin=mac-menu')); ?>" class="button button-primary">
                                <?php echo esc_html__('Install Now', 'mac-core'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mac-core-plugin-card">
                    <h3><?php echo esc_html__('MAC Reservation', 'mac-core'); ?></h3>
                    <p><?php echo esc_html__('Manage restaurant reservations and table bookings.', 'mac-core'); ?></p>
                    <div class="mac-core-plugin-actions">
                        <?php
                        $is_installed = false;
                        foreach ($plugins as $plugin) {
                            if ($plugin['slug'] === 'mac-reservation') {
                                $is_installed = true;
                                break;
                            }
                        }
                        if ($is_installed) :
                        ?>
                            <span class="mac-core-status mac-core-status-installed"><?php echo esc_html__('Installed', 'mac-core'); ?></span>
                        <?php else : ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=mac-core-plugins&action=install&plugin=mac-reservation')); ?>" class="button button-primary">
                                <?php echo esc_html__('Install Now', 'mac-core'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 