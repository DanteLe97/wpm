<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Domain Manager', 'mac-core'); ?></h1>
    
    <div class="mac-core-domain-manager">
        <div class="mac-core-tabs">
            <button class="tab-button active" data-tab="validate"><?php _e('Validate Domain', 'mac-core'); ?></button>
            <button class="tab-button" data-tab="register"><?php _e('Register Domain', 'mac-core'); ?></button>
            <button class="tab-button" data-tab="status"><?php _e('Domain Status', 'mac-core'); ?></button>
        </div>
        
        <div class="tab-content active" id="validate-tab">
            <div class="mac-core-form-container">
                <h2><?php _e('Validate Domain License', 'mac-core'); ?></h2>
                <p><?php _e('Enter your license key to validate your domain for the selected plugin.', 'mac-core'); ?></p>
                
                <form id="mac-core-validate-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Plugin', 'mac-core'); ?></th>
                            <td>
                                <select name="plugin_slug" id="validate-plugin">
                                    <option value="mac-core">MAC Core</option>
                                    <option value="mac-menu">MAC Menu</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('License Key', 'mac-core'); ?></th>
                            <td>
                                <input type="text" name="license_key" id="validate-key" class="regular-text" required>
                                <p class="description"><?php _e('Enter your license key for the selected plugin.', 'mac-core'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" class="button button-primary"><?php _e('Validate Domain', 'mac-core'); ?></button>
                    </p>
                </form>
            </div>
        </div>
        
        <div class="tab-content" id="register-tab">
            <div class="mac-core-form-container">
                <h2><?php _e('Register Domain', 'mac-core'); ?></h2>
                <p><?php _e('Register your domain with a license key for the selected plugin.', 'mac-core'); ?></p>
                
                <form id="mac-core-register-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Plugin', 'mac-core'); ?></th>
                            <td>
                                <select name="plugin_slug" id="register-plugin">
                                    <option value="mac-core">MAC Core</option>
                                    <option value="mac-menu">MAC Menu</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('License Key', 'mac-core'); ?></th>
                            <td>
                                <input type="text" name="license_key" id="register-key" class="regular-text" required>
                                <p class="description"><?php _e('Enter your license key for the selected plugin.', 'mac-core'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" class="button button-primary"><?php _e('Register Domain', 'mac-core'); ?></button>
                    </p>
                </form>
            </div>
        </div>
        
        <div class="tab-content" id="status-tab">
            <div class="mac-core-status-container">
                <h2><?php _e('Domain Status', 'mac-core'); ?></h2>
                <p><?php _e('Current status of all registered domains and plugins.', 'mac-core'); ?></p>
                
                <div id="mac-core-domain-status">
                    <p><?php _e('Loading status...', 'mac-core'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CSS được load từ file external --> 