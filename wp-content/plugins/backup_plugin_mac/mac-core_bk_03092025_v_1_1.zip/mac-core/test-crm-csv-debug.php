<?php
// Test CRM CSV API with detailed debugging
require_once('wp-config.php');

function test_crm_csv_api() {
    echo "=== TESTING CRM CSV API ===\n";
    echo "Time: " . date('Y-m-d H:i:s') . "\n\n";
    
    // Check if CRM connection is active
    if (!class_exists('MAC_Core\CRM_API_Manager')) {
        echo "❌ Error: CRM_API_Manager class not found\n";
        return;
    }
    
    $crm = MAC_Core\CRM_API_Manager::get_instance();
    if (!$crm->is_license_valid()) {
        echo "❌ Error: CRM connection not active\n";
        return;
    }
    
    echo "✓ CRM connection is active\n";
    
    // Test with sample CSV
    $csv_file = 'wp-content/plugins/mac-core/sample-menu.csv';
    if (!file_exists($csv_file)) {
        echo "❌ Error: Sample CSV file not found\n";
        return;
    }
    
    echo "✓ Using CSV file: $csv_file\n";
    echo "✓ CSV file size: " . filesize($csv_file) . " bytes\n";
    
    // Read first few lines of CSV to verify content
    echo "\n=== CSV CONTENT PREVIEW ===\n";
    $handle = fopen($csv_file, 'r');
    if ($handle) {
        $line_count = 0;
        while (($line = fgets($handle)) !== false && $line_count < 5) {
            echo "Line " . ($line_count + 1) . ": " . trim($line) . "\n";
            $line_count++;
        }
        fclose($handle);
    }
    
    echo "\n=== TESTING CRM UPLOAD ===\n";
    
    // Test the upload
    $result = $crm->upload_csv_to_crm($csv_file, 'replace');
    
    echo "\n=== RESULT ===\n";
    echo "Success: " . ($result['success'] ? 'YES' : 'NO') . "\n";
    if (!$result['success']) {
        echo "Error: " . $result['message'] . "\n";
    } else {
        echo "Data structure: " . print_r(array_keys($result['data']), true) . "\n";
        if (isset($result['data']['categories'])) {
            echo "Categories count: " . count($result['data']['categories']) . "\n";
            if (count($result['data']['categories']) > 0) {
                echo "First category: " . print_r($result['data']['categories'][0], true) . "\n";
            }
        }
        if (isset($result['data']['summary'])) {
            echo "Summary: " . print_r($result['data']['summary'], true) . "\n";
        }
        if (isset($result['data']['shop_info'])) {
            echo "Shop info: " . print_r($result['data']['shop_info'], true) . "\n";
        }
    }
    
    echo "\n=== TEST COMPLETED ===\n";
}

// Run test
test_crm_csv_api();
?>
