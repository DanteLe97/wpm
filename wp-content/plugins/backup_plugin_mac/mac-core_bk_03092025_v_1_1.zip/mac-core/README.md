# MAC Core Plugin Installer

## Tổng quan

MAC Core Plugin Installer cho phép bạn tự động download và cài đặt các plugin MAC từ GitHub repositories với authentication token.

## Tính năng

- ✅ Tự động download plugin từ GitHub repository (file-by-file)
- ✅ Cài đặt plugin trực tiếp từ downloaded files
- ✅ Tự động kích hoạt plugin sau khi cài đặt
- ✅ Kiểm tra GitHub token validity
- ✅ Progress indicator và error handling
- ✅ Security với nonce verification
- ✅ Retry mechanism cho GitHub API calls

## Cách sử dụng

### 1. Thiết lập License và Domain

1. Đảm bảo bạn đã nhập license key và domain đã được validate
2. GitHub token sẽ được tự động lưu từ CRM khi validate license

### 2. Cài đặt Plugin

1. Vào **MAC Core > Add-ons**
2. Tìm plugin bạn muốn cài đặt
3. Click "Install Now"
4. Hệ thống sẽ tự động:
   - Kiểm tra GitHub token
   - Download plugin từ GitHub
   - Cài đặt plugin
   - Kích hoạt plugin
   - Reload trang

## Cấu trúc Repository

Plugin GitHub repository cần có cấu trúc như sau:

```
repository/
├── plugin-name/
│   ├── plugin-name.php
│   ├── includes/
│   ├── admin/
│   └── ...
├── version.json (optional)
└── README.md
```

## Troubleshooting

### Lỗi "GitHub token not found"
- Kiểm tra license key đã được nhập và validate
- Đảm bảo domain đã được validate với CRM
- Token sẽ được tự động lưu từ CRM khi validate thành công

### Lỗi "Failed to download plugin"
- Kiểm tra repository có tồn tại không
- Đảm bảo repository có thư mục plugin chính
- Kiểm tra token có quyền truy cập repository
- Kiểm tra cấu trúc repository có đúng format không

### Lỗi "Installation failed"
- Kiểm tra quyền ghi trong thư mục wp-content/plugins
- Kiểm tra quyền ghi trong thư mục wp-content (cho temp files)
- Kiểm tra PHP version (cần 7.0+)
- Kiểm tra PHP memory limit
- Kiểm tra max execution time
- Kiểm tra cURL extension có sẵn
- Kiểm tra error logs trong wp-content/debug.log
- Kiểm tra console logs trong browser developer tools

## API Endpoints

### GitHub API
- `GET /repos/{owner}/{repo}/contents/{path}` - Lấy danh sách files và thư mục
- `GET /repos/{owner}/{repo}/contents/{path}` - Download file content (base64 encoded)

### WordPress AJAX
- `mac_core_install_plugin` - Cài đặt plugin
- `mac_core_check_install_status` - Kiểm tra trạng thái cài đặt
- `mac_core_check_system_requirements` - Kiểm tra system requirements

## Security

- Tất cả AJAX requests đều có nonce verification
- GitHub token được lưu tự động từ CRM khi validate license
- Chỉ admin có quyền cài đặt plugin
- File permissions được kiểm tra trước khi cài đặt

## Hỗ trợ

Nếu gặp vấn đề, vui lòng:
1. Kiểm tra error logs
2. Kiểm tra license key và domain validation
3. Kiểm tra file permissions
4. Liên hệ support team
