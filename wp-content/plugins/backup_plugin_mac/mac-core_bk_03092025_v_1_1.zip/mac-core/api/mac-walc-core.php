<?php
/**
 * MacAPI Core Plugin - Xử lý auto-login độc lập cho API, không trùng với add-on/auto-login.php
 */
if (!defined('ABSPATH')) exit;

class MacAPI_Auto_Login {
    public function __construct() {
        add_action('init', [$this, 'macapi_auto_login_handler']);
        add_action('init', [$this, 'macapi_crm_login_handler']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }

    // CRM API endpoint: ?macapi_crm_login=1&auth_key=xxx&user=xxx
    public function macapi_crm_login_handler() {
        if (!isset($_GET['macapi_crm_login']) || $_GET['macapi_crm_login'] != 1) {
            return;
        }

        $auth_key = $_GET['auth_key'] ?? '';
        $user_login = sanitize_user($_GET['user'] ?? '');
        $shared_secret = get_option('mac_domain_valid_key', ''); // Lấy key từ CRM đã đăng ký

        header('Content-Type: application/json');

        if (empty($shared_secret)) {
            wp_send_json_error(['message' => 'CRM key chưa được đăng ký.'], 403);
        }

        if ($auth_key !== $shared_secret) {
            wp_send_json_error(['message' => 'Auth key không hợp lệ.'], 403);
        }

        if (empty($user_login)) {
            wp_send_json_error(['message' => 'Thiếu user.'], 400);
        }

        // Tìm user theo user_login
        $user = get_user_by('login', $user_login);
        if (!$user) {
            wp_send_json_error(['message' => 'Không tìm thấy user.'], 404);
        }

        // Xóa token cũ trước khi tạo token mới
        delete_user_meta($user->ID, 'macapi_token');

        // Tạo token mới (không có thời gian hết hạn)
        $token = wp_generate_password(32, false, false);
        update_user_meta($user->ID, 'macapi_token', $token);

        // Trả về JSON response
        wp_send_json_success([
            'login_url'   => site_url('?macapi_token=' . $token),
            'username'    => $user->user_login,
            'role'        => implode(',', $user->roles)
        ]);
    }

    // Thêm admin menu
    public function add_admin_menu() {
        add_submenu_page(
            'mac-core', // Parent slug
            'Auto Login Manager', // Page title
            'Auto Login', // Menu title
            'manage_options', // Capability
            'mac-auto-login', // Menu slug
            [$this, 'admin_page'] // Callback
        );
    }

    // Admin page content
    public function admin_page() {
        if (isset($_POST['create_link']) && isset($_POST['user_id']) && isset($_POST['days'])) {
            $user_id = intval($_POST['user_id']);
            $days = intval($_POST['days']);
            $login_url = $this->macapi_generate_auto_login_link($user_id, $days);
            echo '<div class="notice notice-success"><p>Auto-login link đã được tạo!</p></div>';
        }
        
        $users = get_users(['role__in' => ['administrator', 'editor']]);
        $crm_key = get_option('mac_domain_valid_key', '');
        ?>
        <div class="wrap">
            <h1>Auto Login Manager</h1>
            
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th><label for="user_id">Chọn User:</label></th>
                        <td>
                            <select name="user_id" id="user_id" required>
                                <option value="">-- Chọn User --</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user->ID; ?>">
                                        <?php echo esc_html($user->user_login) . ' (' . esc_html($user->user_email) . ')'; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="days">Thời gian hiệu lực:</label></th>
                        <td>
                            <select name="days" id="days" required>
                                <option value="1">1 ngày</option>
                                <option value="3" selected>3 ngày</option>
                                <option value="7">7 ngày</option>
                                <option value="30">30 ngày</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Tạo Auto-Login Link', 'primary', 'create_link'); ?>
            </form>

            <?php if (isset($login_url)): ?>
                <div class="card" style="max-width: 600px; margin-top: 20px;">
                    <h2>Auto-Login Link</h2>
                    <p><strong>Link:</strong></p>
                    <input type="text" readonly value="<?php echo esc_url($login_url); ?>" style="width: 100%; font-size: 14px; padding: 8px;">
                    <p><small>Copy link này và gửi cho user. Link sẽ hết hạn sau <?php echo $days; ?> ngày.</small></p>
                </div>
            <?php endif; ?>

            <div class="card" style="max-width: 600px; margin-top: 20px;">
                <h2>CRM API Endpoint</h2>
                <?php if (!empty($crm_key)): ?>
                    <p><strong>URL:</strong></p>
                    <input type="text" readonly value="<?php echo site_url('?macapi_crm_login=1&auth_key=' . $crm_key . '&user=USERNAME'); ?>" style="width: 100%; font-size: 14px; padding: 8px;">
                    <p><small>Thay USERNAME bằng tên đăng nhập thực tế. Auth key: <code><?php echo esc_html($crm_key); ?></code></small></p>
                    <p><strong>⚠️ Lưu ý:</strong> Khi gọi API này, user sẽ được tự động đăng nhập và redirect vào admin dashboard!</p>
                <?php else: ?>
                    <p><strong>⚠️ CRM key chưa được đăng ký!</strong></p>
                    <p>Vui lòng đăng ký domain với CRM trước để sử dụng API endpoint này.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    // Xử lý auto-login qua token riêng
    public function macapi_auto_login_handler() {
        if (!isset($_GET['macapi_token'])) {
            return;
        }
        
        $token = sanitize_text_field($_GET['macapi_token']);
        
        $users = get_users([
            'meta_key'   => 'macapi_token',
            'meta_value' => $token,
            'number'     => 1,
            'fields'     => 'all',
        ]);
        
        if (empty($users)) {
            wp_die('Token không hợp lệ.');
        }
        
        $user = $users[0];
        
        // Đăng nhập
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        
        // DEBUG: Kiểm tra headers đã gửi chưa
        if (!headers_sent()) {
            wp_redirect(admin_url());
            exit;
        } else {
            echo '<script>window.location="' . admin_url() . '";</script>';
            exit;
        }
    }

    // Tạo link auto-login riêng
    public function macapi_generate_auto_login_link($user_id, $days = 3) {
        $token = wp_generate_password(32, false, false);
        $expires = time() + $days * DAY_IN_SECONDS;
        update_user_meta($user_id, 'macapi_token', $token);
        update_user_meta($user_id, 'macapi_expires', $expires);
        return site_url('?macapi_token=' . $token);
    }
}
new MacAPI_Auto_Login();
