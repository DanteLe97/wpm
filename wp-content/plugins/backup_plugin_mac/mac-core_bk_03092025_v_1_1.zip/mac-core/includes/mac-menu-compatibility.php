<?php
/**
 * MAC Menu Compatibility Layer
 * 
 * This file provides compatibility functions for MAC Menu plugin
 * to ensure it continues working after domain management is moved to MAC Core
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Wrapper functions for MAC Menu compatibility
// Only define these functions if MAC Menu is not installed to avoid conflicts
//if (!file_exists(WP_PLUGIN_DIR . '/mac-menu/mac-menu.php')) {
    if (!function_exists('kvp_enqueue_scripts')) {
        function kvp_enqueue_scripts() {
            if (class_exists('MAC_Menu_Domain_Manager')) {
                $manager = MAC_Menu_Domain_Manager::get_instance();
                $manager->enqueue_scripts();
            } else {
                error_log('MAC Menu: kvp_enqueue_scripts called but MAC_Menu_Domain_Manager is not available');
            }
        }
    }

    if (!function_exists('kvp_handle_check_request')) {
        function kvp_handle_check_request($keyDomainCheck = null) {
            if (class_exists('MAC_Menu_Domain_Manager')) {
                $manager = MAC_Menu_Domain_Manager::get_instance();
                $manager->handle_check_request($keyDomainCheck);
            } else {
                error_log('MAC Menu: kvp_handle_check_request called but MAC_Menu_Domain_Manager is not available');
            }
        }
    }

    if (!function_exists('kvp_handle_check_request_url')) {
        function kvp_handle_check_request_url() {
            error_log('=== MAC Menu: kvp_handle_check_request_url() CALLED (compatibility layer) ===');
            error_log('MAC Menu: kvp_handle_check_request_url - Timestamp: ' . date('Y-m-d H:i:s'));
            
            if (class_exists('MAC_Menu_Domain_Manager')) {
                error_log('MAC Menu: kvp_handle_check_request_url - MAC_Menu_Domain_Manager found, calling handle_check_request_url()');
                $manager = MAC_Menu_Domain_Manager::get_instance();
                $manager->handle_check_request_url();
                error_log('MAC Menu: kvp_handle_check_request_url() ENDING - Success');
            } else {
                error_log('MAC Menu: kvp_handle_check_request_url - MAC_Menu_Domain_Manager not available');
                error_log('MAC Menu: kvp_handle_check_request_url() ENDING - Error');
            }
        }
    }

    // Removed kvp_handle_ajax_request function to avoid conflicts
    // MAC Core now uses mac_core_add_license action directly
//}

// Note: Update functionality is now handled by MAC_Core\Update_Manager class

// Helper functions for add-ons to easily use Update Manager
if (!function_exists('mac_get_update_manager')) {
    function mac_get_update_manager() {
        if (class_exists('MAC_Core\Update_Manager')) {
            return MAC_Core\Update_Manager::get_instance();
        }
        return null;
    }
}

if (!function_exists('mac_check_github_token')) {
    function mac_check_github_token($addon_slug) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->check_github_token($addon_slug);
        }
        return false;
    }
}

if (!function_exists('mac_check_plugin_update')) {
    function mac_check_plugin_update($addon_slug, $github_repo) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->get_update_info($addon_slug, $github_repo);
        }
        return false;
    }
}

if (!function_exists('mac_is_update_available')) {
    function mac_is_update_available($addon_slug, $github_repo) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->is_update_available($addon_slug, $github_repo);
        }
        return false;
    }
}

if (!function_exists('mac_get_update_url')) {
    function mac_get_update_url($addon_slug) {
        $update_manager = mac_get_update_manager();
        if ($update_manager) {
            return $update_manager->get_update_url($addon_slug);
        }
        return admin_url('plugins.php?update_mac=' . $addon_slug);
    }
}

// Register the old function hooks for MAC Menu compatibility
// Only register if MAC Menu is not installed to avoid conflicts
if (!file_exists(WP_PLUGIN_DIR . '/mac-menu/mac-menu.php')) {
    add_action('admin_enqueue_scripts', 'kvp_enqueue_scripts');
    
    // Auto-check domain URL when no key exists or key is invalid
    // DISABLED: Now using manual check via button
    // add_action('admin_init', 'kvp_auto_check_domain_url');
}

// Auto-check domain URL function
if (!function_exists('kvp_auto_check_domain_url')) {
    function kvp_auto_check_domain_url() {
        error_log('=== MAC Menu: kvp_auto_check_domain_url() CALLED ===');
        error_log('MAC Menu: kvp_auto_check_domain_url - Timestamp: ' . date('Y-m-d H:i:s'));
        
        // Only check if we're in admin and not doing AJAX
        if (!is_admin() || (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
            error_log('MAC Menu: kvp_auto_check_domain_url - Not in admin or doing AJAX, skipping');
            error_log('MAC Menu: kvp_auto_check_domain_url() ENDING - Skipped');
            return;
        }
        
        // Check if we have a valid key
        $current_key = get_option('mac_domain_valid_key', '');
        $current_status = get_option('mac_domain_valid_status', '');
        
        error_log('MAC Menu: kvp_auto_check_domain_url - Current key: ' . ($current_key ?: 'empty'));
        error_log('MAC Menu: kvp_auto_check_domain_url - Current status: ' . ($current_status ?: 'empty'));
        
        // If no key or invalid status, check with CRM
        if (empty($current_key) || $current_status !== 'activate') {
            error_log('MAC Menu: kvp_auto_check_domain_url - No valid key or invalid status detected');
            
            // Check last sync time to avoid too frequent requests
            $last_sync = get_option('mac_domain_last_sync', 0);
            $current_time = time();
            
            // Ensure $last_sync is an integer
            $last_sync = intval($last_sync);
            
            $time_diff = $current_time - $last_sync;
            
            error_log('MAC Menu: kvp_auto_check_domain_url - Last sync: ' . date('Y-m-d H:i:s', $last_sync));
            error_log('MAC Menu: kvp_auto_check_domain_url - Current time: ' . date('Y-m-d H:i:s', $current_time));
            error_log('MAC Menu: kvp_auto_check_domain_url - Time difference: ' . $time_diff . ' seconds');
            
            // Only check if it's been more than 1 hour since last check
            if (($current_time - $last_sync) > 3600) {
                error_log('MAC Menu: kvp_auto_check_domain_url - More than 1 hour passed, calling kvp_handle_check_request_url()');
                kvp_handle_check_request_url();
                error_log('MAC Menu: kvp_auto_check_domain_url() ENDING - URL check called');
            } else {
                error_log('MAC Menu: kvp_auto_check_domain_url - Less than 1 hour passed, skipping check');
                error_log('MAC Menu: kvp_auto_check_domain_url() ENDING - Skipped (time limit)');
            }
        } else {
            error_log('MAC Menu: kvp_auto_check_domain_url - Valid key and status found, no need to check');
            error_log('MAC Menu: kvp_auto_check_domain_url() ENDING - No action needed');
        }
    }
}
