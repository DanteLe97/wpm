document.addEventListener("DOMContentLoaded", function () {
    const btn = document.getElementById("download-pdf");
    if (btn) {
        let rawTitle = document.title;                     // hoặc lấy từ nơi khác
        let decodedTitle = decodeHtmlEntities(rawTitle);  // giải mã HTML entities
        let slug = slugifyKeepCase(decodedTitle);          // tạo slug giữ in hoa
        btn.addEventListener("click", function () {
			let scale = 2;
			if (document.documentElement.offsetWidth < 767) {
				scale = 1;
			}
            const opt = {
                margin: [10, 10],
                filename: slug+'.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: {
                    scale: scale,
                    useCORS: true,
                    scrollY: 0,
                    scrollX: window.pageXOffset, // fix f12
                    windowWidth: document.documentElement.offsetWidth
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'letter',
                    orientation: 'portrait'
                },
                pagebreak: {
                    mode: ['avoid-all', 'css', 'legacy'],
                    avoid: ['img', '.no-break'],
                    after: '#mac-qr'
                }
            };

            // Tạo bản sao của body
            var clonedHtml = document.documentElement.cloneNode(true);
            // Hide unnecessary elements
            const elementsToHide = clonedHtml.querySelectorAll('script, style, link, meta, noscript, .no-print, #jet-theme-core-header, #jet-theme-core-footer, header, footer, #wpadminbar');
            elementsToHide.forEach(el => el.style.display = 'none');

            // Tìm phần tử QR và tách nó ra
            ['#mac-qr', '#mac-module-qr'].forEach(selector => {
                const qrElement = clonedHtml.querySelector(selector);
                if (qrElement) {
                    qrElement.style.pageBreakBefore = 'always';
                    qrElement.style.breakBefore = 'always';
                    qrElement.style.height = '279.4mm';
                    qrElement.style.display = 'flex';
                    qrElement.style.justifyContent = 'center';
                    qrElement.style.alignItems = 'center';
                    qrElement.style.flexDirection = 'column';
                    qrElement.style.textAlign = 'center';
                }
            });

            // Tạo PDF với html2pdf
            html2pdf().set(opt).from(clonedHtml).toPdf().get('pdf').then((pdf) => {
                // Lấy số trang
                const totalPages = pdf.internal.getNumberOfPages();
                // Xóa trang cuối nếu có nhiều hơn 1 trang
                if (totalPages > 1) {
                    pdf.deletePage(totalPages);
                }
                // Lưu PDF
                pdf.save(slug + '.pdf');
            }).catch(err => {
                console.error('Lỗi khi xuất PDF:', err);
            })
        });
    }
    
    function slugifyKeepCase(text) {
        return text
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')       // Bỏ dấu tiếng Việt
          .replace(/[^a-zA-Z0-9\s-]/g, '')       // Loại bỏ ký tự đặc biệt (giữ chữ in hoa)
          .trim()
          .replace(/\s+/g, '-')                  // khoảng trắng -> dấu -
          .replace(/-+/g, '-');                  // gộp nhiều dấu -
    }
    function decodeHtmlEntities(html) {
        const txt = document.createElement('textarea');
        txt.innerHTML = html;
        return txt.value;
    }
});
