<?php
// Hook để thêm cột QR vào danh sách Pages
add_filter('manage_pages_columns', 'qrcode_add_column');
if (!function_exists('qrcode_add_column')) {
    function qrcode_add_column($columns) {
        $columns['qrcode'] = 'QR Code';
        return $columns;
    }
}

// Hàm mã hóa ID
if (!function_exists('qrcode_encrypt_id')) {
    function qrcode_encrypt_id($id) {
        $salt = 6008;
        $encrypted = ($id + $salt) * 2;
        return strrev($encrypted);
    }
}

// Hàm giải mã ID
if (!function_exists('qrcode_decrypt_id')) {
    function qrcode_decrypt_id($encrypted) {
        $salt = 6008;
        $reversed = strrev($encrypted);
        return ($reversed / 2) - $salt;
    }
}

// Hook để hiển thị QR trong cột
add_action('manage_pages_custom_column', 'qrcode_column_content', 10, 2);
if (!function_exists('qrcode_column_content')) {
    function qrcode_column_content($column_name, $post_id) {
        if ($column_name == 'qrcode') {
            if (!extension_loaded('gd')) {
                echo '<span style="color:red">PHP GD library không được bật. Vui lòng bật extension này trong php.ini</span>';
                return;
            }

            $qr_dir = MAC_PATH . 'adds-on/qr-code-pages/qr-images/';
            $qr_url = MAC_URI . 'adds-on/qr-code-pages/qr-images/';

            if (!file_exists($qr_dir)) {
                if (!wp_mkdir_p($qr_dir)) {
                    echo '<span style="color:red">Không thể tạo thư mục QR code. Vui lòng kiểm tra quyền truy cập thư mục.</span>';
                    return;
                }
            }

            if (!is_writable($qr_dir)) {
                echo '<span style="color:red">Thư mục QR code không có quyền ghi. Vui lòng cấp quyền ghi cho thư mục ' . esc_html($qr_dir) . '</span>';
                return;
            }

            if (!file_exists(MAC_PATH . 'adds-on/qr-code-pages/assets/phpqrcode/phpqrcode.php')) {
                echo '<span style="color:red">Không tìm thấy file thư viện QR code</span>';
                return;
            }
            require_once MAC_PATH . 'adds-on/qr-code-pages/assets/phpqrcode/phpqrcode.php';

            $file_name = 'qr-' . $post_id . '.png';
            $file_path = $qr_dir . $file_name;

            try {
                if (!file_exists($file_path)) {
                    $site_url = get_site_url();
                    $encrypted_id = qrcode_encrypt_id($post_id);
                    $qr_data = $site_url . '/qr-redirect/?id=' . $encrypted_id;
                    QRcode::png($qr_data, $file_path, QR_ECLEVEL_L, 3);

                    if (!file_exists($file_path)) {
                        echo '<span style="color:red">Không thể tạo QR code. Vui lòng kiểm tra quyền ghi file.</span>';
                        return;
                    }
                }

                echo '<img src="' . esc_url($qr_url . $file_name) . '" width="80" height="80" alt="QR Code for ' . esc_attr(get_the_title($post_id)) . '" />';
            } catch (Exception $e) {
                echo '<span style="color:red">Lỗi khi tạo QR code: ' . esc_html($e->getMessage()) . '</span>';
            }
        }
    }
}

// Hook để xử lý redirect khi quét QR code
add_action('init', 'handle_qr_redirect');
if (!function_exists('handle_qr_redirect')) {
    function handle_qr_redirect() {
        if (isset($_GET['id']) && $_GET['id'] != 'new') {
            $encrypted_id = sanitize_text_field($_GET['id']);

            try {
                $page_id = qrcode_decrypt_id($encrypted_id);

                if ($page_id > 0) {
                    $page_url = get_permalink($page_id);
                    if ($page_url) {
                        wp_redirect($page_url);
                        exit;
                    }
                }
            } catch (Exception $e) {
                // Không làm gì khi lỗi
            }
        }
    }
}

// Thêm rewrite rule cho endpoint riêng
add_action('init', 'add_qr_redirect_endpoint');
if (!function_exists('add_qr_redirect_endpoint')) {
    function add_qr_redirect_endpoint() {
        add_rewrite_rule('^qr-redirect/?$', 'index.php', 'top');
    }
}

// Đăng ký query var
add_filter('query_vars', 'register_qr_query_var');
if (!function_exists('register_qr_query_var')) {
    function register_qr_query_var($vars) {
        $vars[] = 'id';
        return $vars;
    }
}

// Enqueue style và script cho export PDF
add_action('wp_enqueue_scripts', 'mac_add_on_qr_code_enqueue');
if (!function_exists('mac_add_on_qr_code_enqueue')) {
    function mac_add_on_qr_code_enqueue() {
        wp_enqueue_style('mac-qr-style', MAC_URI . 'adds-on/qr-code-pages/assets/css/style.css');
        wp_enqueue_script('epe-pdf-export-html2pdf', MAC_URI . 'adds-on/qr-code-pages/assets/js/html2pdf.bundle.min.js', ['jquery'], '', true);
        wp_enqueue_script('epe-pdf-export', MAC_URI . 'adds-on/qr-code-pages/assets/js/mac-pdf-export.js', ['epe-pdf-export-html2pdf', 'jquery'], '', true);
    }
}
