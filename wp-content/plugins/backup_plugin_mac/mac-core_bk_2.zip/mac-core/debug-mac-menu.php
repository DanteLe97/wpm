<?php
/**
 * MAC Menu Debug Helper
 * 
 * Add this to your theme's functions.php or use as a standalone file
 * to debug MAC Menu domain validation flow
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add debug menu to admin
add_action('admin_menu', function() {
    add_submenu_page(
        'mac-core',
        'MAC Menu Debug',
        'Debug',
        'manage_options',
        'mac-menu-debug',
        'mac_menu_debug_page'
    );
});

function mac_menu_debug_page() {
    ?>
    <div class="wrap">
        <h1>MAC Menu Debug</h1>
        
        <h2>Current Options</h2>
        <table class="wp-list-table widefat fixed striped">
            <tr>
                <td><strong>mac_domain_valid_key</strong></td>
                <td><?php echo esc_html(get_option('mac_domain_valid_key', 'Not set')); ?></td>
            </tr>
            <tr>
                <td><strong>mac_domain_valid_status</strong></td>
                <td><?php echo esc_html(get_option('mac_domain_valid_status', 'Not set')); ?></td>
            </tr>
            <tr>
                <td><strong>mac_menu_github_key</strong></td>
                <td><?php echo esc_html(get_option('mac_menu_github_key', 'Not set')); ?></td>
            </tr>
        </table>
        
        <h2>Test API Endpoints</h2>
        <p>Click the buttons below to test API endpoints manually:</p>
        
        <div style="margin: 20px 0;">
            <button type="button" class="button button-primary" onclick="testValidateKey()" id="btn-validate-key">
                <span class="dashicons dashicons-admin-tools" style="margin-right: 5px;"></span>
                Test Validate Key API
            </button>
            
            <button type="button" class="button button-primary" onclick="testValidateUrl()" id="btn-validate-url">
                <span class="dashicons dashicons-admin-tools" style="margin-right: 5px;"></span>
                Test Validate URL API
            </button>
            
            <button type="button" class="button button-primary" onclick="testRegisterDomain()" id="btn-register-domain">
                <span class="dashicons dashicons-admin-tools" style="margin-right: 5px;"></span>
                Test Register Domain API
            </button>
        </div>
        
        <h2>Test Real Key</h2>
        <p>Enter a real key to test the actual API:</p>
        
        <div style="background: #f9f9f9; padding: 15px; border-radius: 4px; margin: 20px 0;">
            <form id="real-key-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="real-key-input">License Key:</label>
                        </th>
                        <td>
                            <input type="text" id="real-key-input" name="real_key" class="regular-text" placeholder="Enter your license key" required>
                            <p class="description">Enter a real license key to test the API</p>
                        </td>
                    </tr>
                </table>
                
                <button type="submit" class="button button-primary" id="btn-test-real-key">
                    <span class="dashicons dashicons-admin-tools" style="margin-right: 5px;"></span>
                    Test Real Key
                </button>
            </form>
        </div>
        
        <div id="api-results" style="margin-top: 20px;"></div>
        
        <h2>Recent Error Logs</h2>
        <div id="error-logs" style="background: #f1f1f1; padding: 10px; max-height: 300px; overflow-y: auto;">
            <?php
            $log_file = WP_CONTENT_DIR . '/debug.log';
            if (file_exists($log_file)) {
                $logs = file_get_contents($log_file);
                $lines = explode("\n", $logs);
                $mac_menu_logs = array_filter($lines, function($line) {
                    return strpos($line, 'MAC Menu') !== false;
                });
                $recent_logs = array_slice($mac_menu_logs, -20);
                foreach ($recent_logs as $log) {
                    echo '<div style="margin: 2px 0; font-family: monospace; font-size: 12px;">' . esc_html($log) . '</div>';
                }
            } else {
                echo '<p>No debug log found. Make sure WP_DEBUG_LOG is enabled.</p>';
            }
            ?>
        </div>
    </div>
    
    <style>
    .loading {
        opacity: 0.6;
        pointer-events: none;
    }
    
    .loading .dashicons {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .api-result {
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 15px;
        margin: 10px 0;
    }
    
    .api-result h3 {
        margin-top: 0;
        color: #0073aa;
    }
    
    .api-result pre {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 3px;
        padding: 10px;
        overflow-x: auto;
        font-size: 12px;
        line-height: 1.4;
    }
    
    .api-info {
        background: #e7f3ff;
        border-left: 4px solid #0073aa;
        padding: 10px;
        margin: 10px 0;
    }
    
    .api-info h4 {
        margin: 0 0 10px 0;
        color: #0073aa;
    }
    
    .api-info table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .api-info td {
        padding: 5px;
        border-bottom: 1px solid #ddd;
    }
    
    .api-info td:first-child {
        font-weight: bold;
        width: 150px;
    }
    </style>
    
    <script>
    function setLoading(buttonId, isLoading) {
        const button = document.getElementById(buttonId);
        const icon = button.querySelector('.dashicons');
        
        if (isLoading) {
            button.classList.add('loading');
            icon.className = 'dashicons dashicons-update';
        } else {
            button.classList.remove('loading');
            icon.className = 'dashicons dashicons-admin-tools';
        }
    }
    
    function testValidateKey() {
        setLoading('btn-validate-key', true);
        jQuery('#api-results').html('<div class="api-result"><h3>Testing Validate Key API...</h3><p>Please wait...</p></div>');
        
        jQuery.post(ajaxurl, {
            action: 'test_mac_menu_validate_key',
            nonce: '<?php echo wp_create_nonce('mac_menu_debug'); ?>'
        }, function(response) {
            setLoading('btn-validate-key', false);
            displayApiResult('Validate Key API', response);
        }).fail(function(xhr, status, error) {
            setLoading('btn-validate-key', false);
            jQuery('#api-results').html('<div class="api-result"><h3>Error</h3><p>Request failed: ' + error + '</p></div>');
        });
    }
    
    function testValidateUrl() {
        setLoading('btn-validate-url', true);
        jQuery('#api-results').html('<div class="api-result"><h3>Testing Validate URL API...</h3><p>Please wait...</p></div>');
        
        jQuery.post(ajaxurl, {
            action: 'test_mac_menu_validate_url',
            nonce: '<?php echo wp_create_nonce('mac_menu_debug'); ?>'
        }, function(response) {
            setLoading('btn-validate-url', false);
            displayApiResult('Validate URL API', response);
        }).fail(function(xhr, status, error) {
            setLoading('btn-validate-url', false);
            jQuery('#api-results').html('<div class="api-result"><h3>Error</h3><p>Request failed: ' + error + '</p></div>');
        });
    }
    
    function testRegisterDomain() {
        setLoading('btn-register-domain', true);
        jQuery('#api-results').html('<div class="api-result"><h3>Testing Register Domain API...</h3><p>Please wait...</p></div>');
        
        jQuery.post(ajaxurl, {
            action: 'test_mac_menu_register_domain',
            nonce: '<?php echo wp_create_nonce('mac_menu_debug'); ?>'
        }, function(response) {
            setLoading('btn-register-domain', false);
            displayApiResult('Register Domain API', response);
        }).fail(function(xhr, status, error) {
            setLoading('btn-register-domain', false);
            jQuery('#api-results').html('<div class="api-result"><h3>Error</h3><p>Request failed: ' + error + '</p></div>');
        });
    }
    
    function displayApiResult(title, response) {
        const domain = '<?php echo get_site_url() . '/'; ?>';
        const version = '<?php echo defined('MAC_CORE_VERSION') ? MAC_CORE_VERSION : '1.0.0'; ?>';
        
        let html = '<div class="api-result">';
        html += '<h3>' + title + '</h3>';
        
        // API Information
        html += '<div class="api-info">';
        html += '<h4>API Request Details:</h4>';
        html += '<table>';
        
        if (title.includes('Validate Key')) {
            html += '<tr><td>API URL:</td><td>https://wpm.macusaone.com/api/v1/menu-license/validate-key</td></tr>';
            html += '<tr><td>Method:</td><td>POST</td></tr>';
            html += '<tr><td>Parameters:</td><td>key, url, menuversion</td></tr>';
            html += '<tr><td>Test Key:</td><td>test-key</td></tr>';
            html += '<tr><td>Domain:</td><td>' + domain + '</td></tr>';
            html += '<tr><td>Version:</td><td>' + version + '</td></tr>';
        } else if (title.includes('Validate URL')) {
            html += '<tr><td>API URL:</td><td>https://wpm.macusaone.com/api/v1/menu-license/validate-url</td></tr>';
            html += '<tr><td>Method:</td><td>POST</td></tr>';
            html += '<tr><td>Parameters:</td><td>url, menuversion</td></tr>';
            html += '<tr><td>Domain:</td><td>' + domain + '</td></tr>';
            html += '<tr><td>Version:</td><td>' + version + '</td></tr>';
        } else if (title.includes('Register Domain')) {
            html += '<tr><td>API URL:</td><td>https://wpm.macusaone.com/api/v1/menu-license/register-domain</td></tr>';
            html += '<tr><td>Method:</td><td>POST</td></tr>';
            html += '<tr><td>Parameters:</td><td>key, url, menuversion</td></tr>';
            html += '<tr><td>Test Key:</td><td>test-key</td></tr>';
            html += '<tr><td>Domain:</td><td>' + domain + '</td></tr>';
            html += '<tr><td>Version:</td><td>' + version + '</td></tr>';
        } else if (title.includes('Real Key')) {
            const realKey = document.getElementById('real-key-input').value;
            html += '<tr><td>API URL:</td><td>https://wpm.macusaone.com/api/v1/menu-license/register-domain</td></tr>';
            html += '<tr><td>Method:</td><td>POST</td></tr>';
            html += '<tr><td>Parameters:</td><td>key, url, menuversion</td></tr>';
            html += '<tr><td>Real Key:</td><td>' + realKey + '</td></tr>';
            html += '<tr><td>Domain:</td><td>' + domain + '</td></tr>';
            html += '<tr><td>Version:</td><td>' + version + '</td></tr>';
        }
        
        html += '</table>';
        html += '</div>';
        
        // Response
        html += '<h4>API Response:</h4>';
        html += '<pre>' + JSON.stringify(response, null, 2) + '</pre>';
        
        // Check if response has debug info
        if (response.data && response.data.debug_info) {
            html += '<h4>Debug Information:</h4>';
            html += '<pre>' + JSON.stringify(response.data.debug_info, null, 2) + '</pre>';
        }
        
        html += '</div>';
        
        jQuery('#api-results').html(html);
    }
    
    // Handle real key form submission
    jQuery(document).ready(function($) {
        $('#real-key-form').on('submit', function(e) {
            e.preventDefault();
            
            const realKey = $('#real-key-input').val();
            if (!realKey) {
                alert('Please enter a license key');
                return;
            }
            
            setLoading('btn-test-real-key', true);
            $('#api-results').html('<div class="api-result"><h3>Testing Real Key...</h3><p>Please wait...</p></div>');
            
            $.post(ajaxurl, {
                action: 'test_mac_menu_real_key',
                nonce: '<?php echo wp_create_nonce('mac_menu_debug'); ?>',
                key: realKey
            }, function(response) {
                setLoading('btn-test-real-key', false);
                displayApiResult('Real Key Test', response);
            }).fail(function(xhr, status, error) {
                setLoading('btn-test-real-key', false);
                $('#api-results').html('<div class="api-result"><h3>Error</h3><p>Request failed: ' + error + '</p></div>');
            });
        });
    });
    </script>
    <?php
}

// AJAX handlers for testing
add_action('wp_ajax_test_mac_menu_validate_key', function() {
    if (!wp_verify_nonce($_POST['nonce'], 'mac_menu_debug')) {
        wp_send_json_error('Invalid nonce');
    }
    
    $manager = MAC_Menu_Domain_Manager::get_instance();
    
    // Capture debug info
    $debug_info = array(
        'api_url' => 'https://wpm.macusaone.com/api/v1/menu-license/validate-key',
        'method' => 'POST',
        'parameters' => array(
            'key' => 'test-key',
            'url' => get_site_url() . '/',
            'menuversion' => defined('MAC_CORE_VERSION') ? MAC_CORE_VERSION : '1.0.0'
        ),
        'timestamp' => current_time('mysql')
    );
    
    $manager->handle_check_request('test-key');
    
    wp_send_json_success(array(
        'message' => 'Validate key test completed. Check error logs for detailed information.',
        'debug_info' => $debug_info
    ));
});

add_action('wp_ajax_test_mac_menu_validate_url', function() {
    if (!wp_verify_nonce($_POST['nonce'], 'mac_menu_debug')) {
        wp_send_json_error('Invalid nonce');
    }
    
    $manager = MAC_Menu_Domain_Manager::get_instance();
    
    // Capture debug info
    $debug_info = array(
        'api_url' => 'https://wpm.macusaone.com/api/v1/menu-license/validate-url',
        'method' => 'POST',
        'parameters' => array(
            'url' => get_site_url() . '/',
            'menuversion' => defined('MAC_CORE_VERSION') ? MAC_CORE_VERSION : '1.0.0'
        ),
        'timestamp' => current_time('mysql')
    );
    
    $manager->handle_check_request_url();
    
    wp_send_json_success(array(
        'message' => 'Validate URL test completed. Check error logs for detailed information.',
        'debug_info' => $debug_info
    ));
});

add_action('wp_ajax_test_mac_menu_register_domain', function() {
    if (!wp_verify_nonce($_POST['nonce'], 'mac_menu_debug')) {
        wp_send_json_error('Invalid nonce');
    }
    
    $manager = MAC_Menu_Domain_Manager::get_instance();
    
    // Capture debug info
    $debug_info = array(
        'api_url' => 'https://wpm.macusaone.com/api/v1/menu-license/register-domain',
        'method' => 'POST',
        'parameters' => array(
            'key' => 'test-key',
            'url' => get_site_url() . '/',
            'menuversion' => defined('MAC_CORE_VERSION') ? MAC_CORE_VERSION : '1.0.0'
        ),
        'timestamp' => current_time('mysql')
    );
    
    $manager->handle_ajax_request();
    
    wp_send_json_success(array(
        'message' => 'Register domain test completed. Check error logs for detailed information.',
        'debug_info' => $debug_info
    ));
});

add_action('wp_ajax_test_mac_menu_real_key', function() {
    if (!wp_verify_nonce($_POST['nonce'], 'mac_menu_debug')) {
        wp_send_json_error('Invalid nonce');
    }
    
    if (!isset($_POST['key']) || empty($_POST['key'])) {
        wp_send_json_error('Key is required');
    }
    
    $real_key = sanitize_text_field($_POST['key']);
    $manager = MAC_Menu_Domain_Manager::get_instance();
    
    // Capture debug info
    $debug_info = array(
        'api_url' => 'https://wpm.macusaone.com/api/v1/menu-license/register-domain',
        'method' => 'POST',
        'parameters' => array(
            'key' => $real_key,
            'url' => get_site_url() . '/',
            'menuversion' => defined('MAC_CORE_VERSION') ? MAC_CORE_VERSION : '1.0.0'
        ),
        'timestamp' => current_time('mysql')
    );
    
    // Simulate the AJAX request with real key
    $_POST['key'] = $real_key;
    $_POST['nonce'] = wp_create_nonce('mac_core_add_license');
    
    $manager->handle_ajax_request();
    
    wp_send_json_success(array(
        'message' => 'Real key test completed. Check error logs for detailed information.',
        'debug_info' => $debug_info
    ));
});
