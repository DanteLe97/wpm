jQuery(document).ready(function($) {
    'use strict';

    // Handle license actions
    $('.mac-core-license-action').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var action = $button.data('action');
        var licenseId = $button.data('license-id');

        if (action === 'delete' && !confirm(macCoreAdmin.i18n.confirmDelete)) {
            return;
        }

        $button.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_license_action',
                nonce: macCoreAdmin.nonce,
                license_action: action,
                license_id: licenseId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // Handle plugin actions
    $('.mac-core-plugin-action').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var action = $button.data('action');
        var pluginSlug = $button.data('plugin-slug');

        if (action === 'uninstall' && !confirm(macCoreAdmin.i18n.confirmDelete)) {
            return;
        }

        $button.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_plugin_action',
                nonce: macCoreAdmin.nonce,
                plugin_action: action,
                plugin_slug: pluginSlug
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // Handle settings form
    $('#mac-core-settings-form').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $submitButton = $form.find('button[type="submit"]');

        $submitButton.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_save_settings',
                nonce: macCoreAdmin.nonce,
                api_url: $form.find('#api_url').val(),
                api_key: $form.find('#api_key').val(),
                debug_mode: $form.find('#debug_mode').is(':checked') ? 1 : 0
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $submitButton.prop('disabled', false);
            }
        });
    });

    // Handle license key validation
    $('#license_key').on('blur', function() {
        var $input = $(this);
        var licenseKey = $input.val();

        if (!licenseKey) {
            return;
        }

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_validate_license',
                nonce: macCoreAdmin.nonce,
                license_key: licenseKey
            },
            success: function(response) {
                if (response.success) {
                    $input.removeClass('error').addClass('valid');
                } else {
                    $input.removeClass('valid').addClass('error');
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            }
        });
    });

    // Handle plugin installation
    $('.mac-core-install-plugin').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var pluginSlug = $button.data('plugin-slug');

        $button.prop('disabled', true);

        $.ajax({
            url: macCoreAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'mac_core_install_plugin',
                nonce: macCoreAdmin.nonce,
                plugin_slug: pluginSlug
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    var message = 'An error occurred.';
                    if (response && response.data && response.data.message) {
                        message = response.data.message;
                    } else if (response && response.message) {
                        message = response.message;
                    }
                    alert(message);
                }
            },
            error: function() {
                alert(macCoreAdmin.i18n.error);
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
});