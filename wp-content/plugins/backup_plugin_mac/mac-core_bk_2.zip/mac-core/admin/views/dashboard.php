<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

// Classes are already loaded in mac_core_init()

global $mac_core_license_manager;
$license_manager = $mac_core_license_manager;

$licenses = $license_manager->get_all_licenses();
// $plugins = $plugin_manager->get_installed_plugins(); // Plugin Manager not implemented yet

// Get MAC Core information
$mac_core_version = defined('MAC_CORE_VERSION') ? MAC_CORE_VERSION : 'Unknown';
$mac_core_path = defined('MAC_CORE_PATH') ? MAC_CORE_PATH : 'Unknown';

// Get CRM status
$domain_status = get_option('mac_domain_valid_status', 'inactive');
$domain_key = get_option('mac_domain_valid_key', '');
$domain_url = get_option('mac_domain_valid_url', '');

// Create last_sync option if it doesn't exist
if (false === get_option('mac_domain_last_sync')) {
    add_option('mac_domain_last_sync', '');
}

// Get MAC Core plugin data
$mac_core_plugin_data = get_plugin_data(MAC_CORE_PATH . 'mac-core.php');
$mac_core_description = isset($mac_core_plugin_data['Description']) ? $mac_core_plugin_data['Description'] : 'MAC Core Plugin';

// Ensure kvp_params is available for the form
?>
<script>
var kvp_params = {
    ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>'
};
</script>

<div class="wrap">
    <h1><?php echo esc_html__('MAC Core Dashboard', 'mac-core'); ?></h1>

    <div class="mac-core-dashboard">
        <!-- Top Row Grid -->
        <div class="mac-core-grid-row">
            <!-- MAC Core Information Section -->
            <div class="mac-core-dashboard-section mac-core-grid-item">
                <h2><?php echo esc_html__('MAC Core Information', 'mac-core'); ?></h2>
                
                <div class="mac-core-info-grid">
                    <div class="mac-core-info-item">
                        <strong><?php echo esc_html__('Version:', 'mac-core'); ?></strong>
                        <span class="mac-core-version"><?php echo esc_html($mac_core_version); ?></span>
                    </div>
                </div>
            </div>

            <!-- CRM Status Section -->
            <div class="mac-core-dashboard-section mac-core-grid-item">
                <h2><?php echo esc_html__('CRM Connection Status', 'mac-core'); ?></h2>
                
                <div class="mac-core-crm-status">
                    <div class="mac-core-status-item">
                        <strong><?php echo esc_html__('Status:', 'mac-core'); ?></strong>
                        <span class="mac-core-status mac-core-status-<?php echo $domain_status === 'activate' ? 'active' : 'inactive'; ?>">
                            <?php echo $domain_status === 'activate' ? esc_html__('Active', 'mac-core') : esc_html__('Inactive', 'mac-core'); ?>
                        </span>
                    </div>
                </div>
                
                <?php if ($domain_status !== 'activate') : ?>
                    <div class="mac-core-notice mac-core-notice-warning">
                        <p><?php echo esc_html__('⚠️ CRM connection is not active. Please add a valid license key below to activate the connection.', 'mac-core'); ?></p>
                    </div>
                <?php else : ?>
                    <div class="mac-core-notice mac-core-notice-success">
                        <p><?php echo esc_html__('✅ CRM connection is active and working properly.', 'mac-core'); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- License Management Section -->
            <div class="mac-core-dashboard-section mac-core-grid-item">
                <h2><?php echo esc_html__('License Management', 'mac-core'); ?></h2>
                
                <!-- Add License Form -->
                <div class="mac-core-form-container">
                                     <h3><?php echo esc_html__('Add License', 'mac-core'); ?></h3>
                    <div id="kvp-container" class="key-domain-wrap">
                        <form id="kvp-form">
                            <?php wp_nonce_field('mac_core_add_license', 'mac_core_license_nonce'); ?>
                            <label for="kvp-key-input"><?php echo esc_html__('Enter your key:', 'mac-core'); ?></label>
                            <input type="text" id="kvp-key-input" name="key" value="MAC Menu" required>
                            <button type="submit"><?php echo esc_html__('Validate', 'mac-core'); ?></button>
                        </form>
                        <div id="kvp-result"></div>
                    </div>
                </div>

                
            </div>
        </div>

        <!-- Bottom Row - System Information Section -->
        <div class="mac-core-grid-row">
            <div class="mac-core-dashboard-section mac-core-grid-item mac-core-full-width">
                <h2><?php echo esc_html__('System Information', 'mac-core'); ?></h2>
                <table class="widefat">
                    <tbody>
                        <tr>
                            <td><strong><?php echo esc_html__('WordPress Version', 'mac-core'); ?></strong></td>
                            <td><?php echo esc_html(get_bloginfo('version')); ?></td>
                        </tr>
                        <tr>
                            <td><strong><?php echo esc_html__('PHP Version', 'mac-core'); ?></strong></td>
                            <td><?php echo esc_html(PHP_VERSION); ?></td>
                        </tr>
                        <tr>
                            <td><strong><?php echo esc_html__('MySQL Version', 'mac-core'); ?></strong></td>
                            <td><?php echo esc_html($wpdb->get_var('SELECT VERSION()')); ?></td>
                        </tr>
                        <tr>
                            <td><strong><?php echo esc_html__('MAC Core Version', 'mac-core'); ?></strong></td>
                            <td><?php echo esc_html(MAC_CORE_VERSION); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        

        
    </div>
</div>

<style>
.mac-core-dashboard {
    margin-top: 20px;
}

/* Grid Layout */
.mac-core-grid-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 20px;
}

.mac-core-grid-item {
    min-height: 200px;
    display: flex;
    flex-direction: column;
}

.mac-core-full-width {
    grid-column: 1 / -1;
}

/* Responsive Design */
@media (max-width: 768px) {
    .mac-core-grid-row {
        grid-template-columns: 1fr;
        gap: 15px;
    }
    
    .mac-core-grid-item {
        min-height: auto;
    }
}

/* kvp-form styles from MAC Menu */
.key-domain-wrap form label {
    display: block;
    margin-bottom: 10px;
}

.key-domain-wrap form button {
    margin-top: 15px;
    display: block;
    background-color: #0073aa !important;
    color: #fff;
    border: none !important;
    padding: 7px 25px !important;
    border-radius: 5px;
    font-weight: 400;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    cursor: pointer;
}

.key-domain-wrap form input[type="text"] {
    width: 100%;
    max-width: 400px;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

#kvp-result {
    margin-top: 10px;
    font-weight: bold;
}

.mac-core-dashboard-section {
    background: #fff;
    padding: 20px;
    border: 1px solid #e1e1e1;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transition: box-shadow 0.3s ease;
}

.mac-core-dashboard-section:hover {
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.mac-core-dashboard-section h2 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #23282d;
    font-size: 18px;
    border-bottom: 2px solid #0073aa;
    padding-bottom: 8px;
}

.mac-core-form-container {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 6px;
    border: 1px solid #e9ecef;
    flex-grow: 1;
}

.mac-core-form-container h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #495057;
    font-size: 16px;
}

.mac-core-status {
    padding: 4px 8px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 12px;
}

.mac-core-status-active {
    background: #d4edda;
    color: #155724;
}

.mac-core-status-inactive {
    background: #f8d7da;
    color: #721c24;
}

.mac-core-status-invalid {
    background: #fff3cd;
    color: #856404;
}

.status-active {
    color: #46b450;
    font-weight: bold;
    background: #f7fcf7;
    padding: 4px 8px;
    border-radius: 4px;
    border: 1px solid #46b450;
}

.status-inactive {
    color: #dc3232;
    font-weight: bold;
    background: #fdf7f7;
    padding: 4px 8px;
    border-radius: 4px;
    border: 1px solid #dc3232;
}

.mac-core-info-grid {
    display: flex;
    gap: 15px;
    margin-top: 15px;
}

.mac-core-info-item {
    display: flex;
    align-items: center;
    gap: 10px;
}

.mac-core-info-item strong {
    color: #23282d;
    font-size: 14px;
}

.mac-core-info-item span {
    color: #666;
    font-size: 13px;
}

.mac-core-version {
    color: #0073aa !important;
    font-weight: bold;
}

.mac-core-crm-status {
    display: flex;
    gap: 15px;
    margin-top: 15px;
}

.mac-core-status-item {
    display: flex;
    align-items: center;
    gap: 10px;
}

.mac-core-status-item strong {
    color: #23282d;
    font-size: 14px;
}

.mac-core-status-item span {
    color: #666;
    font-size: 13px;
}

.mac-core-notice {
    margin-top: 15px;
    padding: 12px 15px;
    border-radius: 4px;
    border-left: 4px solid;
}

.mac-core-notice-warning {
    background: #fff3cd;
    border-left-color: #ffc107;
    color: #856404;
}

.mac-core-notice-success {
    background: #d4edda;
    border-left-color: #28a745;
    color: #155724;
}

.mac-core-notice p {
    margin: 0;
    font-weight: 500;
}

.mac-core-dashboard-section table {
    margin-top: 15px;
    border-collapse: collapse;
    width: 100%;
}

.mac-core-dashboard-section table td {
    padding: 12px 15px;
    border-bottom: 1px solid #e9ecef;
}

.mac-core-dashboard-section table tr:last-child td {
    border-bottom: none;
}

.mac-core-dashboard-section table tr:hover {
    background-color: #f8f9fa;
}

</style>

<script>
jQuery(document).ready(function($) {
    // Add License Form - Using kvp-form from MAC Menu
    $('#kvp-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $button = $form.find('button[type="submit"]');
        var $result = $('#kvp-result');
        var originalButtonText = $button.text();
        
        if ($('#kvp-key-input').val() != '' && $('#kvp-key-input').val() != 'MAC Menu') {
            var key = $('#kvp-key-input').val();
            
            // Show loading state
            $button.prop('disabled', true).text('Validating...');
            $result.html('<div style="color: blue; font-weight: bold;">🔄 Đang gửi request...</div>');
            
            console.log('🔍 Debug: Sending AJAX request');
            console.log('📤 Request data:', {
                action: 'kvp_handle_ajax_request',
                key: key,
                nonce: $('#mac_core_license_nonce').val()
            });
            
            $.ajax({
                url: kvp_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'kvp_handle_ajax_request',
                    key: key,
                    nonce: $('#mac_core_license_nonce').val()
                },
                beforeSend: function() {
                    console.log('🚀 AJAX request started');
                },
                success: function(response) {
                    console.log('✅ AJAX response received:', response);
                    $result.append('<div style="color: green; margin-top: 10px;">📥 Response: ' + JSON.stringify(response, null, 2) + '</div>');
                    
                    if (response.success) {
                        $result.append('<div style="color: green; font-weight: bold; margin-top: 10px;">✅ Success: ' + response.data + '</div>');
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        $result.append('<div style="color: red; font-weight: bold; margin-top: 10px;">❌ Error: ' + response.data + '</div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.log('❌ AJAX error:', {xhr: xhr, status: status, error: error});
                    $result.append('<div style="color: red; font-weight: bold; margin-top: 10px;">❌ AJAX Error: ' + status + ' - ' + error + '</div>');
                    $result.append('<div style="color: orange; margin-top: 5px;">📋 Response Text: ' + xhr.responseText + '</div>');
                },
                complete: function() {
                    console.log('🏁 AJAX request completed');
                    $button.prop('disabled', false).text(originalButtonText);
                }
            });
        } else {
            $result.html('<div style="color: orange;">⚠️ Vui lòng nhập key hợp lệ</div>');
        }
    });
    
    
    

});
</script>