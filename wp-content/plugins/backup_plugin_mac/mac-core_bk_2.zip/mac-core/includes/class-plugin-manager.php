<?php
namespace MAC_Core;

class Plugin_Manager {
    private $api;
    private $license_manager;

    public function __construct() {
        $this->api = new API();
        $this->license_manager = new License_Manager();

        add_action('admin_init', array($this, 'check_updates'));
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_plugin_updates'));
    }

    public function check_updates() {
        $plugins = $this->get_installed_plugins();
        foreach ($plugins as $plugin) {
            $license = $this->license_manager->get_license($plugin['slug']);
            if ($license && $license['status'] === 'active') {
                $info = $this->api->get_plugin_info($plugin['slug']);
                if ($info['success'] && version_compare($info['version'], $plugin['version'], '>')) {
                    $this->update_plugin($plugin['slug'], $info['version']);
                }
            }
        }
    }

    public function check_plugin_updates($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $plugins = $this->get_installed_plugins();
        foreach ($plugins as $plugin) {
            $license = $this->license_manager->get_license($plugin['slug']);
            if ($license && $license['status'] === 'active') {
                $info = $this->api->get_plugin_info($plugin['slug']);
                if ($info['success'] && version_compare($info['version'], $plugin['version'], '>')) {
                    $transient->response[$plugin['file']] = (object) array(
                        'slug' => $plugin['slug'],
                        'new_version' => $info['version'],
                        'url' => $info['url'],
                        'package' => $this->api->download_plugin($plugin['slug'], $info['version'])
                    );
                }
            }
        }

        return $transient;
    }

    public function install_plugin($plugin_slug) {
        $license = $this->license_manager->get_license($plugin_slug);
        if (!$license || $license['status'] !== 'active') {
            return array(
                'success' => false,
                'message' => __('Plugin requires an active license.', 'mac-core')
            );
        }

        $info = $this->api->get_plugin_info($plugin_slug);
        if (!$info['success']) {
            return $info;
        }

        $download = $this->api->download_plugin($plugin_slug, $info['version']);
        if (!$download['success']) {
            return $download;
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';

        $upgrader = new \Plugin_Upgrader(new \WP_Ajax_Upgrader_Skin());
        $result = $upgrader->install($download['data']);

        if (is_wp_error($result)) {
            return array(
                'success' => false,
                'message' => $result->get_error_message()
            );
        }

        return array(
            'success' => true,
            'message' => __('Plugin installed successfully.', 'mac-core')
        );
    }

    public function update_plugin($plugin_slug, $version) {
        $license = $this->license_manager->get_license($plugin_slug);
        if (!$license || $license['status'] !== 'active') {
            return array(
                'success' => false,
                'message' => __('Plugin requires an active license.', 'mac-core')
            );
        }

        $download = $this->api->download_plugin($plugin_slug, $version);
        if (!$download['success']) {
            return $download;
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';

        $upgrader = new \Plugin_Upgrader(new \WP_Ajax_Upgrader_Skin());
        $result = $upgrader->upgrade($download['data']);

        if (is_wp_error($result)) {
            return array(
                'success' => false,
                'message' => $result->get_error_message()
            );
        }

        return array(
            'success' => true,
            'message' => __('Plugin updated successfully.', 'mac-core')
        );
    }

    public function activate_plugin($plugin_slug) {
        $plugin_file = $this->get_plugin_file($plugin_slug);
        if (!$plugin_file) {
            return array(
                'success' => false,
                'message' => __('Plugin not found.', 'mac-core')
            );
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        activate_plugin($plugin_file);

        return array(
            'success' => true,
            'message' => __('Plugin activated successfully.', 'mac-core')
        );
    }

    public function uninstall_plugin($plugin_slug) {
        $plugin_file = $this->get_plugin_file($plugin_slug);
        if (!$plugin_file) {
            return array(
                'success' => false,
                'message' => __('Plugin not found.', 'mac-core')
            );
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        deactivate_plugins($plugin_file);

        return array(
            'success' => true,
            'message' => __('Plugin deactivated successfully.', 'mac-core')
        );
    }

    public function get_installed_plugins() {
        $plugins = array();
        $all_plugins = get_plugins();
        foreach ($all_plugins as $plugin_file => $plugin_data) {
            if (strpos($plugin_file, 'mac-') === 0) {
                $plugins[] = array(
                    'file' => $plugin_file,
                    'slug' => dirname($plugin_file),
                    'name' => $plugin_data['Name'],
                    'version' => $plugin_data['Version']
                );
            }
        }
        return $plugins;
    }

    private function get_plugin_file($plugin_slug) {
        $plugins = get_plugins();
        foreach ($plugins as $plugin_file => $plugin_data) {
            if (dirname($plugin_file) === $plugin_slug) {
                return $plugin_file;
            }
        }
        return false;
    }
} 