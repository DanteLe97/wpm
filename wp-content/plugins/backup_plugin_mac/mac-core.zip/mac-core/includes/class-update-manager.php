<?php
/**
 * MAC Core Update Manager
 * 
 * Handles plugin updates for all MAC add-ons
 */

namespace MAC_Core;

class Update_Manager {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        // Handle update requests
        if (isset($_GET['update_mac']) && !empty($_GET['update_mac'])) {
            $this->handle_update_request($_GET['update_mac']);
        }
    }
    
    /**
     * Check if domain license is active
     */
    public function is_domain_license_active() {
        $status = !empty(get_option('mac_domain_valid_status')) ? get_option('mac_domain_valid_status') : "0";
        error_log("MAC Core: Domain license status: {$status}");
        return $status === 'activate';
    }
    
    /**
     * Get GitHub token for specific addon
     */
    public function get_github_token($addon_slug) {
        // Convert dash to underscore for option name consistency
        $option_slug = str_replace('-', '_', $addon_slug);
        $token_option = $option_slug . '_github_key';
        $token = !empty(get_option($token_option)) ? get_option($token_option) : "";
        error_log("MAC Core: Getting GitHub token for {$addon_slug} (option: {$token_option}): " . (!empty($token) ? 'EXISTS' : 'EMPTY'));
        return $token;
    }
    
    /**
     * Check GitHub token validity
     */
    public function check_github_token($addon_slug) {
        $github_token = $this->get_github_token($addon_slug);
        if (empty($github_token)) {
            return false;
        }
        
        $args = array(
            'headers' => array(
                'Authorization' => 'token ' . $github_token,
                'User-Agent'    => 'WordPress Plugin',
                'Accept'        => 'application/vnd.github.v3+json',
            ),
            'timeout' => 60,
        );
        
        $response = wp_remote_get('https://api.github.com/user', $args);
        
        if (!is_wp_error($response)) {
            $code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            
            if ($code === 200) {
                $data = json_decode($body);
                return isset($data->login) ? $data->login : false;
            }
        }
        
        return false;
    }
    
    /**
     * Check for updates for specific addon
     */
    public function check_plugin_update($addon_slug, $github_repo) {
        error_log("=== MAC Core Update Debug: check_plugin_update for {$addon_slug} ===");
        
        $github_token = $this->get_github_token($addon_slug);
        error_log("GitHub token for {$addon_slug}: " . (!empty($github_token) ? 'EXISTS' : 'EMPTY'));
        
        if (empty($github_token)) {
            error_log("No GitHub token found for {$addon_slug}");
            return false;
        }
        
        $update_check_url = 'https://api.github.com/repos/' . $github_repo . '/contents/version.json';
        error_log("Checking update URL: {$update_check_url}");
        
        $args = array(
            'headers' => array(
                'Authorization' => 'token ' . $github_token,
                'User-Agent'    => 'WordPress Plugin',
                'Accept'        => 'application/vnd.github.v3+json',
            ),
            'timeout' => 60,
        );
        
        $response = wp_remote_get($update_check_url, $args);
        
        if (!is_wp_error($response)) {
            $code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            error_log("GitHub API response code: {$code}");
            
            if ($code === 200) {
                $data = json_decode($body, true);
                
                if (json_last_error() === JSON_ERROR_NONE && is_array($data) && isset($data['content'])) {
                    $version_data = base64_decode($data['content']);
                    $version_info = json_decode($version_data, true);
                    
                    if (json_last_error() === JSON_ERROR_NONE && is_array($version_info) && isset($version_info['version'])) {
                        $latest_version = $version_info['version'];
                        $current_version = $this->get_plugin_version($addon_slug);
                        
                        error_log("Current version: {$current_version}");
                        error_log("Latest version: {$latest_version}");
                        
                        // Check if update is available (same logic as MAC Menu)
                        if (version_compare($latest_version, '1.2.0', '>=') &&
                            version_compare($current_version, $latest_version, '<')) {
                            error_log("UPDATE AVAILABLE for {$addon_slug}!");
                            return array(
                                'available' => true,
                                'current_version' => $current_version,
                                'latest_version' => $latest_version,
                                'download_url' => isset($version_info['download_url']) ? $version_info['download_url'] : ''
                            );
                        } else {
                            error_log("No update available - version comparison failed");
                            error_log("Latest >= 1.2.0: " . (version_compare($latest_version, '1.2.0', '>=') ? 'YES' : 'NO'));
                            error_log("Current < Latest: " . (version_compare($current_version, $latest_version, '<') ? 'YES' : 'NO'));
                        }
                    } else {
                        error_log("Failed to parse version info JSON");
                    }
                } else {
                    error_log("Failed to parse GitHub response JSON");
                }
            } else {
                error_log("GitHub API returned error code: {$code}");
                error_log("Response body: " . substr($body, 0, 500));
            }
        } else {
            error_log("GitHub API request failed: " . $response->get_error_message());
        }
        
        error_log("=== End MAC Core Update Debug for {$addon_slug} ===");
        return false;
    }
    
    /**
     * Get plugin version
     */
    public function get_plugin_version($addon_slug) {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        
        $plugin_file = WP_PLUGIN_DIR . '/' . $addon_slug . '/' . $addon_slug . '.php';
        if (file_exists($plugin_file)) {
            $plugin_data = get_plugin_data($plugin_file);
            error_log("MAC Core: Plugin version for {$addon_slug}: " . (isset($plugin_data['Version']) ? $plugin_data['Version'] : 'Unknown'));
            return isset($plugin_data['Version']) ? $plugin_data['Version'] : 'Unknown';
        }
        
        error_log("MAC Core: Plugin version for {$addon_slug}: Unknown (file not found)");
        return 'Unknown';
    }
    
    /**
     * GitHub API call with retry mechanism
     */
    private function github_wp_get($url, $addon_slug, $retries = 3) {
        $github_token = $this->get_github_token($addon_slug);
        
        for ($i = 0; $i < $retries; $i++) {
            $args = array(
                'headers' => array(
                    'Authorization' => 'token ' . $github_token,
                    'User-Agent'    => 'WordPress Plugin',
                    'Accept'        => 'application/vnd.github.v3+json',
                ),
                'timeout' => 60,
            );
            
            $response = wp_remote_get($url, $args);
            
            if (!is_wp_error($response)) {
                $code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);
                
                if ($code === 200) {
                    return $body;
                }
                
                error_log("GitHub HTTP {$code} for {$url} (attempt " . ($i + 1) . ")");
            } else {
                error_log('GitHub request error (attempt ' . ($i + 1) . '): ' . $response->get_error_message());
            }
            
            // Wait before retry (except for last attempt)
            if ($i < $retries - 1) {
                sleep(2);
            }
        }
        
        error_log("GitHub request failed after {$retries} attempts for {$url}");
        return false;
    }
    
    /**
     * List files in GitHub directory
     */
    private function list_files_in_directory($directory, $addon_slug) {
        $body = $this->github_wp_get('https://api.github.com/repos/DanteLe97/' . strtoupper($addon_slug) . '/contents/' . ltrim($directory, '/'), $addon_slug);
        if ($body === false) {
            return array();
        }
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            error_log('list_files_in_directory JSON error: ' . json_last_error_msg());
            return array();
        }
        return $data;
    }
    
    /**
     * Download file content from GitHub
     */
    private function download_file_content($file_url, $addon_slug) {
        $body = $this->github_wp_get($file_url, $addon_slug);
        if ($body === false) {
            error_log('Failed to download file content from: ' . $file_url);
            return '';
        }
        
        $file_info = json_decode($body, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($file_info['content'])) {
            $content = base64_decode($file_info['content']);
            
            // Validate decoded content
            if ($content === false) {
                error_log('Failed to decode base64 content from: ' . $file_url);
                return '';
            }
            
            return $content;
        }
        
        error_log('Invalid file info format from: ' . $file_url);
        return '';
    }
    
    /**
     * Delete directory recursively
     */
    private function delete_directory($dir) {
        if (is_dir($dir)) {
            $objects = array_diff(scandir($dir), array('.', '..'));
            foreach ($objects as $object) {
                $file = $dir . '/' . $object;
                (is_dir($file)) ? $this->delete_directory($file) : unlink($file);
            }
            rmdir($dir);
        }
    }
    
    /**
     * Download subdirectory files
     */
    private function download_sub_directory_files($sub_directory, $tmp_root, $addon_slug) {
        $files = $this->list_files_in_directory($sub_directory, $addon_slug);
        if (!is_array($files) || empty($files)) {
            error_log('No files found in subdirectory: ' . $sub_directory);
            return false;
        }
        
        $plugin_path = $tmp_root . '/' . $sub_directory;
        if (!wp_mkdir_p($plugin_path)) {
            error_log('Failed to create directory: ' . $plugin_path);
            return false;
        }
        
        $success_count = 0;
        $total_files = count($files);
        
        foreach ($files as $file) {
            if (!is_array($file) || !isset($file['type'])) {
                continue;
            }
            
            if ($file['type'] === 'file') {
                $content = $this->download_file_content($file['url'], $addon_slug);
                if (empty($content)) {
                    error_log('Failed to download file: ' . $file['name'] . ' in ' . $sub_directory);
                    continue;
                }
                
                $file_path = $plugin_path . '/' . $file['name'];
                $result = file_put_contents($file_path, $content);
                
                if ($result === false) {
                    error_log('Failed to write file: ' . $file_path);
                    continue;
                }
                
                $success_count++;
                
            } elseif ($file['type'] === 'dir') {
                $result = $this->download_sub_directory_files($sub_directory . '/' . $file['name'], $tmp_root, $addon_slug);
                if ($result) {
                    $success_count++;
                }
            }
        }
        
        // Return true if at least 80% of files were downloaded successfully
        return ($success_count / $total_files) >= 0.8;
    }
    
    /**
     * Download and replace plugin files
     */
    public function download_and_replace_plugin_files($addon_slug) {
        // Check if domain license is active
        if (!$this->is_domain_license_active()) {
            error_log('Update failed: Domain license is not active');
            return false;
        }
        
        $directory = $addon_slug;
        $files = $this->list_files_in_directory($directory, $addon_slug);
        if (!is_array($files) || empty($files)) {
            error_log('No files returned from GitHub for ' . $directory);
            return false;
        }

        $tmp_dir = WP_CONTENT_DIR . '/' . $addon_slug . '-update-tmp-' . time();
        if (!wp_mkdir_p($tmp_dir)) {
            error_log('Failed to create temporary directory: ' . $tmp_dir);
            return false;
        }
        
        $plugin_base_tmp = $tmp_dir . '/' . $directory;
        if (!wp_mkdir_p($plugin_base_tmp)) {
            error_log('Failed to create plugin temporary directory: ' . $plugin_base_tmp);
            $this->delete_directory($tmp_dir);
            return false;
        }

        $downloaded_files = array();
        $failed_files = array();
        $download_success = true;

        // Download all files first
        foreach ($files as $file) {
            if (!is_array($file) || !isset($file['type'])) {
                continue;
            }
            
            if ($file['type'] === 'file') {
                $content = $this->download_file_content($file['url'], $addon_slug);
                
                if (empty($content)) {
                    $failed_files[] = $file['name'];
                    error_log('Failed to download file: ' . $file['name']);
                    $download_success = false;
                    continue;
                }
                
                $file_path = $plugin_base_tmp . '/' . $file['name'];
                $result = file_put_contents($file_path, $content);
                
                if ($result === false) {
                    $failed_files[] = $file['name'];
                    error_log('Failed to write file: ' . $file_path);
                    $download_success = false;
                    continue;
                }
                
                $downloaded_files[] = $file['name'];
                
            } elseif ($file['type'] === 'dir') {
                $result = $this->download_sub_directory_files($directory . '/' . $file['name'], $tmp_dir, $addon_slug);
                if (!$result) {
                    $failed_files[] = $file['name'];
                    error_log('Failed to download subdirectory: ' . $file['name']);
                    $download_success = false;
                }
            }
        }

        // Check if any files failed
        if (!empty($failed_files) || !$download_success) {
            error_log('Download failed: ' . count($failed_files) . ' files/subdirectories failed');
            $this->delete_directory($tmp_dir);
            return false;
        }

        // Create backup and replace
        $plugin_path = WP_PLUGIN_DIR . '/' . $directory;
        $backup_path = null;
        
        if (file_exists($plugin_path)) {
            $backup_path = WP_CONTENT_DIR . '/' . $addon_slug . '-backup-' . time();
            if (!rename($plugin_path, $backup_path)) {
                error_log('Failed to create backup of existing plugin');
                $this->delete_directory($tmp_dir);
                return false;
            }
        }

        // Replace plugin
        $result = rename($plugin_base_tmp, $plugin_path);
        if (!$result) {
            error_log('Failed to replace plugin directory');
            
            // Restore backup if exists
            if ($backup_path && file_exists($backup_path)) {
                rename($backup_path, $plugin_path);
                error_log('Restored plugin from backup');
            }
            
            $this->delete_directory($tmp_dir);
            return false;
        }

        // Cleanup
        $this->delete_directory($tmp_dir);
        
        error_log('Plugin updated successfully. Backup available at: ' . $backup_path);
        return true;
    }
    
    /**
     * Handle update request
     */
    public function handle_update_request($addon_slug) {
        $result = $this->download_and_replace_plugin_files($addon_slug);
        
        if ($result) {
            // Update successful
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>Plugin updated successfully!</p></div>';
            });
        } else {
            // Update failed
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>Plugin update failed. Please check error logs and try again.</p></div>';
            });
        }
        
        // Redirect back to plugins page
        wp_redirect(admin_url('plugins.php'));
        exit();
    }
    
    /**
     * Get update URL for addon
     */
    public function get_update_url($addon_slug) {
        return admin_url('plugins.php?update_mac=' . $addon_slug);
    }
    
    /**
     * Check if update is available for addon
     */
    public function is_update_available($addon_slug, $github_repo) {
        if (!$this->is_domain_license_active()) {
            return false;
        }
        
        $update_info = $this->check_plugin_update($addon_slug, $github_repo);
        return $update_info && $update_info['available'];
    }
    
    /**
     * Get update info for addon
     */
    public function get_update_info($addon_slug, $github_repo) {
        error_log("=== MAC Core: get_update_info called for {$addon_slug} ===");
        
        if (!$this->is_domain_license_active()) {
            error_log("MAC Core: Domain license not active, skipping update check");
            return false;
        }
        
        $result = $this->check_plugin_update($addon_slug, $github_repo);
        error_log("MAC Core: Update check result for {$addon_slug}: " . ($result ? 'UPDATE AVAILABLE' : 'NO UPDATE'));
        
        return $result;
    }
}
