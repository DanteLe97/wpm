<?php
namespace MAC_Core;

/**
 * CRM API Manager
 * 
 * Handles all API calls to CRM for domain validation, license checking, and domain registration
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CRM_API_Manager {
    
    // API endpoints
    const VALIDATE_KEY_URL = 'https://wpm.macusaone.com/api/v1/menu-license/validate-key';
    const VALIDATE_URL_URL = 'https://wpm.macusaone.com/api/v1/menu-license/validate-url';
    const REGISTER_DOMAIN_URL = 'https://wpm.macusaone.com/api/v1/menu-license/register-domain';
    const PLUGIN_REQUEST_URL_PATTERN = 'https://wpm.macusaone.com/api/v1/plugins/{slug}';
    
    // Timeout for API requests
    const TIMEOUT = 45;
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Initialize options if they don't exist
        $this->initialize_options();
    }
    
    /**
     * Initialize MAC Menu options
     */
    private function initialize_options() {
        if (false === get_option('mac_domain_valid_key')) {
            add_option('mac_domain_valid_key', '');
        }
        if (false === get_option('mac_domain_valid_status')) {
            add_option('mac_domain_valid_status', '');
        }
    }
    
    /**
     * Validate key with CRM
     */
    public function validate_key($key, $domain, $version) {
        if (empty($key)) {
            // Don't reset options for empty key, just return error
            return array('success' => false, 'message' => 'Empty key provided');
        }
        
        $response = wp_remote_post(self::VALIDATE_KEY_URL, array(
            'method' => 'POST',
            'body' => array(
                'key' => $key,
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->process_domain_response($data, $key);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Validate URL with CRM (when no key exists)
     */
    public function validate_url($domain, $version) {
        $response = wp_remote_post(self::VALIDATE_URL_URL, array(
            'method' => 'POST',
            'body' => array(
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->process_domain_response($data);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Register domain with CRM
     */
    public function register_domain($key, $domain, $version) {
        $response = wp_remote_post(self::REGISTER_DOMAIN_URL, array(
            'method' => 'POST',
            'body' => array(
                'key' => $key,
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array('success' => false, 'message' => 'Invalid response format from server');
        }
        
        $this->process_domain_response($data);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Process domain response from CRM
     */
    private function process_domain_response($data, $key = null) {
        if (!isset($data['valid']) || !$data['valid']) {
            $this->reset_domain_options();
            return;
        }
        
        $this->update_domain_options($data);
    }
    
    /**
     * Update domain options
     */
    private function update_domain_options($data) {
        update_option('mac_domain_valid_key', $data['keyDomain']);
        update_option('mac_domain_valid_status', $data['statusDomain']);
    }
    
    /**
     * Reset domain options
     */
    private function reset_domain_options() {
        update_option('mac_domain_valid_key', null);
        update_option('mac_domain_valid_status', null);
    }
    
    /**
     * Get domain status
     */
    public function get_domain_status() {
        return get_option('mac_domain_valid_status', '');
    }
    
    /**
     * Get domain key
     */
    public function get_domain_key() {
        return get_option('mac_domain_valid_key', '');
    }
    
    /**
     * Get GitHub token
     */
    public function get_github_token() {
        return get_option('mac_menu_github_key', '');
    }
    
    /**
     * Check if license is valid
     */
    public function is_license_valid() {
        return (get_option('mac_domain_valid_status', '') === 'activate');
    }

    /**
     * Download a file to a temp path; returns ['success'=>true, 'file'=>path]
     */
    public function download_file_to_tmp($download_url, $timeout = 120) {
        $tmp = wp_tempnam($download_url);
        if (!$tmp) {
            return array('success' => false, 'message' => 'Failed to create temp file');
        }

        $args = array(
            'timeout' => $timeout,
            'sslverify' => true,
            'stream' => true,
            'filename' => $tmp,
            'headers' => array(
                'Accept' => 'application/zip, application/octet-stream'
            ),
        );

        $response = wp_remote_get($download_url, $args);
        if (is_wp_error($response)) {
            @unlink($tmp);
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            @unlink($tmp);
            return array('success' => false, 'message' => 'Download HTTP ' . $code);
        }

        return array('success' => true, 'file' => $tmp);
    }



    public function get_plugin_request_url($slug) {
        $default = str_replace('{slug}', $slug, self::PLUGIN_REQUEST_URL_PATTERN);
        if (function_exists('apply_filters')) {
            $default = apply_filters('mac_core/crm_plugin_request_url', $default, $slug);
        }
        return $default;
    }

    /**
     * Check for plugin updates from CRM
     * Returns: ['success'=>true, 'data'=>['version', 'needs_update', 'current_version']]
     */
    public function check_update($slug) {
        $url = $this->get_plugin_request_url($slug);

        $site_url = get_site_url();
        $license_key = get_option('mac_domain_valid_key', '');

        $body = array(
            'url' => $site_url,
            'key' => $license_key,
            'action' => 'check_update'
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ),
            'body' => $body,
        );

        $response = wp_remote_post($url, $args);
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_str = wp_remote_retrieve_body($response);
        if ($code !== 200) {
            return array('success' => false, 'message' => 'CRM request HTTP ' . $code);
        }

        $data = json_decode($body_str, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            return array('success' => false, 'message' => 'Invalid CRM response');
        }

        // Get current version from installed plugin
        $current_version = $this->get_plugin_version($slug);
        
        // Compare versions
        $needs_update = false;
        if (!empty($data['version']) && !empty($current_version)) {
            $needs_update = version_compare($data['version'], $current_version, '>');
        }

        return array(
            'success' => true, 
            'data' => array(
                'version' => isset($data['version']) ? $data['version'] : '',
                'current_version' => $current_version,
                'needs_update' => $needs_update
            )
        );
    }

    /**
     * Request download URL for plugin installation/update
     * Returns: ['success'=>true, 'data'=>['download_url', 'version']]
     */
    public function download_plugin($slug) {
        $url = $this->get_plugin_request_url($slug);

        $site_url = get_site_url();
        $license_key = get_option('mac_domain_valid_key', '');

        $body = array(
            'url' => $site_url,
            'key' => $license_key,
            'action' => 'download'
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ),
            'body' => $body,
        );

        $response = wp_remote_post($url, $args);
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_str = wp_remote_retrieve_body($response);
        if ($code !== 200) {
            return array('success' => false, 'message' => 'CRM request HTTP ' . $code);
        }

        $data = json_decode($body_str, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            return array('success' => false, 'message' => 'Invalid CRM response');
        }

        if (empty($data['download_url'])) {
            return array('success' => false, 'message' => 'CRM response missing download_url');
        }

        return array('success' => true, 'data' => $data);
    }

    /**
     * Get current version of installed plugin
     */
    private function get_plugin_version($slug) {
        if ($slug === 'mac-menu') {
            $plugin_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
            if (file_exists($plugin_file)) {
                $plugin_data = get_plugin_data($plugin_file);
                return isset($plugin_data['Version']) ? $plugin_data['Version'] : '';
            }
        }
        return '';
    }
}
