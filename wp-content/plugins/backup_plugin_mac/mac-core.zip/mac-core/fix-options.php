<?php
/**
 * Fix MAC Menu Options Script
 * 
 * This script fixes the options that were incorrectly initialized with '0' instead of empty values
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Only run if user is admin
if (!current_user_can('manage_options')) {
    wp_die('Unauthorized access');
}

// Fix options
function fix_mac_menu_options() {
    error_log('=== MAC Menu: Fixing options script started ===');
    
    // Get current values
    $current_key = get_option('mac_domain_valid_key', '');
    $current_status = get_option('mac_domain_valid_status', '');
    
    error_log('MAC Menu: Current key before fix: ' . $current_key);
    error_log('MAC Menu: Current status before fix: ' . $current_status);
    
    // Fix key if it's '0'
    if ($current_key === '0') {
        update_option('mac_domain_valid_key', '');
        error_log('MAC Menu: Fixed mac_domain_valid_key from "0" to empty');
    }
    
    // Fix status if it's '0'
    if ($current_status === '0') {
        update_option('mac_domain_valid_status', '');
        error_log('MAC Menu: Fixed mac_domain_valid_status from "0" to empty');
    }
    
    // Get values after fix
    $new_key = get_option('mac_domain_valid_key', '');
    $new_status = get_option('mac_domain_valid_status', '');
    
    error_log('MAC Menu: New key after fix: ' . $new_key);
    error_log('MAC Menu: New status after fix: ' . $new_status);
    error_log('=== MAC Menu: Fixing options script completed ===');
    
    return array(
        'old_key' => $current_key,
        'old_status' => $current_status,
        'new_key' => $new_key,
        'new_status' => $new_status
    );
}

// Run the fix if this file is accessed directly
if (basename($_SERVER['SCRIPT_NAME']) === 'fix-options.php') {
    $result = fix_mac_menu_options();
    
    echo '<h2>MAC Menu Options Fix Results</h2>';
    echo '<p><strong>Old Key:</strong> ' . htmlspecialchars($result['old_key']) . '</p>';
    echo '<p><strong>Old Status:</strong> ' . htmlspecialchars($result['old_status']) . '</p>';
    echo '<p><strong>New Key:</strong> ' . htmlspecialchars($result['new_key']) . '</p>';
    echo '<p><strong>New Status:</strong> ' . htmlspecialchars($result['new_status']) . '</p>';
    echo '<p><em>Check error log for detailed information.</em></p>';
}
?>

