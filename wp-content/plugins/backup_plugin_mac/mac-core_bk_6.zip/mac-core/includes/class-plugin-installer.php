<?php
/**
 * MAC Core Plugin Installer
 * 
 * Handles downloading and installing plugins from GitHub repositories
 */

namespace MAC_Core;

class Plugin_Installer {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add AJAX handlers
        add_action('wp_ajax_mac_core_install_plugin', array($this, 'handle_install_plugin_ajax'));
        add_action('wp_ajax_mac_core_check_install_status', array($this, 'handle_check_install_status_ajax'));
        add_action('wp_ajax_mac_core_check_system_requirements', array($this, 'handle_check_system_requirements_ajax'));
        add_action('wp_ajax_mac_core_debug_tokens', array($this, 'handle_debug_tokens_ajax'));
        add_action('wp_ajax_mac_core_test_token', array($this, 'handle_test_token_ajax'));
        add_action('wp_ajax_mac_core_activate_plugin', array($this, 'handle_activate_plugin_ajax'));
        add_action('wp_ajax_mac_core_force_remove_plugin', array($this, 'handle_force_remove_plugin_ajax'));
        add_action('wp_ajax_mac_core_check_options_status', array($this, 'handle_check_options_status_ajax'));
        add_action('wp_ajax_mac_core_check_url', array($this, 'handle_check_url_ajax'));
        add_action('wp_ajax_mac_core_test_validate_url', array($this, 'handle_test_validate_url_ajax'));
        add_action('wp_ajax_mac_core_install_mac_menu', array($this, 'handle_install_mac_menu_ajax'));
        add_action('wp_ajax_mac_core_activate_mac_menu', array($this, 'handle_activate_mac_menu_ajax'));
        add_action('wp_ajax_mac_core_update_mac_menu', array($this, 'handle_update_mac_menu_ajax'));
        add_action('wp_ajax_mac_core_reset_options', array($this, 'handle_reset_options_ajax'));
        add_action('wp_ajax_mac_core_restore_mac_core', array($this, 'handle_restore_mac_core_ajax'));
        // Removed custom force delete handler; rely on WP delete_plugins
    }
    
    /**
     * Get plugin configuration
     */
    public function get_plugin_config($addon_slug) {
        $mac_core_addons = array(
            'mac-menu' => array(
                'name' => 'MAC Menu',
                'description' => 'Create beautiful menu tables for your restaurant website.',
                'slug' => 'mac-menu',
                'file' => 'mac-menu/mac-menu.php',
                'github_repo' => 'DanteLe97/MAC_MENU',
                'github_token_option' => 'mac_menu_github_key'
            ),
            'mac-reservation' => array(
                'name' => 'MAC Reservation', 
                'description' => 'Manage restaurant reservations and table bookings.',
                'slug' => 'mac-reservation',
                'file' => 'mac-reservation/mac-reservation.php',
                'github_repo' => 'DanteLe97/MAC_RESERVATION',
                'github_token_option' => 'mac_reservation_github_key'
            ),
            'mac-delivery' => array(
                'name' => 'MAC Delivery',
                'description' => 'Handle food delivery orders and tracking.',
                'slug' => 'mac-delivery',
                'file' => 'mac-delivery/mac-delivery.php',
                'github_repo' => 'DanteLe97/MAC_DELIVERY',
                'github_token_option' => 'mac_delivery_github_key'
            ),
            'mac-loyalty' => array(
                'name' => 'MAC Loyalty',
                'description' => 'Customer loyalty program and rewards system.',
                'slug' => 'mac-loyalty',
                'file' => 'mac-loyalty/mac-loyalty.php',
                'github_repo' => 'DanteLe97/MAC_LOYALTY',
                'github_token_option' => 'mac_loyalty_github_key'
            )
        );
        
        return isset($mac_core_addons[$addon_slug]) ? $mac_core_addons[$addon_slug] : false;
    }
    
    /**
     * Check if plugin is already installed
     */
    public function is_plugin_installed($addon_slug) {
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            return false;
        }
        
        $plugin_file = WP_PLUGIN_DIR . '/' . $config['file'];
        return file_exists($plugin_file);
    }
    
    /**
     * Check if plugin is active
     */
    public function is_plugin_active($addon_slug) {
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            return false;
        }
        
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        return is_plugin_active($config['file']);
    }
    
    /**
     * Get GitHub token for plugin
     */
    public function get_github_token($addon_slug) {
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            error_log('MAC Core: Plugin config not found for ' . $addon_slug);
            return false;
        }
        
        $token = get_option($config['github_token_option'], '');
        error_log('MAC Core: GitHub token for ' . $addon_slug . ': ' . ($token ? 'FOUND' : 'NOT FOUND'));
        error_log('MAC Core: Token option name: ' . $config['github_token_option']);
        
        return $token;
    }
    
    /**
     * GitHub API call with retry mechanism
     */
    private function github_wp_get($url, $addon_slug, $retries = 3) {
        $github_token = $this->get_github_token($addon_slug);
        
        for ($i = 0; $i < $retries; $i++) {
            $args = array(
                'headers' => array(
                    'Authorization' => 'token ' . $github_token,
                    'User-Agent'    => 'WordPress Plugin',
                    'Accept'        => 'application/vnd.github.v3+json',
                ),
                'timeout' => 60,
            );
            
            $response = wp_remote_get($url, $args);
            
            if (!is_wp_error($response)) {
                $code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);
                
                if ($code === 200) {
                    return $body;
                }
                
                error_log("GitHub HTTP {$code} for {$url} (attempt " . ($i + 1) . ")");
            } else {
                error_log('GitHub request error (attempt ' . ($i + 1) . '): ' . $response->get_error_message());
            }
            
            // Wait before retry (except for last attempt)
            if ($i < $retries - 1) {
                sleep(2);
            }
        }
        
        error_log("GitHub request failed after {$retries} attempts for {$url}");
        return false;
    }
    
    /**
     * List files in GitHub directory
     */
    private function list_files_in_directory($addon_slug, $directory) {
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            return array();
        }
        
        $url = 'https://api.github.com/repos/' . $config['github_repo'] . '/contents/' . ltrim($directory, '/');
        $body = $this->github_wp_get($url, $addon_slug);
        
        if ($body === false) {
            return array();
        }
        
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            error_log('list_files_in_directory JSON error: ' . json_last_error_msg());
            return array();
        }
        return $data;
    }
    
    /**
     * Download file content from GitHub
     */
    private function download_file_content($file_url, $addon_slug) {
        $body = $this->github_wp_get($file_url, $addon_slug);
        if ($body === false) {
            error_log('Failed to download file content from: ' . $file_url);
            return '';
        }
        
        $file_info = json_decode($body, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($file_info['content'])) {
            $content = base64_decode($file_info['content']);
            
            // Validate decoded content
            if ($content === false) {
                error_log('Failed to decode base64 content from: ' . $file_url);
                return '';
            }
            
            return $content;
        }
        
        error_log('Invalid file info format from: ' . $file_url);
        return '';
    }
    
    /**
     * Download subdirectory files recursively
     */
    private function download_sub_directory_files($addon_slug, $sub_directory, $tmp_root) {
        $files = $this->list_files_in_directory($addon_slug, $sub_directory);
        if (!is_array($files) || empty($files)) {
            error_log('No files found in subdirectory: ' . $sub_directory);
            return false;
        }
        
        $plugin_path = $tmp_root . '/' . $sub_directory;
        if (!wp_mkdir_p($plugin_path)) {
            error_log('Failed to create directory: ' . $plugin_path);
            return false;
        }
        
        $success_count = 0;
        $total_files = count($files);
        
        foreach ($files as $file) {
            if (!is_array($file) || !isset($file['type'])) {
                continue;
            }
            
            if ($file['type'] === 'file') {
                $content = $this->download_file_content($file['url'], $addon_slug);
                if (empty($content)) {
                    error_log('Failed to download file: ' . $file['name'] . ' in ' . $sub_directory);
                    continue;
                }
                
                $file_path = $plugin_path . '/' . $file['name'];
                $result = file_put_contents($file_path, $content);
                
                if ($result === false) {
                    error_log('Failed to write file: ' . $file_path);
                    continue;
                }
                
                $success_count++;
                
            } elseif ($file['type'] === 'dir') {
                $result = $this->download_sub_directory_files($addon_slug, $sub_directory . '/' . $file['name'], $tmp_root);
                if ($result) {
                    $success_count++;
                }
            }
        }
        
        // Return true if at least 80% of files were downloaded successfully
        return ($success_count / $total_files) >= 0.8;
    }
    
    /**
     * Delete directory recursively
     */
    private function delete_directory($dir) {
        if (is_dir($dir)) {
            $objects = array_diff(scandir($dir), array('.', '..'));
            foreach ($objects as $object) {
                $file = $dir . '/' . $object;
                (is_dir($file)) ? $this->delete_directory($file) : unlink($file);
            }
            rmdir($dir);
        }
    }
    
    /**
     * Download plugin from GitHub using file-by-file method
     */
    public function download_plugin_from_github($addon_slug) {
        error_log('MAC Core: Starting download for ' . $addon_slug);
        
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            error_log('MAC Core: Plugin configuration not found for ' . $addon_slug);
            return array(
                'success' => false,
                'message' => 'Plugin configuration not found.'
            );
        }
        
        $github_token = $this->get_github_token($addon_slug);
        if (empty($github_token)) {
            error_log('MAC Core: GitHub token not found for ' . $addon_slug);
            return array(
                'success' => false,
                'message' => 'GitHub token not found. Please check your license key and domain validation.'
            );
        }
        
        // Get files from GitHub repository
        $directory = $config['slug'];
        error_log('MAC Core: Getting files from directory: ' . $directory);
        $files = $this->list_files_in_directory($addon_slug, $directory);
        if (!is_array($files) || empty($files)) {
            error_log('MAC Core: No files found in GitHub repository for ' . $directory);
            return array(
                'success' => false,
                'message' => 'No files found in GitHub repository.'
            );
        }
        
        error_log('MAC Core: Found ' . count($files) . ' files in repository');
        
        // Create temporary directory
        $tmp_dir = WP_CONTENT_DIR . '/' . $addon_slug . '-install-tmp-' . time();
        error_log('MAC Core: Creating temp directory: ' . $tmp_dir);
        if (!wp_mkdir_p($tmp_dir)) {
            error_log('MAC Core: Failed to create temporary directory: ' . $tmp_dir);
            return array(
                'success' => false,
                'message' => 'Failed to create temporary directory.'
            );
        }
        
        $plugin_base_tmp = $tmp_dir . '/' . $directory;
        error_log('MAC Core: Creating plugin temp directory: ' . $plugin_base_tmp);
        if (!wp_mkdir_p($plugin_base_tmp)) {
            error_log('MAC Core: Failed to create plugin temporary directory: ' . $plugin_base_tmp);
            $this->delete_directory($tmp_dir);
            return array(
                'success' => false,
                'message' => 'Failed to create plugin temporary directory.'
            );
        }
        
        $downloaded_files = array();
        $failed_files = array();
        $download_success = true;
        
        // Download all files
        foreach ($files as $file) {
            if (!is_array($file) || !isset($file['type'])) {
                continue;
            }
            
            if ($file['type'] === 'file') {
                $content = $this->download_file_content($file['url'], $addon_slug);
                
                if (empty($content)) {
                    $failed_files[] = $file['name'];
                    error_log('Failed to download file: ' . $file['name']);
                    $download_success = false;
                    continue;
                }
                
                $file_path = $plugin_base_tmp . '/' . $file['name'];
                $result = file_put_contents($file_path, $content);
                
                if ($result === false) {
                    $failed_files[] = $file['name'];
                    error_log('Failed to write file: ' . $file_path);
                    $download_success = false;
                    continue;
                }
                
                $downloaded_files[] = $file['name'];
                
            } elseif ($file['type'] === 'dir') {
                $result = $this->download_sub_directory_files($addon_slug, $directory . '/' . $file['name'], $tmp_dir);
                if (!$result) {
                    $failed_files[] = $file['name'];
                    error_log('Failed to download subdirectory: ' . $file['name']);
                    $download_success = false;
                }
            }
        }
        
        // Check if download was successful
        if (!empty($failed_files) || !$download_success) {
            error_log('MAC Core: Download failed: ' . count($failed_files) . ' files/subdirectories failed');
            error_log('MAC Core: Failed files: ' . implode(', ', $failed_files));
            error_log('MAC Core: Successfully downloaded: ' . implode(', ', $downloaded_files));
            $this->delete_directory($tmp_dir);
            return array(
                'success' => false,
                'message' => 'Failed to download plugin files. Please try again.'
            );
        }
        
        error_log('MAC Core: Download completed successfully. Total files: ' . count($downloaded_files));
        return array(
            'success' => true,
            'temp_dir' => $tmp_dir,
            'plugin_dir' => $plugin_base_tmp,
            'version' => 'latest'
        );
    }
    
    /**
     * Clean up conflicting plugin files
     */
    private function cleanup_conflicting_files($addon_slug) {
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            return;
        }
        
        // Only clean up the target plugin directory, never touch MAC Core
        $plugin_dir = WP_PLUGIN_DIR . '/' . $config['slug'];
        if (is_dir($plugin_dir)) {
            error_log('MAC Core: Cleaning up existing plugin directory: ' . $plugin_dir);
            $this->delete_directory($plugin_dir);
        }
        
        // For MAC Menu, only clean up MAC Menu files, never touch MAC Core
        if ($addon_slug === 'mac-menu') {
            $mac_menu_files = array(
                WP_PLUGIN_DIR . '/mac-menu/domain-manager.php',
                WP_PLUGIN_DIR . '/mac-menu/mac-menu.php'
            );
            
            foreach ($mac_menu_files as $file) {
                if (file_exists($file)) {
                    error_log('MAC Core: Removing conflicting MAC Menu file: ' . $file);
                    unlink($file);
                }
            }
            
            // Fix potential output issues in MAC Menu main file
            $this->fix_mac_menu_output_issues();
        }
    }
    
    /**
     * Install plugin from downloaded files
     */
    public function install_plugin($addon_slug) {
        error_log('MAC Core: Starting installation for ' . $addon_slug);
        
        // Clean up any conflicting files first
        $this->cleanup_conflicting_files($addon_slug);
        
        // Check if plugin is already installed
        if ($this->is_plugin_installed($addon_slug)) {
            error_log('MAC Core: Plugin already installed');
            return array(
                'success' => false,
                'message' => 'Plugin is already installed.'
            );
        }
        
        // Download plugin
        $download_result = $this->download_plugin_from_github($addon_slug);
        if (!$download_result['success']) {
            error_log('MAC Core: Download failed: ' . $download_result['message']);
            return $download_result;
        }
        
        $temp_dir = $download_result['temp_dir'];
        $plugin_dir = $download_result['plugin_dir'];
        $config = $this->get_plugin_config($addon_slug);
        
        // Move plugin to final location
        $final_plugin_path = WP_PLUGIN_DIR . '/' . $config['slug'];
        error_log('MAC Core: Moving plugin to: ' . $final_plugin_path);
        
        // Check if destination already exists
        if (file_exists($final_plugin_path)) {
            error_log('MAC Core: Removing existing plugin directory');
            $this->delete_directory($final_plugin_path);
        }
        
        // Move the plugin directory
        $result = rename($plugin_dir, $final_plugin_path);
        
        if (!$result) {
            error_log('MAC Core: Failed to move plugin directory. Error: ' . error_get_last()['message']);
            $this->delete_directory($temp_dir);
            return array(
                'success' => false,
                'message' => 'Failed to move plugin to final location. Please check file permissions.'
            );
        }
        
        // Clean up temporary directory
        error_log('MAC Core: Cleaning up temp directory');
        $this->delete_directory($temp_dir);
        
        error_log('MAC Core: Plugin installation completed successfully');
        return array(
            'success' => true,
            'message' => 'Plugin installed successfully!',
            'version' => $download_result['version']
        );
    }
    
    /**
     * Activate plugin after installation
     */
    public function activate_plugin($addon_slug) {
        error_log('MAC Core: Starting activation for ' . $addon_slug);
        
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            error_log('MAC Core: Plugin configuration not found for ' . $addon_slug);
            return array(
                'success' => false,
                'message' => 'Plugin configuration not found.'
            );
        }
        
        // Check if plugin file exists
        $plugin_file = WP_PLUGIN_DIR . '/' . $config['file'];
        if (!file_exists($plugin_file)) {
            error_log('MAC Core: Plugin file not found: ' . $plugin_file);
            return array(
                'success' => false,
                'message' => 'Plugin file not found: ' . $config['file']
            );
        }
        
        // Check if plugin is already active
        if ($this->is_plugin_active($addon_slug)) {
            error_log('MAC Core: Plugin is already active');
            return array(
                'success' => true,
                'message' => 'Plugin is already active.'
            );
        }
        
        // Check plugin requirements
        $requirements = $this->check_plugin_requirements($addon_slug);
        if (isset($requirements['errors']) && !empty($requirements['errors'])) {
            error_log('MAC Core: Plugin requirements not met: ' . implode(', ', $requirements['errors']));
            return array(
                'success' => false,
                'message' => 'Plugin requirements not met: ' . implode(', ', $requirements['errors'])
            );
        }
        
        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        // Deactivate any conflicting plugins first
        if (is_plugin_active('mac-menu/mac-menu.php')) {
            error_log('MAC Core: Deactivating existing mac-menu plugin');
            deactivate_plugins('mac-menu/mac-menu.php');
        }
        
        // Clean up any remaining conflicting files
        $this->cleanup_conflicting_files($addon_slug);
        
        // Clear function and class cache for MAC Menu
        if ($addon_slug === 'mac-menu') {
            // Force WordPress to reload function and class definitions
            if (function_exists('wp_cache_flush')) {
                wp_cache_flush();
            }
            
            // Clear autoloader cache
            if (function_exists('spl_autoload_functions')) {
                $autoloaders = spl_autoload_functions();
                foreach ($autoloaders as $autoloader) {
                    spl_autoload_unregister($autoloader);
                }
            }
            
            error_log('MAC Core: Cleared function and class cache for MAC Menu activation');
        }
        
        // Check for function conflicts
        $function_conflicts = $this->check_function_conflicts();
        $constant_conflicts = $this->check_constant_conflicts();
        
        if (!empty($function_conflicts) || !empty($constant_conflicts)) {
            $all_conflicts = array_merge($function_conflicts, $constant_conflicts);
            error_log('MAC Core: Conflicts detected: ' . implode(', ', $all_conflicts));
            
            // For MAC Menu, try to fix constant conflicts by redefining them
            if ($addon_slug === 'mac-menu' && !empty($constant_conflicts)) {
                error_log('MAC Core: Attempting to fix constant conflicts for MAC Menu');
                $this->fix_constant_conflicts();
            }
            
            return array(
                'success' => false,
                'message' => 'Conflicts detected. Please deactivate conflicting plugins first: ' . implode(', ', $all_conflicts)
            );
        }
        
        error_log('MAC Core: Activating plugin: ' . $config['file']);
        
        // Capture any output during activation
        ob_start();
        $result = activate_plugin($config['file']);
        $output = ob_get_clean();
        
        // Log any unexpected output
        if (!empty($output)) {
            error_log('MAC Core: Unexpected output during activation: ' . $output);
        }
        
        if (is_wp_error($result)) {
            error_log('MAC Core: Activation failed: ' . $result->get_error_message());
            
            // For MAC Menu, try to force activate by ignoring output
            if ($addon_slug === 'mac-menu' && strpos($result->get_error_message(), 'unexpected output') !== false) {
                error_log('MAC Core: Attempting to force activate MAC Menu despite output issues');
                
                // Try to activate again with output buffering
                ob_start();
                $force_result = activate_plugin($config['file'], '', false, true);
                ob_end_clean();
                
                if (!is_wp_error($force_result)) {
                    error_log('MAC Core: Force activation successful');
                    return array(
                        'success' => true,
                        'message' => 'Plugin activated successfully! (Force activated due to output issues)',
                        'force_activated' => true
                    );
                }
                
                // If force activation still fails, try to manually activate by updating options
                error_log('MAC Core: Force activation failed, trying manual activation');
                $manual_result = $this->manual_activate_plugin($addon_slug);
                if ($manual_result['success']) {
                    return array(
                        'success' => true,
                        'message' => 'Plugin activated successfully! (Manually activated due to output issues)',
                        'force_activated' => true,
                        'manual_activation' => true
                    );
                }
            }
            
            return array(
                'success' => false,
                'message' => 'Activation failed: ' . $result->get_error_message()
            );
        }
        
        error_log('MAC Core: Plugin activated successfully');
        
        // Force reload to clear function and class cache
        if ($addon_slug === 'mac-menu') {
            error_log('MAC Core: Forcing reload to clear function and class cache');
            
            // Restore MAC Core files after successful activation
            $this->restore_compatibility_file($addon_slug);
            
            return array(
                'success' => true,
                'message' => 'Plugin activated successfully! Please refresh the page to complete activation.',
                'reload_required' => true,
                'force_restart' => true
            );
        }
        
        return array(
            'success' => true,
            'message' => 'Plugin activated successfully!'
        );
    }
    
    /**
     * Handle AJAX install request
     */
    public function handle_install_plugin_ajax() {
        error_log('=== MAC Core: Starting plugin installation ===');
        
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            error_log('MAC Core: Security check failed');
            wp_send_json_error('Security check failed.');
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            error_log('MAC Core: Insufficient permissions');
            wp_send_json_error('Insufficient permissions.');
        }
        
        $addon_slug = sanitize_text_field($_POST['plugin_slug']);
        error_log('MAC Core: Installing plugin: ' . $addon_slug);
        
        // Check if plugin is already installed
        if ($this->is_plugin_installed($addon_slug)) {
            error_log('MAC Core: Plugin already installed');
            wp_send_json_error('Plugin is already installed.');
        }
        
        // Check GitHub token
        $github_token = $this->get_github_token($addon_slug);
        if (empty($github_token)) {
            error_log('MAC Core: GitHub token not found for ' . $addon_slug);
            wp_send_json_error('GitHub token not found. Please check your license key and domain validation.');
        }
        error_log('MAC Core: GitHub token found');
        
        // Install plugin
        $result = $this->install_plugin($addon_slug);
        
        if ($result['success']) {
            error_log('MAC Core: Plugin installation successful');
            
            // Try to activate the plugin
            $activate_result = $this->activate_plugin($addon_slug);
            if ($activate_result['success']) {
                $result['message'] .= ' Plugin activated successfully!';
                error_log('MAC Core: Plugin activation successful');
                wp_send_json_success($result);
            } else {
                error_log('MAC Core: Plugin activation failed: ' . $activate_result['message']);
                // Installation succeeded but activation failed
                $result['message'] .= ' Plugin installed but activation failed: ' . $activate_result['message'];
                $result['activation_failed'] = true;
                $result['activation_error'] = $activate_result['message'];
                wp_send_json_success($result);
            }
        } else {
            error_log('MAC Core: Plugin installation failed: ' . $result['message']);
            wp_send_json_error($result['message']);
        }
        
        error_log('=== MAC Core: Plugin installation completed ===');
    }
    

    
    /**
     * Handle AJAX status check
     */
    public function handle_check_install_status_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $addon_slug = sanitize_text_field($_POST['plugin_slug']);
        
        $status = array(
            'installed' => $this->is_plugin_installed($addon_slug),
            'active' => $this->is_plugin_active($addon_slug),
            'has_token' => !empty($this->get_github_token($addon_slug))
        );
        
        wp_send_json_success($status);
    }
    
    /**
     * Check system requirements and permissions
     */
    public function check_system_requirements() {
        $requirements = array();
        
        // Check if wp-content/plugins is writable
        $plugins_dir = WP_PLUGIN_DIR;
        $requirements['plugins_dir_writable'] = is_writable($plugins_dir);
        $requirements['plugins_dir_path'] = $plugins_dir;
        
        // Check if wp-content is writable (for temp files)
        $content_dir = WP_CONTENT_DIR;
        $requirements['content_dir_writable'] = is_writable($content_dir);
        $requirements['content_dir_path'] = $content_dir;
        
        // Check PHP version
        $requirements['php_version'] = PHP_VERSION;
        $requirements['php_version_ok'] = version_compare(PHP_VERSION, '7.0', '>=');
        
        // Check memory limit
        $memory_limit = ini_get('memory_limit');
        $requirements['memory_limit'] = $memory_limit;
        
        // Check max execution time
        $max_execution_time = ini_get('max_execution_time');
        $requirements['max_execution_time'] = $max_execution_time;
        
        // Check if curl is available
        $requirements['curl_available'] = function_exists('curl_init');
        
        // Check if file_get_contents can access URLs
        $requirements['allow_url_fopen'] = ini_get('allow_url_fopen');
        
        return $requirements;
    }
    
    /**
     * Debug all GitHub tokens
     */
    public function debug_github_tokens() {
        $tokens = array();
        $mac_core_addons = array(
            'mac-menu' => 'mac_menu_github_key',
            'mac-reservation' => 'mac_reservation_github_key',
            'mac-delivery' => 'mac_delivery_github_key',
            'mac-loyalty' => 'mac_loyalty_github_key'
        );
        
        foreach ($mac_core_addons as $addon => $option) {
            $token = get_option($option, '');
            $tokens[$addon] = array(
                'option_name' => $option,
                'has_token' => !empty($token),
                'token_length' => strlen($token),
                'token_preview' => !empty($token) ? substr($token, 0, 10) . '...' : 'empty'
            );
        }
        
        // Also check license and domain status
        $license_key = get_option('mac_license_key', '');
        $domain_status = get_option('mac_domain_valid_status', '');
        $domain_key = get_option('mac_domain_valid_key', '');
        
        $tokens['_system'] = array(
            'license_key' => !empty($license_key) ? 'FOUND (' . strlen($license_key) . ' chars)' : 'NOT FOUND',
            'domain_status' => $domain_status,
            'domain_key' => !empty($domain_key) ? 'FOUND' : 'NOT FOUND'
        );
        
        return $tokens;
    }
    
    /**
     * Check plugin dependencies and requirements
     */
    public function check_plugin_requirements($addon_slug) {
        $requirements = array();
        
        // Check if MAC Core is active (required for all plugins)
        if (!class_exists('MAC_Core\Admin')) {
            $requirements['mac_core_active'] = false;
            $requirements['errors'][] = 'MAC Core plugin is not active';
        } else {
            $requirements['mac_core_active'] = true;
        }
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.0', '<')) {
            $requirements['php_version_ok'] = false;
            $requirements['errors'][] = 'PHP version ' . PHP_VERSION . ' is too old. Need 7.0+';
        } else {
            $requirements['php_version_ok'] = true;
        }
        
        // Check WordPress version
        global $wp_version;
        if (version_compare($wp_version, '5.0', '<')) {
            $requirements['wp_version_ok'] = false;
            $requirements['errors'][] = 'WordPress version ' . $wp_version . ' is too old. Need 5.0+';
        } else {
            $requirements['wp_version_ok'] = true;
        }
        
        // Check if Elementor is active (for MAC Menu)
        if ($addon_slug === 'mac-menu') {
            if (!class_exists('Elementor\Plugin')) {
                $requirements['elementor_active'] = false;
                $requirements['warnings'][] = 'Elementor plugin is not active (recommended for MAC Menu)';
            } else {
                $requirements['elementor_active'] = true;
            }
        }
        
        return $requirements;
    }
    
    /**
     * Check for function conflicts
     */
    private function check_function_conflicts() {
        $conflicts = array();
        
        // Check for conflicting functions
        $conflicting_functions = array(
            'kvp_enqueue_scripts',
            'kvp_handle_check_request',
            'kvp_handle_check_request_url',
            'kvp_handle_ajax_request'
        );
        
        foreach ($conflicting_functions as $function) {
            if (function_exists($function)) {
                $conflicts[] = $function;
            }
        }
        
        return $conflicts;
    }
    
    /**
     * Remove conflicting functions
     */
    private function remove_conflicting_functions() {
        $conflicts = $this->check_function_conflicts();
        
        if (!empty($conflicts)) {
            error_log('MAC Core: Found conflicting functions: ' . implode(', ', $conflicts));
            
            // Note: We can't actually remove functions in PHP, but we can log them
            // The real solution is to prevent them from being declared in the first place
            foreach ($conflicts as $function) {
                error_log('MAC Core: Function conflict detected: ' . $function);
            }
        }
        
        return $conflicts;
    }
    
    /**
     * Check for constant conflicts
     */
    private function check_constant_conflicts() {
        $conflicts = array();
        
        // Check for conflicting constants
        $conflicting_constants = array(
            'MAC_MENU_VALIDATE_KEY',
            'MAC_MENU_VALIDATE_URL',
            'MAC_MENU_REGISTER_DOMAIN'
        );
        
        foreach ($conflicting_constants as $constant) {
            if (defined($constant)) {
                $conflicts[] = $constant;
            }
        }
        
        return $conflicts;
    }
    
    /**
     * Fix constant conflicts by redefining them
     */
    private function fix_constant_conflicts() {
        // Note: We cannot undefine constants in PHP, but we can log the issue
        error_log('MAC Core: Constant conflicts detected - MAC Menu will define its own constants');
        error_log('MAC Core: This is expected behavior and should not cause activation failure');
    }
    
    /**
     * Fix potential output issues in MAC Menu files
     */
    private function fix_mac_menu_output_issues() {
        $mac_menu_file = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        $domain_manager_file = WP_PLUGIN_DIR . '/mac-menu/domain-manager.php';
        $update_plugin_file = WP_PLUGIN_DIR . '/mac-menu/update-plugin.php';
        
        if (file_exists($mac_menu_file)) {
            error_log('MAC Core: Checking MAC Menu main file for output issues');
            
            // Read the file content
            $content = file_get_contents($mac_menu_file);
            
            // Check for potential output issues
            if (strpos($content, 'echo') !== false || strpos($content, 'print') !== false) {
                error_log('MAC Core: Found potential output statements in MAC Menu main file');
                error_log('MAC Core: This may cause "unexpected output" error during activation');
            }
            
            // Check for constants that need protection
            if (strpos($content, 'define(') !== false && strpos($content, 'if (!defined(') === false) {
                error_log('MAC Core: Found unprotected constants in MAC Menu main file');
                error_log('MAC Core: This may cause "constant already defined" warnings');
            }
        }
        
        if (file_exists($domain_manager_file)) {
            error_log('MAC Core: Checking MAC Menu domain manager file for output issues');
            
            // Read the file content
            $content = file_get_contents($domain_manager_file);
            
            // Check for potential output issues
            if (strpos($content, 'echo') !== false || strpos($content, 'print') !== false) {
                error_log('MAC Core: Found potential output statements in MAC Menu domain manager file');
                error_log('MAC Core: This may cause "unexpected output" error during activation');
            }
        }
        
        if (file_exists($update_plugin_file)) {
            error_log('MAC Core: Checking MAC Menu update plugin file for output issues');
            
            // Read the file content
            $content = file_get_contents($update_plugin_file);
            
            // Check for potential output issues
            if (strpos($content, 'echo') !== false || strpos($content, 'print') !== false) {
                error_log('MAC Core: Found potential output statements in MAC Menu update plugin file');
                error_log('MAC Core: This may cause "unexpected output" error during activation');
            }
            
            // Check for constants that need protection
            if (strpos($content, 'define(') !== false && strpos($content, 'if (!defined(') === false) {
                error_log('MAC Core: Found unprotected constants in MAC Menu update plugin file');
                error_log('MAC Core: This may cause "constant already defined" warnings');
            }
        }
    }
    
    /**
     * Manually activate plugin by updating WordPress options
     */
    private function manual_activate_plugin($addon_slug) {
        error_log('MAC Core: Attempting manual activation for ' . $addon_slug);
        
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            return array('success' => false, 'message' => 'Plugin configuration not found');
        }
        
        // Get active plugins
        $active_plugins = get_option('active_plugins', array());
        
        // Add plugin to active plugins list
        if (!in_array($config['file'], $active_plugins)) {
            $active_plugins[] = $config['file'];
            update_option('active_plugins', $active_plugins);
            error_log('MAC Core: Added ' . $config['file'] . ' to active plugins');
        }
        
        // Also update active_sitewide_plugins for multisite
        if (is_multisite()) {
            $active_sitewide_plugins = get_site_option('active_sitewide_plugins', array());
            $active_sitewide_plugins[$config['file']] = time();
            update_site_option('active_sitewide_plugins', $active_sitewide_plugins);
            error_log('MAC Core: Added ' . $config['file'] . ' to active sitewide plugins');
        }
        
        error_log('MAC Core: Manual activation completed for ' . $addon_slug);
        return array('success' => true, 'message' => 'Plugin manually activated');
    }
    
    /**
     * Test GitHub token validity
     */
    public function test_github_token($addon_slug) {
        $github_token = $this->get_github_token($addon_slug);
        if (empty($github_token)) {
            return array(
                'success' => false,
                'message' => 'GitHub token not found.'
            );
        }
        
        $response = wp_remote_get('https://api.github.com/user', array(
            'headers' => array(
                'Authorization' => 'token ' . $github_token,
                'User-Agent' => 'WordPress Plugin',
                'Accept' => 'application/vnd.github.v3+json',
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to connect to GitHub: ' . $response->get_error_message()
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($code === 200) {
            $data = json_decode($body, true);
            return array(
                'success' => true,
                'message' => 'GitHub token is valid. Connected as: ' . $data['login'],
                'user' => $data['login']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'GitHub token is invalid. Response code: ' . $code
            );
        }
    }
    
    /**
     * Handle AJAX system requirements check
     */
    public function handle_check_system_requirements_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $requirements = $this->check_system_requirements();
        wp_send_json_success($requirements);
    }
    
    /**
     * Handle AJAX debug tokens
     */
    public function handle_debug_tokens_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $tokens = $this->debug_github_tokens();
        wp_send_json_success($tokens);
    }
    
    /**
     * Handle AJAX test token
     */
    public function handle_test_token_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $addon_slug = sanitize_text_field($_POST['plugin_slug']);
        $result = $this->test_github_token($addon_slug);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Force remove plugin completely
     */
    public function force_remove_plugin($addon_slug) {
        error_log('MAC Core: Force removing plugin: ' . $addon_slug);
        
        $config = $this->get_plugin_config($addon_slug);
        if (!$config) {
            return array(
                'success' => false,
                'message' => 'Plugin configuration not found.'
            );
        }
        
        // Deactivate plugin first
        if ($this->is_plugin_active($addon_slug)) {
            if (!function_exists('deactivate_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            deactivate_plugins($config['file']);
            error_log('MAC Core: Plugin deactivated: ' . $config['file']);
        }
        
        // Remove plugin directory completely
        $plugin_dir = WP_PLUGIN_DIR . '/' . $config['slug'];
        if (is_dir($plugin_dir)) {
            $this->delete_directory($plugin_dir);
            error_log('MAC Core: Plugin directory removed: ' . $plugin_dir);
        }
        
        // Restore compatibility file if needed
        $this->restore_compatibility_file($addon_slug);
        
        return array(
            'success' => true,
            'message' => 'Plugin removed completely.'
        );
    }
    
    /**
     * Restore compatibility and domain manager files when MAC Menu is removed
     */
    private function restore_compatibility_file($addon_slug) {
        if ($addon_slug === 'mac-menu') {
            // Restore compatibility file
            $compatibility_file = MAC_CORE_PATH . 'includes/mac-menu-compatibility.php';
            $backup_file = $compatibility_file . '.disabled';
            
            if (file_exists($backup_file) && !file_exists($compatibility_file)) {
                error_log('MAC Core: Restoring compatibility file: ' . $compatibility_file);
                rename($backup_file, $compatibility_file);
            }
            
            // Restore domain manager file
            $domain_manager_file = MAC_CORE_PATH . 'includes/class-mac-menu-domain-manager.php';
            $backup_file = $domain_manager_file . '.disabled';
            
            if (file_exists($backup_file) && !file_exists($domain_manager_file)) {
                error_log('MAC Core: Restoring domain manager file: ' . $domain_manager_file);
                rename($backup_file, $domain_manager_file);
            }
            
            // Restore MAC Core main file
            $mac_core_main_file = MAC_CORE_PATH . 'mac-core.php';
            $backup_file = $mac_core_main_file . '.disabled';
            
            if (file_exists($backup_file) && !file_exists($mac_core_main_file)) {
                error_log('MAC Core: Restoring MAC Core main file: ' . $mac_core_main_file);
                rename($backup_file, $mac_core_main_file);
            }
        }
    }
    
    /**
     * Handle AJAX activate plugin
     */
    public function handle_activate_plugin_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $addon_slug = sanitize_text_field($_POST['plugin_slug']);
        $result = $this->activate_plugin($addon_slug);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Handle AJAX force remove plugin
     */
    public function handle_force_remove_plugin_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $addon_slug = sanitize_text_field($_POST['plugin_slug']);
        $result = $this->force_remove_plugin($addon_slug);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Handle AJAX check options status
     */
    public function handle_check_options_status_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        global $mac_core_options_monitor;
        if ($mac_core_options_monitor) {
            $status = $mac_core_options_monitor->get_critical_options_status();
            wp_send_json_success($status);
        } else {
            wp_send_json_error('Options monitor not available.');
        }
    }
    
    /**
     * Handle AJAX check URL
     */
    public function handle_check_url_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        error_log('MAC Core: AJAX Check URL requested');
        
        // Check current domain status
        $current_key = get_option('mac_domain_valid_key', '');
        $current_status = get_option('mac_domain_valid_status', '');
        
        // Clean up invalid values
        if ($current_key === '0' || $current_key === null) {
            $current_key = '';
        }
        if ($current_status === '0' || $current_status === null) {
            $current_status = '';
        }
        
        error_log('MAC Core: Current key: ' . ($current_key ?: 'empty'));
        error_log('MAC Core: Current status: ' . ($current_status ?: 'empty'));
        
        // Call the URL check function
        if (function_exists('kvp_handle_check_request_url')) {
            kvp_handle_check_request_url();
            
            // Check if status changed after the check
            $new_key = get_option('mac_domain_valid_key', '');
            $new_status = get_option('mac_domain_valid_status', '');
            
            if ($new_key !== $current_key || $new_status !== $current_status) {
                wp_send_json_success('Domain status updated! Key: ' . ($new_key ?: 'empty') . ', Status: ' . ($new_status ?: 'empty'));
            } else {
                wp_send_json_success('URL check completed. No changes detected.');
            }
        } else {
            wp_send_json_error('URL check function not available.');
        }
    }
    
    /**
     * Handle AJAX test validate URL
     */
    public function handle_test_validate_url_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        error_log('MAC Core: AJAX Test Validate URL requested');
        
        // Call kvp_handle_check_request_url function directly
        if (function_exists('kvp_handle_check_request_url')) {
            error_log('MAC Core: Calling kvp_handle_check_request_url()');
            kvp_handle_check_request_url();
            wp_send_json_success('Test Validate URL completed successfully. Check error log for detailed API request/response information.');
        } else {
            wp_send_json_error('kvp_handle_check_request_url function not available.');
        }
    }

    public function handle_install_mac_menu_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        // Check if CRM connection is active
        global $mac_core_crm_api_manager;
        if (!$mac_core_crm_api_manager || !$mac_core_crm_api_manager->is_license_valid()) {
            wp_send_json_error('CRM connection must be active to install MAC Menu.');
        }
        
        // Check if MAC Menu already exists
        $mac_menu_path = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        if (file_exists($mac_menu_path)) {
            wp_send_json_error('MAC Menu is already installed. Please activate it instead.');
        }
        
        // Install MAC Menu plugin from GitHub
        $result = $this->install_plugin('mac-menu');
        
        if ($result['success']) {
            wp_send_json_success('MAC Menu installed successfully!');
        } else {
            wp_send_json_error('Failed to install MAC Menu: ' . $result['message']);
        }
    }

    public function handle_activate_mac_menu_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        // Activate MAC Menu plugin
        $plugin_path = 'mac-menu/mac-menu.php';
        
        if (!file_exists(WP_PLUGIN_DIR . '/' . $plugin_path)) {
            wp_send_json_error('MAC Menu plugin not found.');
        }
        
        $result = activate_plugin($plugin_path);
        
        if (is_wp_error($result)) {
            wp_send_json_error('Failed to activate MAC Menu: ' . $result->get_error_message());
        } else {
            wp_send_json_success('MAC Menu activated successfully!');
        }
    }

    public function handle_reset_options_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        // Reset all MAC Menu options
        update_option('mac_domain_valid_key', '');
        update_option('mac_domain_valid_status', '');
        update_option('mac_menu_github_key', '');
        
        wp_send_json_success('Options reset successfully! Page will reload.');
    }

    /**
     * Restore MAC Core if it was disabled
     */
    public function restore_mac_core_if_disabled() {
        $mac_core_main_file = MAC_CORE_PATH . 'mac-core.php';
        $disabled_file = $mac_core_main_file . '.disabled';
        
        if (!file_exists($mac_core_main_file) && file_exists($disabled_file)) {
            error_log('MAC Core: Restoring disabled MAC Core main file');
            rename($disabled_file, $mac_core_main_file);
            return true;
        }
        
        return false;
    }

    public function handle_restore_mac_core_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        $restored = $this->restore_mac_core_if_disabled();
        
        if ($restored) {
            wp_send_json_success('MAC Core restored successfully! Please refresh the page.');
        } else {
            wp_send_json_error('MAC Core is already active or no disabled file found.');
        }
    }

    public function handle_update_mac_menu_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mac_core_install_plugin')) {
            wp_send_json_error('Security check failed.');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions.');
        }
        
        // Check if MAC Menu exists
        $mac_menu_path = WP_PLUGIN_DIR . '/mac-menu/mac-menu.php';
        if (!file_exists($mac_menu_path)) {
            wp_send_json_error('MAC Menu is not installed. Please install it first.');
        }
        
        // Check if CRM connection is active
        global $mac_core_crm_api_manager;
        if (!$mac_core_crm_api_manager || !$mac_core_crm_api_manager->is_license_valid()) {
            wp_send_json_error('CRM connection must be active to update MAC Menu.');
        }
        
        // Update MAC Menu plugin from GitHub
        $result = $this->install_plugin('mac-menu');
        
        if ($result['success']) {
            wp_send_json_success('MAC Menu updated successfully!');
        } else {
            wp_send_json_error('Failed to update MAC Menu: ' . $result['message']);
        }
    }
    
    // Removed custom force delete implementation
    

}
