<?php
namespace MAC_Core;

/**
 * CRM API Manager
 * 
 * Handles all API calls to CRM for domain validation, license checking, and domain registration
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CRM_API_Manager {
    
    // API endpoints
    const VALIDATE_KEY_URL = 'https://wpm.macusaone.com/api/v1/menu-license/validate-key';
    const VALIDATE_URL_URL = 'https://wpm.macusaone.com/api/v1/menu-license/validate-url';
    const REGISTER_DOMAIN_URL = 'https://wpm.macusaone.com/api/v1/menu-license/register-domain';
    
    // Timeout for API requests
    const TIMEOUT = 45;
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Initialize options if they don't exist
        $this->initialize_options();
    }
    
    /**
     * Initialize MAC Menu options
     */
    private function initialize_options() {
        if (false === get_option('mac_domain_valid_key')) {
            add_option('mac_domain_valid_key', '');
        }
        if (false === get_option('mac_domain_valid_status')) {
            add_option('mac_domain_valid_status', '');
        }
        if (false === get_option('mac_menu_github_key')) {
            add_option('mac_menu_github_key', '');
        }
    }
    
    /**
     * Validate key with CRM
     */
    public function validate_key($key, $domain, $version) {
        if (empty($key)) {
            // Don't reset options for empty key, just return error
            return array('success' => false, 'message' => 'Empty key provided');
        }
        
        $response = wp_remote_post(self::VALIDATE_KEY_URL, array(
            'method' => 'POST',
            'body' => array(
                'key' => $key,
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->process_domain_response($data, $key);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Validate URL with CRM (when no key exists)
     */
    public function validate_url($domain, $version) {
        $response = wp_remote_post(self::VALIDATE_URL_URL, array(
            'method' => 'POST',
            'body' => array(
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $this->process_domain_response($data);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Register domain with CRM
     */
    public function register_domain($key, $domain, $version) {
        $response = wp_remote_post(self::REGISTER_DOMAIN_URL, array(
            'method' => 'POST',
            'body' => array(
                'key' => $key,
                'url' => $domain,
                'menuversion' => $version
            ),
            'timeout' => self::TIMEOUT,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array('success' => false, 'message' => 'Invalid response format from server');
        }
        
        $this->process_domain_response($data);
        
        return array('success' => true, 'data' => $data);
    }
    
    /**
     * Process domain response from CRM
     */
    private function process_domain_response($data, $key = null) {
        if (!isset($data['valid']) || !$data['valid']) {
            $this->reset_domain_options();
            return;
        }
        
        $this->update_domain_options($data);
    }
    
    /**
     * Update domain options
     */
    private function update_domain_options($data) {
        update_option('mac_domain_valid_key', $data['keyDomain']);
        update_option('mac_domain_valid_status', $data['statusDomain']);
        
        if (in_array($data['statusDomain'], array('activate', 'deactivate'))) {
            update_option('mac_menu_github_key', $data['keytoken']);
        } else {
            update_option('mac_menu_github_key', null);
        }
    }
    
    /**
     * Reset domain options
     */
    private function reset_domain_options() {
        update_option('mac_domain_valid_key', null);
        update_option('mac_domain_valid_status', null);
        update_option('mac_menu_github_key', null);
    }
    
    /**
     * Get domain status
     */
    public function get_domain_status() {
        return get_option('mac_domain_valid_status', '');
    }
    
    /**
     * Get domain key
     */
    public function get_domain_key() {
        return get_option('mac_domain_valid_key', '');
    }
    
    /**
     * Get GitHub token
     */
    public function get_github_token() {
        return get_option('mac_menu_github_key', '');
    }
    
    /**
     * Check if license is valid
     */
    public function is_license_valid() {
        return (get_option('mac_domain_valid_status', '') === 'activate');
    }
}
