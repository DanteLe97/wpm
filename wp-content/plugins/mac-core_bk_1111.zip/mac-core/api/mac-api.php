<?php

require_once MAC_CORE_PATH . 'api/mac-walc-core.php';
require_once MAC_CORE_PATH . 'api/mac-addon-manager.php';
// Include MAC Info Manager (đã tách thành nhiều file)
require_once MAC_CORE_PATH . 'api/mac-info-manager.php'; // File chính (đã include mac-sitecheck.php)
require_once MAC_CORE_PATH . 'api/mac-user-manager.php';





