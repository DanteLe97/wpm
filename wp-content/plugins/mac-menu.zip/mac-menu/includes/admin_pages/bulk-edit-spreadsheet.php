<?php
// Kiểm tra quyền truy cập
if (!defined('ABSPATH')) {
    exit;
}

// Lấy data từ WordPress transient (thay vì session)
$user_id = get_current_user_id();
$transient_key = 'mac_bulk_edit_data_' . $user_id;
$bulk_edit_data = get_transient($transient_key);

if ($bulk_edit_data === false) {
    // Nếu không có transient, có thể là lần đầu hoặc đã hết hạn
    // Cho phép vào editor với data trống
    $bulk_edit_data = array();
}

// Cho phép hiển thị editor ngay cả khi data trống (không cần check empty)

// Định nghĩa columns
$columns = array(
    'id', 'category_name', 'category_description', 'price', 'featured_img',
    'parents_category', 'is_hidden', 'is_table', 'table_heading',
    'item_list_name', 'item_list_price', 'item_list_description',
    'item_list_fw', 'item_list_img', 'item_list_position',
    'category_inside', 'category_inside_order'
);

$column_headers = array(
    'ID', 'Category Name', 'Category Description', 'Price', 'Featured Image',
    'Parents Category', 'Is Hidden', 'Is Table', 'Table Heading',
    'Item Name', 'Item Price', 'Item Description',
    'Item Full Width', 'Item Image', 'Item Position',
    'Category Inside', 'Category Inside Order'
);

// Chuyển đổi data thành format cho Handsontable
$hot_data = array();
if (!empty($bulk_edit_data)) {
    foreach ($bulk_edit_data as $row) {
        $hot_row = array();
        foreach ($columns as $col) {
            $hot_row[] = isset($row[$col]) ? $row[$col] : '';
        }
        $hot_data[] = $hot_row;
    }
}
// Nếu data trống, $hot_data sẽ là mảng rỗng - Handsontable sẽ hiển thị bảng trống

// Encode data để truyền vào JavaScript
$hot_data_json = json_encode($hot_data);
$column_headers_json = json_encode($column_headers);
$nonce = wp_create_nonce('mac_bulk_edit_save');
?>

<div class="wrap">
    <h1 class="wp-heading-inline">Bulk Edit Menu - Spreadsheet Editor</h1>
    <hr class="wp-header-end">
    
    <div class="postbox" style="margin-top: 20px;">
        <div class="postbox-header">
            <h2>Edit Menu Data</h2>
        </div>
        <div class="inside">
            <?php if (empty($bulk_edit_data)): ?>
                <div class="notice notice-info" style="margin-bottom: 20px;">
                    <p><strong>Empty Table:</strong> No data found. You can add new data by clicking on the cells below and entering your information.</p>
                </div>
            <?php endif; ?>
            
            <div style="margin-bottom: 20px;">
                <button id="mac-bulk-edit-save" class="button button-primary button-large">
                    <span class="dashicons dashicons-yes" style="vertical-align: middle; margin-right: 5px;"></span>
                    Save Changes
                </button>
                <button id="mac-bulk-edit-add-row" class="button button-secondary">
                    <span class="dashicons dashicons-plus-alt" style="vertical-align: middle; margin-right: 5px;"></span>
                    Add Row
                </button>
                <a href="<?php echo admin_url('admin.php?page=mac-menu-bulk-edit'); ?>" class="button button-secondary">
                    Cancel
                </a>
                <span id="mac-bulk-edit-status" style="margin-left: 20px;"></span>
            </div>
            
            <div id="mac-bulk-edit-spreadsheet" style="overflow: auto; max-width: 100%;"></div>
        </div>
    </div>
</div>

<!-- Handsontable CSS -->
<link href="https://cdn.jsdelivr.net/npm/handsontable@latest/dist/handsontable.full.min.css" rel="stylesheet">

<!-- Handsontable JS -->
<script src="https://cdn.jsdelivr.net/npm/handsontable@latest/dist/handsontable.full.min.js"></script>

<script>
jQuery(document).ready(function($) {
    var container = document.getElementById('mac-bulk-edit-spreadsheet');
    var hotData = <?php echo $hot_data_json; ?>;
    var columnHeaders = <?php echo $column_headers_json; ?>;
    
    var hot = new Handsontable(container, {
        data: hotData,
        colHeaders: columnHeaders,
        rowHeaders: true,
        width: '100%',
        height: 600,
        licenseKey: 'non-commercial-and-evaluation',
        stretchH: 'all',
        columnSorting: true,
        contextMenu: true,
        manualColumnResize: true,
        manualRowResize: true,
        filters: true,
        dropdownMenu: true,
        minSpareRows: 10, // Tự động tạo 10 row trống ở cuối (giống CSV)
        allowInsertRow: true, // Cho phép insert row từ context menu
        allowRemoveRow: true, // Cho phép xóa row
        columns: [
            { data: 0, type: 'numeric', width: 80 }, // id
            { data: 1, type: 'text', width: 150 }, // category_name
            { data: 2, type: 'text', width: 200 }, // category_description
            { data: 3, type: 'text', width: 100 }, // price
            { data: 4, type: 'text', width: 150 }, // featured_img
            { data: 5, type: 'text', width: 120 }, // parents_category
            { data: 6, type: 'numeric', width: 80 }, // is_hidden
            { data: 7, type: 'numeric', width: 80 }, // is_table
            { data: 8, type: 'text', width: 150 }, // table_heading
            { data: 9, type: 'text', width: 150 }, // item_list_name
            { data: 10, type: 'text', width: 120 }, // item_list_price
            { data: 11, type: 'text', width: 200 }, // item_list_description
            { data: 12, type: 'numeric', width: 100 }, // item_list_fw
            { data: 13, type: 'text', width: 150 }, // item_list_img
            { data: 14, type: 'numeric', width: 100 }, // item_list_position
            { data: 15, type: 'numeric', width: 120 }, // category_inside
            { data: 16, type: 'text', width: 150 } // category_inside_order
        ]
    });
    
    // Xử lý Add Row button
    $('#mac-bulk-edit-add-row').on('click', function() {
        // Thêm 20 row trống mới
        var currentData = hot.getData();
        var emptyRow = [];
        for (var i = 0; i < <?php echo count($columns); ?>; i++) {
            emptyRow.push('');
        }
        
        // Thêm 5 row trống
        for (var i = 0; i < 20; i++) {
            currentData.push(emptyRow.slice()); // Copy array
        }
        
        hot.loadData(currentData);
    });
    
    // Xử lý Save
    $('#mac-bulk-edit-save').on('click', function() {
        if (!confirm('Are you sure you want to save changes? This will replace all existing menu data.')) {
            return;
        }
        
        var $button = $(this);
        var $status = $('#mac-bulk-edit-status');
        
        $button.prop('disabled', true);
        $status.html('<span class="spinner is-active" style="float: none; margin: 0 10px;"></span> Saving...');
        
        // Lấy data từ Handsontable
        var data = hot.getData();
        var columns = <?php echo json_encode($columns); ?>;
        
        // Chuyển đổi về format array và filter bỏ row trống hoàn toàn
        var formattedData = [];
        for (var i = 0; i < data.length; i++) {
            var row = {};
            var hasData = false; // Kiểm tra row có data không
            
            for (var j = 0; j < columns.length; j++) {
                var value = data[i][j] !== null && data[i][j] !== undefined ? data[i][j] : '';
                row[columns[j]] = value;
                
                // Kiểm tra nếu có ít nhất 1 giá trị không rỗng
                if (value !== '' && value !== null && value !== undefined) {
                    hasData = true;
                }
            }
            
            // Chỉ thêm row nếu có ít nhất 1 giá trị
            if (hasData) {
                formattedData.push(row);
            }
        }
        
        // Kiểm tra nếu không có data nào
        if (formattedData.length === 0) {
            $status.html('<span style="color: orange;">⚠ No data to save. Please enter at least one row of data.</span>');
            $button.prop('disabled', false);
            return;
        }
        
        // Gửi AJAX request
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json', // Đảm bảo parse response thành JSON
            data: {
                action: 'mac_bulk_edit_save',
                nonce: '<?php echo $nonce; ?>',
                data: JSON.stringify(formattedData)
            },
            success: function(response) {
                console.log('Full Response:', response); // Debug
                console.log('Response Type:', typeof response);
                console.log('Response.success:', response ? response.success : 'undefined');
                console.log('Response.data:', response ? response.data : 'undefined');
                
                // Kiểm tra response có tồn tại
                if (!response) {
                    console.error('Response is null or undefined');
                    $status.html('<span style="color: red;">✗ Error: No response received</span>');
                    $button.prop('disabled', false);
                    return;
                }
                
                // Kiểm tra response có success property và giá trị là true
                if (typeof response === 'object' && response.hasOwnProperty('success') && response.success === true) {
                    var message = 'Changes saved successfully!';
                    if (response.data && typeof response.data === 'object') {
                        if (response.data.message) {
                            message = response.data.message;
                        }
                    }
                    $status.html('<span style="color: green;">✓ ' + message + '</span>');
                    setTimeout(function() {
                        window.location.href = '<?php echo admin_url('admin.php?page=mac-cat-menu'); ?>';
                    }, 2000);
                } else {
                    // Xử lý trường hợp response.success = false hoặc không có success property
                    var errorMsg = 'Unknown error occurred';
                    
                    if (typeof response === 'object') {
                        if (response.data && typeof response.data === 'object') {
                            if (response.data.message) {
                                errorMsg = response.data.message;
                            } else if (response.data.errors && Array.isArray(response.data.errors) && response.data.errors.length > 0) {
                                errorMsg = response.data.errors.join('; ');
                            }
                        } else if (response.message) {
                            errorMsg = response.message;
                        }
                    } else if (typeof response === 'string') {
                        // Nếu response là string, có thể là JSON string
                        try {
                            var parsed = JSON.parse(response);
                            if (parsed.data && parsed.data.message) {
                                errorMsg = parsed.data.message;
                            }
                        } catch(e) {
                            errorMsg = response;
                        }
                    }
                    
                    // Nếu vẫn là "Unknown error" nhưng có response, log để debug
                    if (errorMsg === 'Unknown error occurred') {
                        console.error('Unexpected response format:', response);
                        console.error('Response keys:', Object.keys(response || {}));
                    }
                    
                    $status.html('<span style="color: red;">✗ Error: ' + errorMsg + '</span>');
                    $button.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', xhr, status, error); // Debug
                var errorMsg = error;
                if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    errorMsg = xhr.responseJSON.data.message;
                } else if (xhr.responseText) {
                    try {
                        var parsed = JSON.parse(xhr.responseText);
                        if (parsed.data && parsed.data.message) {
                            errorMsg = parsed.data.message;
                        }
                    } catch(e) {
                        errorMsg = xhr.responseText.substring(0, 200);
                    }
                }
                $status.html('<span style="color: red;">✗ Error: ' + errorMsg + '</span>');
                $button.prop('disabled', false);
            }
        });
    });
});
</script>

<style>
#mac-bulk-edit-spreadsheet {
    margin-top: 20px;
}
.handsontable {
    font-size: 13px;
}
</style>

