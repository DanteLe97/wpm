jQuery(document).ready(function($) {
  const panel = $('#elementor-color-control-panel');
  const toggleBtn = $('.toggle-button');
  const closeBtn = $('.close-panel');

  /*---------------------------- Initialization ----------------------------*/ 
  // Định nghĩa các preset
  const presets = {
    modern: {
      colors: {
        primary: '#F26212',
        secondary: '#FBAE85',
        text: '#333333',
        accent: '#FBAE85'
      },
      fonts: {
        primary: 'Montserrat',
        secondary: 'Open Sans'
      }
    },
    minimal: {
      colors: {
        primary: '#333333',
        secondary: '#666666',
        text: '#333333',
        accent: '#666666'
      },
      fonts: {
        primary: 'Helvetica',
        secondary: 'Arial'
      }
    },
    nature: {
      colors: {
        primary: '#28a745',
        secondary: '#20c997',
        text: '#333333',
        accent: '#20c997'
      },
      fonts: {
        primary: 'Poppins',
        secondary: 'Open Sans'
      }
    },
    ocean: {
      colors: {
        primary: '#007bff',
        secondary: '#17a2b8',
        text: '#333333',
        accent: '#17a2b8'
      },
      fonts: {
        primary: 'Roboto',
        secondary: 'Lato'
      }
    }
  };

  /*---------------------------- Helper Functions ----------------------------*/ 
  // Google Fonts Loader
  function ensurePreconnect() {
    if (!document.querySelector('link[rel="preconnect"][href="https://fonts.googleapis.com"]')) {
      const l1 = document.createElement('link');
      l1.rel = 'preconnect';
      l1.href = 'https://fonts.googleapis.com';
      document.head.appendChild(l1);
    }
    if (!document.querySelector('link[rel="preconnect"][href="https://fonts.gstatic.com"]')) {
      const l2 = document.createElement('link');
      l2.rel = 'preconnect';
      l2.href = 'https://fonts.gstatic.com';
      l2.crossOrigin = 'anonymous';
      document.head.appendChild(l2);
    }
  }
  function loadGoogleFontFamily(fontFamily, weights = '100;200;300;400;500;600;700;800;900') {
    if (!fontFamily) return Promise.resolve();
    ensurePreconnect();
    const famParam = String(fontFamily).trim().replace(/\s+/g, '+');
    const id = `glf-${famParam}-${String(weights).replace(/[^0-9;]/g,'')}`;
    if (!document.getElementById(id)) {
      const link = document.createElement('link');
      link.id = id;
      link.rel = 'stylesheet';
      link.href = `https://fonts.googleapis.com/css2?family=${famParam}:wght@${weights}&display=swap`;
      document.head.appendChild(link);
    }
    if (document.fonts && document.fonts.load) {
      return document.fonts.load(`1em "${fontFamily}"`);
    }
    return new Promise(r => setTimeout(r, 300));
  }
   function getCurrentColorsStyles() {
    const colors = {};
    // Ưu tiên cấu trúc mới của Coloris: .clr-field > input.coloris[data-color]
    const $newInputs = $('.color-control .clr-field > input.coloris[data-color]');
    if ($newInputs.length) {
      $newInputs.each(function() {
        const $input = $(this);
        const dataColor = $input.data('color');
        const $colorControl = $input.closest('.color-control');
        const label = $colorControl.find('label').text().trim();
        const $field = $input.closest('.clr-field');
        const rgb = $field.css('color');
        // Chuyển rgb/rgba sang hex ngay trong hàm (không thay đổi code cũ)
        let hex = '';
        if (rgb && /^rgba?/i.test(rgb)) {
          const m = rgb.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
          if (m) {
            const toHex = function(n) { return parseInt(n, 10).toString(16).padStart(2, '0'); };
            hex = ('#' + toHex(m[1]) + toHex(m[2]) + toHex(m[3])).toLowerCase();
          }
        }
        if (!hex) {
          hex = $input.val();
        }
        if (dataColor && hex) {
          // Lưu dưới dạng object với _id và title
          colors[dataColor] = {
            _id: dataColor,
            title: label || dataColor,
            color: hex
          };
        }
      });
      return colors;
    }
    // Fallback: giữ nguyên cách lấy cũ từ input
    $('.color-control input.coloris-input, .color-control input[type="color"]').each(function() {
      const input = $(this);
      const id = input.attr('id');
      if (!id) return;
      const colorName = id.replace('-color', '');
      const colorValue = input.val();
      if (colorValue) {
        colors[colorName] = colorValue;
      }
    });
    return colors;
  }
  // Hàm lấy tất cả màu hiện tại từ các input
  function getCurrentColors() {
    const colors = {};
	$('.color-control input.coloris, .color-control input[type="text"]').each(function() {
//     $('.color-control input[type="color"]').each(function() {
      const input = $(this);
      const id = input.attr('id');
      if (!id) return;
      
      const colorName = id.replace('-color', '');
      const colorValue = input.val();
      if (colorValue) {
        colors[colorName] = colorValue;
      }
    });
    return colors;
  }

  // Hàm lấy tất cả font hiện tại từ các select
  function getCurrentFonts() {
    const fonts = {};
    $('.font-control select.font-select').each(function() {
      const select = $(this);
      const id = select.attr('id');
      if (!id) return;
      
      const fontName = id.replace('-font', '');
      const fontValue = select.val();
      if (fontValue) {
        fonts[fontName] = fontValue;
      }
    });
    return fonts;
  }

  // Hàm lấy tất cả CSS variables từ database
  function getCSSVariables() {
    const variables = {};

    $('.color-control input[type="color"],.color-control .coloris').each(function() {
      const input = $(this);
      const id = input.attr('data-color');
      if (!id) return;
      
      const colorName = id.replace('-color', '');
      const colorValue = input.val();
      // Tìm CSS variable tương ứng từ data attribute hoặc tạo mới
      if (colorValue) {
        const cssVar = `--e-global-color-${colorName}`;
        variables[cssVar] = colorValue;
      }
		console.log(colorValue);
    });

    return variables;
  }

  // Hàm lấy map selector -> font-family từ UI (primary/secondary/accent)
  function getCSSFontVariables() {
    const selectorToFont = {};
    $('.font-control select.font-select').each(function() {
      const select = $(this);
      const id = select.attr('id');
      if (!id) return;

      const slug = id.replace('-font', '');
      const fontValue = select.val();
      if (!fontValue) return;

      // Map slug -> selectors (đồng bộ với macruleid)
      let selectors = '';
       if (slug === 'secondary') {
        selectors = 'main span, p, main, main .secondary-font';
      }else if (slug === 'primary') {
        selectors = 'main h1, main h2,main h3,main h4,main h5,main h6,main .primary-font,main .module-category__name,main h1 span,main h2 span,main h3 span,main h4 span,main h5 span,main h6 span,main .primary-font,main .module-category__name';
      } else if (slug === 'accent') {
        selectors = 'main .accent-font h1,main .accent-font h2,main .accent-font h3,main .accent-font h4,main .accent-font h5,main .accent-font h6,main .accent-font .elementor-heading-title,main .accent-font h1 span,main .accent-font h2 span,main .accent-font h3 span,main .accent-font h4 span,main .accent-font h5 span,main .accent-font h6 span,main .accent-font .elementor-heading-title,main .accent-font';
      } else {
        return; // bỏ qua slug lạ
      }

      selectorToFont[selectors] = `"${fontValue}", sans-serif`;
    });
    return selectorToFont;
  }

  // Tối ưu hóa helper function để tạo CSS rules
  function createCSSRules(variables) {
    if (!variables || Object.keys(variables).length === 0) return '';
    
    return Object.entries(variables)
      .map(([key, value]) => `${key}: ${value} !important;`)
      .join('\n        ');
  }

  // Tạo CSS rules theo selectors cho fonts
  function createFontSelectorRules(selectorMap) {
    if (!selectorMap || Object.keys(selectorMap).length === 0) return '';
    return Object.entries(selectorMap)
      .map(([selectors, family]) => `${selectors} {\n  font-family: ${family} !important  ;\n}`)
      .join('\n');
  }

  // Hàm cập nhật CSS cho website
  function updateWebsiteColors() {
      // Tạo hoặc lấy style element
      let styleElement = $('#elementor-live-color-dynamic-styles');
      if (styleElement.length === 0) {
        styleElement = $('<style id="elementor-live-color-dynamic-styles"></style>');
        $('head').append(styleElement);
      }

      // Lấy CSS variables từ database
      const colorVariables = getCSSVariables();
      const fontSelectorMap = getCSSFontVariables();
    
      // Tạo CSS rules hiệu quả hơn
      const colorRules = createCSSRules(colorVariables);
      const fontSelectorRules = createFontSelectorRules(fontSelectorMap);

      // Tạo CSS với cấu trúc rõ ràng và hiệu quả
      const cssRules = [];
      
      // Thêm color variables vào :root
      if (colorRules) {
        cssRules.push(`body {\n         ${colorRules}\n    }`);
      }  
      if (fontSelectorRules) {
        cssRules.push(fontSelectorRules);
      }

      // Áp dụng font variables cho các elements
//       if (fontRules) {
//         cssRules.push(`
//           [data-elementor-type="wp-page"] h1,
//           [data-elementor-type="wp-page"] h2,
//           [data-elementor-type="wp-page"] h3,
//           [data-elementor-type="wp-page"] h4,
//           [data-elementor-type="wp-page"] h5,
//           [data-elementor-type="wp-page"] h6,
//           [data-elementor-type="wp-page"] h1 span,
//           [data-elementor-type="wp-page"] h2 span,
//           [data-elementor-type="wp-page"] h3 span,
//           [data-elementor-type="wp-page"] h4 span,
//           [data-elementor-type="wp-page"] h5 span,
//           [data-elementor-type="wp-page"] h6 span {
//             font-family: var(--e-global-typography-primary-font-family, inherit) !important;
//           }
//         `);
        
//         cssRules.push(`
//           [data-elementor-type="wp-page"] p,
//           [data-elementor-type="wp-page"] div,
//           [data-elementor-type="wp-page"] p span,
//           [data-elementor-type="wp-page"] div span {
//             font-family: var(--e-global-typography-secondary-font-family, inherit);
//           }
//         `);
//       }
      
      // Cập nhật style element
      styleElement.html(cssRules.join('\n'));
  }

  /*---------------------------- UI Events ----------------------------*/ 
  // Xử lý chuyển đổi tab
  $('.tab-button').on('click', function() {
    const tabId = $(this).data('tab');
    
    // Cập nhật trạng thái active của tab
    $('.tab-button').removeClass('active');
    $(this).addClass('active');
    
    // Hiển thị nội dung tab tương ứng
    $('.tab-pane').removeClass('active');
    $(`#${tabId}-tab`).addClass('active');
  });

  // Xử lý chọn preset
  $('.preset-item').on('click', function() {
    const presetId = $(this).data('preset');
    const preset = presets[presetId];
    
    if (preset) {
      // Cập nhật các input với giá trị từ preset (chỉ cho các màu cơ bản)
      if ($('#primary-color').length) $('#primary-color').val(preset.colors.primary);
      if ($('#secondary-color').length) $('#secondary-color').val(preset.colors.secondary);
      if ($('#text-color').length) $('#text-color').val(preset.colors.text);
      if ($('#accent-color').length) $('#accent-color').val(preset.colors.accent);
      if ($('#primary-font').length) $('#primary-font').val(preset.fonts.primary);
      if ($('#secondary-font').length) $('#secondary-font').val(preset.fonts.secondary);
      
      // Cập nhật preview
      $('.color-preview').each(function() {
        const colorInput = $(this).siblings('input[type="color"]');
        $(this).css('background-color', colorInput.val());
      });
      
      // Cập nhật website
      const currentColors = getCurrentColorsStyles();
      const currentFonts = getCurrentFonts();
      updateWebsiteColors(currentColors, currentFonts);
    }
  });

  toggleBtn.on('click', function() {
    panel.toggleClass('active');
  });

  closeBtn.on('click', function() {
    panel.removeClass('active');
  });

  // Cập nhật preview và website khi thay đổi màu
  $('.color-control .coloris').on('input', function() {
    //const preview = $(this).siblings('.color-preview');
	const preview = $(this).closest('.color-control').find('.color-preview');
    const colorValue = $(this).val();
    preview.css('background-color', colorValue);
    
    // Log màu sắc riêng lẻ khi thay đổi
    console.log(`Đã thay đổi ${$(this).prev('label').text()}:`, colorValue);
    
    // Lấy tất cả màu hiện tại - SỬ DỤNG HÀM MỚI
    const colors = getCurrentColorsStyles();

    // Lấy font hiện tại
    const fonts = getCurrentFonts();
    
    // Cập nhật website
    updateWebsiteColors(colors, fonts);
  });

  // Cập nhật website khi thay đổi font
  $('.font-select').on('change', function() {
    const colors = getCurrentColorsStyles();
    const fonts = getCurrentFonts();
    Promise.all(Object.values(fonts).map(f => loadGoogleFontFamily(f)))
      .finally(() => {
        console.log('Font đã thay đổi:', fonts);
        updateWebsiteColors(colors, fonts);
      });
  });

  // Khởi tạo preview ban đầu
  $('.color-control input[type="text"]').each(function() {
    const preview = $(this).siblings('.color-preview');
    preview.css('background-color', $(this).val());
  });

  // Khởi tạo màu ban đầu cho website
  const initialColors = getCurrentColorsStyles();

  // Khởi tạo font ban đầu
  const initialFonts = getCurrentFonts();

  // Init Select2 for font selects using fonts from PHP (elementorLiveColor.fonts)
  function initFontSelect2() {
    if (!window.elementorLiveColor || !Array.isArray(window.elementorLiveColor.fonts)) return;
    const fonts = window.elementorLiveColor.fonts;
    $('.font-select').each(function() {
      const $sel = $(this);
      const current = $sel.data('current') || $sel.val() || '';
      // clear and populate
      $sel.empty();
      $sel.append($('<option>'));
      fonts.forEach(f => {
        if (f && f.value) {
          const opt = new Option(f.text || f.value, f.value, false, false);
          $sel.append(opt);
        }
      });
      // init select2
      if ($sel.hasClass('select2-hidden-accessible')) {
        $sel.select2('destroy');
      }
      $sel.select2({ width: '100%', placeholder: 'Select Font', allowClear: true, dropdownAutoWidth: true });
      if (current) {
        $sel.val(current).trigger('change');
      }
    });
  }
  initFontSelect2();

  Promise.all(Object.values(initialFonts).map(f => loadGoogleFontFamily(f)))
    .finally(() => updateWebsiteColors(initialColors, initialFonts));

  // Xử lý export settings
  jQuery('#export-settings').on('click', function() {
    const pageId = getCurrentPageId();
    
    // Lấy tất cả màu sắc hiện tại đã thay đổi
    const currentColors = getCurrentColorsStyles();
    
    // Lấy tất cả font hiện tại đã thay đổi  
    const currentFonts = getCurrentFonts();
    const fontValues = Object.values(currentFonts);
    
    console.log("Đang export với dữ liệu hiện tại:");
    console.log("- Màu sắc hiện tại:", currentColors);
    console.log("- Font hiện tại:", currentFonts);
    console.log("- Page ID:", pageId);

    jQuery.ajax({
      url: elementorLiveColor.ajaxurl,
      type: 'POST',
      data: {
        action: 'export_page_settings',
        nonce: elementorLiveColor.nonce,
        page_id: pageId,
        current_colors: currentColors,     // Gửi màu sắc hiện tại
        current_fonts: currentFonts,       // Gửi font hiện tại
        fonts: fontValues                  // Giữ lại để tương thích
      },
      success: function(response) {
        if (response.success) {
          const data = response.data;
          console.log("Export thành công:", data);
          
          // Tạo tên file với timestamp để dễ phân biệt
          const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
          const filename = `mac-theme-settings-${data.page_id}-${timestamp}.json`;
          
          const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
          
          alert(`Đã export thành công các cài đặt hiện tại!\nFile: ${filename}`);
        } else {
          console.error("Export failed:", response);
          alert('Có lỗi xảy ra khi export settings: ' + (response.data || 'Unknown error'));
        }
      },
      error: function(xhr, status, error) {
        console.error("AJAX Error:", {xhr, status, error});
        alert('Có lỗi xảy ra khi export settings: ' + error);
      }
    });
  });

  // Xử lý export site settings
  jQuery('#export-site-settings').on('click', function() {
    // Lấy tất cả màu sắc hiện tại đã thay đổi
    //const currentColors = getCurrentColors();
  
    const currentColors = getCurrentColorsStyles();
    // Lấy tất cả font hiện tại đã thay đổi  
    const currentFonts = getCurrentFonts();
    
    console.log("Đang export Site Settings với dữ liệu hiện tại:");
    console.log("- Màu sắc hiện tại:", currentColors);
    console.log("- Font hiện tại:", currentFonts);
    
    // Hiển thị loading state
    const btn = $(this);
    const originalHTML = btn.html();
    btn.html('<span>Đang export...</span>').prop('disabled', true);

    jQuery.ajax({
      url: elementorLiveColor.ajaxurl,
      type: 'POST',
      data: {
        action: 'export_site_settings',
        nonce: elementorLiveColor.nonce,
        current_colors: currentColors,
        current_fonts: currentFonts
      },
      success: function(response) {
        // Khôi phục nút
        btn.html(originalHTML).prop('disabled', false);
        
        if (response.success) {
          const data = response.data;
          console.log("Export Site Settings thành công:", data);
          
          // Tạo tên file với thông tin site và timestamp
          const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
          const siteNameSource = document.title || window.location.hostname || 'site';
          const siteName = siteNameSource.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
          const filename = `${siteName}-elementor-kit-${timestamp}.json`;
          
          const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
          
          // Hiển thị thông báo chi tiết
          const message = `Đã export thành công Site Settings!\n\n` +
                         `🎨 Màu sắc: ${Object.keys(currentColors).length} màu\n` +
                         `📝 Font: ${Object.keys(currentFonts).length} font\n` +
                         `📁 File: ${filename}`;
          
          alert(message);
        } else {
          console.error("Export Site Settings failed:", response);
          alert('Có lỗi xảy ra khi export site settings: ' + (response.data || 'Unknown error'));
        }
      },
      error: function(xhr, status, error) {
        // Khôi phục nút
        btn.html(originalHTML).prop('disabled', false);
        
        console.error("AJAX Error:", {xhr, status, error});
        alert('Có lỗi xảy ra khi export site settings: ' + error);
      }
    });
  });

  // Hàm lấy ID của trang hiện tại
  function getCurrentPageId() {
    // Kiểm tra nếu đang ở trang đơn
    if (document.body.classList.contains('single')) {
      const postId = document.body.className.match(/postid-(\d+)/);
      if (postId && postId[1]) {
        return postId[1];
      }
    }
    
    // Kiểm tra nếu đang ở trang Elementor
    const elementorData = window.elementorFrontendConfig;
    if (elementorData && elementorData.post && elementorData.post.id) {
      return elementorData.post.id;
    }
    
    // Nếu không tìm thấy, trả về 0
    return 0;
  }

  /*---------------------------- Close Coloris Picker on Scroll ----------------------------*/
  // Đóng picker khi scroll window hoặc tab-content
  let scrollTimeout;
  
  function closeColorisPicker() {
    const picker = document.getElementById('clr-picker');
    if (!picker) return;
    
    // Kiểm tra xem picker có đang hiển thị không
    const pickerDisplay = window.getComputedStyle(picker).display;
    if (pickerDisplay === 'none') return;
    
    // Đóng picker bằng cách click vào preview button (close button)
    const previewButton = picker.querySelector('.clr-preview');
    if (previewButton) {
      previewButton.click();
    } else {
      // Fallback: ẩn picker trực tiếp nếu không tìm thấy button
      picker.style.display = 'none';
    }
  }
  
  // Xử lý scroll của window
  function handleWindowScroll() {
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(function() {
      closeColorisPicker();
    }, 100); // Debounce 100ms để tránh đóng quá nhanh
  }
  
  // Xử lý scroll của tab-content
  function handleTabContentScroll() {
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(function() {
      closeColorisPicker();
    }, 100); // Debounce 100ms
  }
  
  // Lắng nghe scroll của window
  $(window).on('scroll', handleWindowScroll);
  
  // Lắng nghe scroll của tab-content trong panel
  const panelElement = document.getElementById('elementor-color-control-panel');
  if (panelElement) {
    const tabContent = panelElement.querySelector('.tab-content');
    if (tabContent) {
      $(tabContent).on('scroll', handleTabContentScroll);
      tabContent.addEventListener('scroll', handleTabContentScroll, true);
    }
  } else {
    // Retry sau 1 giây nếu panel chưa có
    setTimeout(function() {
      const panelRetry = document.getElementById('elementor-color-control-panel');
      if (panelRetry) {
        const tabContent = panelRetry.querySelector('.tab-content');
        if (tabContent) {
          $(tabContent).on('scroll', handleTabContentScroll);
          tabContent.addEventListener('scroll', handleTabContentScroll, true);
        }
      }
    }, 1000);
  }
  
  console.log('✅ Coloris picker auto-close on scroll initialized');
});


