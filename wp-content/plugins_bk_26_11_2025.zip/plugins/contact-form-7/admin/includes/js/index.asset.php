<?php

return array(
	'dependencies' => array(
		'wp-api-fetch',
		'wp-i18n',
	),
	'version' => WPCF7_VERSION,
);
